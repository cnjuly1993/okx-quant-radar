#!/usr/bin/env bash
# ==============================================================================
#  OKX 量化系统 · 一键安装脚本
#  用法（二选一）：
#    1) 解压后在本目录执行：  sudo bash install.sh
#    2) 远程一条命令：        curl -fsSL <安装包地址> | sudo bash
#       （远程模式需要设置环境变量 OKX_DIST_URL 指向 tar.gz 地址）
#
#  这个脚本只做安装与自检，不碰你的资金、不配置任何交易参数。
#  安装完成后请在浏览器里打开控制台完成设置（填 API Key、选规模、开始）。
# ==============================================================================
set -euo pipefail

RADAR="${OKX_RADAR_HOME:-/opt/okx-radar}"
PROFILE="${OKX_PROFILE:-default}"
PORT="${CONSOLE_PORT:-8080}"
UNIT="okx-monitor-live"
CONSOLE_UNIT="okx-console"
WRAPPER="/usr/local/bin/okx-${PROFILE}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd || echo /tmp)"

say()  { printf '\033[1;36m[%s]\033[0m %s\n' "$1" "$2"; }
warn() { printf '\033[1;33m[注意]\033[0m %s\n' "$1"; }
die()  { printf '\033[1;31m[失败]\033[0m %s\n' "$1" >&2; exit 1; }

[ "$(id -u)" = "0" ] || die "请用 root 运行：sudo bash install.sh"

# ---------------------------------------------------------------- 0. 系统检查
command -v apt-get >/dev/null 2>&1 || die "目前只支持 Ubuntu / Debian 系统"
. /etc/os-release 2>/dev/null || true
say "1/7" "系统：${PRETTY_NAME:-unknown}"

ARCH="$(uname -m)"
case "$ARCH" in x86_64|aarch64) ;; *) warn "未测试的 CPU 架构：$ARCH" ;; esac

# 内存很小的机器先补一块 swap（否则策略进程容易被系统杀掉且不重启）
MEM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
SWAP_MB=$(awk '/SwapTotal/{print int($2/1024)}' /proc/meminfo)
if [ "$MEM_MB" -lt 2048 ] && [ "$SWAP_MB" -lt 512 ]; then
  say "1/7" "内存 ${MEM_MB}MB 且没有 swap，正在创建 2GB swap（防止进程被系统杀掉）"
  if [ ! -f /swapfile ]; then
    fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
    chmod 600 /swapfile; mkswap /swapfile >/dev/null; swapon /swapfile
    grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  else
    swapon /swapfile 2>/dev/null || true
  fi
fi

# ---------------------------------------------------------------- 1. 取安装文件
WORK=""
if [ -f "$HERE/src/strategy-monitor.ps1" ]; then
  WORK="$HERE"
  say "2/7" "使用本目录的安装文件：$WORK"
else
  [ -n "${OKX_DIST_URL:-}" ] || die "本目录没有 src/ 文件，也没有设置 OKX_DIST_URL 环境变量"
  WORK="$(mktemp -d)"
  say "2/7" "下载安装包：$OKX_DIST_URL"
  curl -fsSL "$OKX_DIST_URL" -o "$WORK/dist.tgz" || die "下载失败，请检查网络或地址"
  tar xzf "$WORK/dist.tgz" -C "$WORK" || die "解压失败"
  [ -f "$WORK/src/strategy-monitor.ps1" ] || WORK="$(dirname "$(find "$WORK" -name strategy-monitor.ps1 | head -1)")/.."
  [ -f "$WORK/src/strategy-monitor.ps1" ] || die "安装包里找不到 src/strategy-monitor.ps1"
fi

# ---------------------------------------------------------------- 2. 装依赖
export DEBIAN_FRONTEND=noninteractive
say "3/7" "安装运行环境（Node.js / PowerShell / OKX 命令行）"
apt-get update -qq
apt-get install -y -qq curl ca-certificates tar >/dev/null

if ! command -v node >/dev/null 2>&1 || [ "$(node -v | sed 's/v\([0-9]*\).*/\1/')" -lt 18 ]; then
  say "3/7" "安装 Node.js 20"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1 || warn "NodeSource 源不可用，改用系统自带的 nodejs"
  apt-get install -y -qq nodejs >/dev/null
fi
command -v node >/dev/null 2>&1 || die "Node.js 安装失败"
NODE_BIN="$(command -v node)"
if ! command -v npm >/dev/null 2>&1; then
  apt-get install -y -qq npm >/dev/null 2>&1 || die "npm 安装失败"
fi

if ! command -v pwsh >/dev/null 2>&1; then
  say "3/7" "安装 PowerShell 7"
  TMPDEB=/tmp/packages-microsoft-prod.deb
  if curl -fsSL "https://packages.microsoft.com/config/ubuntu/${VERSION_ID}/packages-microsoft-prod.deb" -o "$TMPDEB"; then
    dpkg -i "$TMPDEB" >/dev/null 2>&1 || true
    apt-get update -qq
    apt-get install -y -qq powershell >/dev/null || die "PowerShell 安装失败"
  else
    warn "微软源不可用，改用 snap 安装 PowerShell"
    command -v snap >/dev/null 2>&1 || die "请手动安装 PowerShell 7 后重跑本脚本"
    snap install powershell --classic || die "PowerShell 安装失败"
  fi
fi
PWSH_BIN="$(command -v pwsh)"
[ -n "$PWSH_BIN" ] || die "找不到 pwsh"

if ! command -v okx >/dev/null 2>&1; then
  say "3/7" "安装 OKX 交易命令行"
  npm install -g --silent @okx_ai/okx-trade-cli >/dev/null 2>&1 || die "OKX 命令行安装失败，请检查网络"
fi
command -v okx >/dev/null 2>&1 || die "找不到 okx 命令"

# ---------------------------------------------------------------- 3. 放文件
say "4/7" "安装到 $RADAR"
mkdir -p "$RADAR/web" "$RADAR/data-live" "$RADAR/observation-live"
cp -f "$WORK"/src/*.ps1 "$RADAR"/ 2>/dev/null || true
cp -f "$WORK"/src/*.js  "$RADAR"/ 2>/dev/null || true
cp -f "$WORK"/web/server.js "$WORK"/web/index.html "$RADAR/web/"
[ -f "$WORK/VERSION" ] && cp -f "$WORK/VERSION" "$RADAR/VERSION"
if [ ! -f "$RADAR/live-config.json" ]; then
  cp -f "$WORK"/config/live-config.example.json "$RADAR/live-config.json"
  say "4/7" "已写入默认配置（每单 10U / 3 倍 / 每天最多 5 笔 / 回撤 20% 停手）"
else
  say "4/7" "检测到已有 live-config.json，保留不动"
fi
if [ -f "$WORK/disabled-strategies-live.json" ] && [ ! -f "$RADAR/disabled-strategies-live.json" ]; then
  cp -f "$WORK/disabled-strategies-live.json" "$RADAR/disabled-strategies-live.json"
  say "4/7" "已安装出厂禁用策略清单（8 条，作者实测该停的策略）"
fi
chmod 700 "$RADAR" 2>/dev/null || true

# 每个账户一个包装脚本：策略在实盘模式下调用 okx-<profile>
printf '#!/bin/bash\nexec okx --profile %s "$@"\n' "$PROFILE" > "$WRAPPER"
chmod 755 "$WRAPPER"

# 开单闸门：默认先关着，等使用者走完首次设置、点「开始交易」才打开
if [ ! -f "$RADAR/trading-switch-live.json" ]; then
  printf '{\n "allowOpen": false,\n "reason": "installed-not-configured-yet",\n "updatedAt": "%s",\n "updatedBy": "install.sh",\n "cancelPendingOnPause": true,\n "_note": "仅控制是否允许新开仓。首次设置完成后由控制台打开。"\n}\n' "$(date '+%Y-%m-%d %H:%M:%S')" > "$RADAR/trading-switch-live.json"
  say "4/7" "开单已默认暂停，等你完成首次设置后手动开始"
fi

# ---------------------------------------------------------------- 4. 服务
say "5/7" "注册开机自启服务"
cat > /etc/systemd/system/${UNIT}.service <<EOF
[Unit]
Description=OKX Strategy Monitor
After=network.target

[Service]
Type=simple
Environment=OKX_RADAR_HOME=${RADAR}
Environment=OKX_LIVE=1
Environment=OKX_PROFILE=${PROFILE}
Environment=OKX_SUFFIX=-live
Environment=PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/usr/lib/node_modules/.bin
ExecStart=${PWSH_BIN} -NoProfile -File ${RADAR}/strategy-monitor.ps1 -Live -IntervalSec 900
Restart=always
RestartSec=30
OOMPolicy=continue

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/${CONSOLE_UNIT}.service <<EOF
[Unit]
Description=OKX Strategy Console (web)
After=network.target

[Service]
Type=simple
Environment=OKX_RADAR_HOME=${RADAR}
Environment=OKX_PROFILE=${PROFILE}
Environment=OKX_SUFFIX=-live
Environment=CONSOLE_PORT=${PORT}
Environment=MONITOR_UNIT=${UNIT}
ExecStart=${NODE_BIN} ${RADAR}/web/server.js
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now ${UNIT}.service >/dev/null 2>&1
systemctl restart ${UNIT}.service
systemctl enable --now ${CONSOLE_UNIT}.service >/dev/null 2>&1
systemctl restart ${CONSOLE_UNIT}.service

# 控制台密码：服务器是无头机器，使用者没法"在本机打开"设密码，所以这里生成一个并打印出来。
# 本机（SSH 进去 curl）访问不需要密码；从外网访问必须用这个密码。
CONSOLE_PW="$(head -c 16 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 10)"
if [ -n "$CONSOLE_PW" ]; then
  (cd "$RADAR" && "$NODE_BIN" web/server.js --set-password "$CONSOLE_PW" >/dev/null 2>&1) \
    && say "5/7" "已生成控制台密码" || warn "控制台密码生成失败，可稍后手动设置"
fi

# 本机防火墙（云厂商的「安全组」要另外在控制台放行端口）
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q active; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
  say "5/7" "已在本机防火墙放行 ${PORT} 端口"
fi

# ---------------------------------------------------------------- 5. 自检
say "6/7" "自检"
sleep 3
FAIL=0
chk() { if eval "$2" >/dev/null 2>&1; then printf '  ✓ %s\n' "$1"; else printf '  ✗ %s\n' "$1"; FAIL=$((FAIL+1)); fi; }
chk "Node.js $(node -v)" "node -v"
chk "PowerShell $($PWSH_BIN -v)" "$PWSH_BIN -v"
chk "OKX 命令行" "okx --version"
chk "策略服务在运行" "systemctl is-active ${UNIT}"
chk "控制台在运行" "systemctl is-active ${CONSOLE_UNIT}"
chk "控制台端口 ${PORT} 在监听" "ss -ltn | grep -q ':${PORT}'"
chk "控制台页面能打开" "curl -fsS -o /dev/null http://127.0.0.1:${PORT}/"

# 公网 IP（给 OKX 的 IP 白名单用）
PUBIP="$(curl -fsS --max-time 5 https://api.ipify.org 2>/dev/null || true)"

# ---------------------------------------------------------------- 6. 收尾
say "7/7" "完成"
echo
if [ "$FAIL" -eq 0 ]; then
  printf '\033[1;32m安装成功。\033[0m\n'
else
  printf '\033[1;33m有 %s 项自检没通过，请把上面的输出发给作者。\033[0m\n' "$FAIL"
fi
echo "  请在浏览器打开：  http://${PUBIP:-<这台机器的公网IP>}:${PORT}"
echo "  （云服务器的「安全组」需要放行 ${PORT} 端口，否则外网打不开）"
echo
echo "  控制台密码：${CONSOLE_PW:-（未生成，可手动设置）}"
echo "  打开后：用上面的密码登录 → 填 OKX 的 API Key / Secret Key / Passphrase"
echo "          → 选规模 → 勾选风险确认 → 点「开始交易」才会真正下单。"
echo "  忘了密码：rm -f ${RADAR}/console-auth.json && systemctl restart ${CONSOLE_UNIT}"
echo
echo "  IP 白名单：${PUBIP:-（点控制台里的「本机公网 IP」按钮查看）}"
echo "  常用命令："
echo "    看策略日志   journalctl -u ${UNIT} -n 50 --no-pager"
echo "    看控制台日志 journalctl -u ${CONSOLE_UNIT} -n 50 --no-pager"
echo "    停止开新单   systemctl stop ${UNIT}   （已有持仓的止盈止损仍在交易所挂着）"
echo "    重启策略     systemctl restart ${UNIT}"
echo
