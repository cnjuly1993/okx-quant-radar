﻿# 版本记录

## 1.0.0 — 2026-10-05（第一版）

面向「不懂电脑的使用者、一人一套独立部署」的第一版。

**交付内容**
- `install.sh`：一条命令安装（装依赖 → 放文件 → 注册开机自启 → 自检 → 打印网址）。
- `src/`：策略主程序与信号引擎（与作者线上版本同一份，md5 见下方"来源"）。
- `web/`：单页控制台（状态 / 持仓 / 三个档位 / 一键停止开新单 / 导出诊断报告）。
- `config/live-config.example.json`：默认配置（每单 10U、3 倍、每天最多 5 笔、回撤 20% 停手）。

**与作者线上版的差异（刻意为交付做的）**
- **对 `src/` 打的唯一一处补丁**：主程序里默认账户名原本写死为作者自己的账户名，交付版改为 `default`（同时把注释里的作者账户名去掉）。只改默认值，**不改任何交易逻辑**；补丁在"原始文件 md5 与作者线上一致"校验通过之后才应用，且带唯一性断言。
- 清掉了会覆盖使用者设置的个人化项：`perCoin`（ETH/BTC/SNDK 单独 30 倍）、`rules.coinDirOverride`、`rules.manualInsts`。
- `risk.ddHalt` 由 0 改为 **0.2**（开启"权益从起点回撤 20% 自动停止开新单"）。该熔断功能代码里本来就有（`Test-RiskOk`），作者线上一直是关着的。
- `rules.leverage/shortLeverage` 5 → 3；`rules.maxPerDay` 48 → 5；`rules.maxPerRound` 3 → 1；`risk.fixedNotionalUsdt` 100 → 10；`risk.minAvailEqUsdt` 50 → 20。
- 出场保持线上的"纯固定"：止盈 +8% / 止损 −5%，动态保护（dynProtect）关闭。
- 未打包：看板（BI）、文案生成、回测、盘口采集、归因台账等全部内部工具。

**已知边界**
- 只支持 Ubuntu / Debian（脚本里的 `apt-get`）。
- 首次安装后**默认不开单**，必须走完控制台的 3 步设置并点「开始交易」。
- 系统没有"平掉全部持仓"按钮：平仓由交易所侧的止盈止损单自动完成。
- 策略本身没有稳定的正期望（作者实测：19 天 6006 条信号胜率 47.1%，扣费后每笔约 −0.23%），本工具不保证盈利。

**来源（构建时核对）**
- `src/strategy-monitor.ps1` md5 `b383d3031ab7934cc03e1bd58470f0d3`（作者线上 `/opt/okx-radar/strategy-monitor.ps1`）
- `src/indicators.js` md5 `e97a746a9e8dfe114f95b469430d16cb`
- `src/strategies.js` md5 `2cdc3fb4e7ce934e5b9a546f38e04718`
- `src/orderflow.js` md5 `ec0333762b050f38aa4f53694f4bfdc7`
- `src/altcoin-strategies.js` md5 `f615a470fed98f270f260982dcfdc85f`
- `config/live-config.example.json` 由作者线上 `live-config.json`（md5 `c5f7f9a41926e38b1b8d7a143a36a2bb`）派生
## 1.0.0 补丁（2026-10-08）

**控制台设置项扩充（作者要求）**

| 设置 | 可选值 | 说明 |
|---|---|---|
| 每单金额 | 10U / 20U / 50U / 100U / **200U** | 名义价值；选 200U 时系统会自动把 `maxNotionalCap` 抬到 200 |
| 杠杆倍数 | 1x / 2x / 3x / 5x / **10x** | 同时写入 `rules.leverage` 与 `rules.shortLeverage` |
| 每天最多开几笔 | 5 / 10 / 20 / **99** | 99 = 基本不限制（仍受"每币每日上限"约束） |
| **可用金额低于 X 就停止开新单** | 不限制 / 10U / 20U / 50U / 100U | 新增项，写入 `risk.minAvailEqUsdt`；可用保证金低于该值时空单/多单都不再开，已有持仓与止盈止损不受影响 |

**修复（严重）**
- **Windows 版此前完全无法开单**：启动器无控制台启动策略时，PowerShell 5.1 按系统代码页（GBK）解码 Node 引擎输出的 UTF-8 中文，JSON 引号被吃掉 → 每轮全部候选解析失败（实测 `候选 0 / 错误 29~30`）。修复：启动策略前先 `chcp 65001`。修复后实测 `候选 29 / 错误 0`。

**新增**
- 控制台「挂单中（未成交）」卡片：显示未成交限价单（合约/方向/数量/挂单价/来源=策略或手动/挂单时间），持仓 KPI 上标注挂单数。
- 启动器新增 `--interval=<秒>` 参数（默认 **900 = 15 分钟**，与作者线上一致；测试可用 300 = 5 分钟）。

**验证记录**
- 设置项端到端实测：接口保存 200/10x/99/100U → 配置文件写入一致（含 `maxNotionalCap=200`、`shortLeverage=10`）→ 非法值被拒。
- 真实下单实测：`CRV-USDT-SWAP` 做空 255 张 @0.3931，`clOrdId=DSH…`，`state=live`；设置为 10U/3x 后下单记录为 `notionalUsdt=10, lever=3`。
### 2026-10-24 重打包（对齐服务器权威版）

**主程序升级到服务器当前版本**（此前包里是 10-01 的旧版，落后 22 天 / 605 行）：
`strategy-monitor.ps1` md5 `b383d303…`（151,066 B）→ **`ab369d0b…`（171,223 B / 2655 行，服务器 10-23 版）**，因此本版**包含**这期间的以下能力：`反向:X` 参与决策、`forceReverse`（ALT 动量无条件反向）、`chg24Dir` 方向闸门（chg24<3% 只做多 / 3~8% 死区 / ≥8% 只做空）、重启守卫、孤儿算法单清理、归因人工覆盖等。

**配置模板同步重建**：以服务器 `live-config.json`（md5 `27458e6b…`，77 个 rules 键）为基线派生，仅把规模压到保守档：每单 10U / 3x / 每天 5 笔 / 每轮 1 笔 / 持仓上限 10 / 回撤熔断 20% / 可用下限 20U；**功能键全部沿用服务器**（`chg24DirEnabled=true`、`maxChg24ShortPct=20`、`excludeInstruments` 203 条、`forceReverse`、`strategyScore` 13 条、`onlyReverseSource` 3 条）。

**轮次间隔 1800 → 900（15 分钟）**，Linux `install.sh` 与 Windows 启动器默认值同时对齐作者线上。

**Windows 兼容性**：交付包里的主程序补了 **UTF-8 BOM** —— 实测无 BOM 时 Windows PowerShell 5.1 会按系统 ANSI 读中文，产生 77 个语法错误；补 BOM 后本机 5.1 与服务器 pwsh 7 解析均为 **0 错误**。