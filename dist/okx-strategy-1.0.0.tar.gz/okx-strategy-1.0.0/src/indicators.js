// OKX 策略测试 - 技术指标计算引擎
// 用法: node indicators.js <instId> <bar> [limit]
// 输出: 最新K线的所有指标值 (JSON)
// 数据源: OKX 公共行情接口 (无需 API Key)
'use strict';

const http = require('http');
const https = require('https');

// ---------- 数据获取 ----------
// 数据来源：优先从本地 JSON 文件读取（由 okx CLI 拉取），避免直连 OKX 被阻断
const fs = require('fs');
const path = require('path');

function loadCandlesFromFile(file) {
  let raw = fs.readFileSync(file, 'utf8');
  // 去掉 UTF-8 BOM
  if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
  const data = JSON.parse(raw);
  const arr = Array.isArray(data) ? data : (data.data || []);
  return arr.map(r => ({
    ts: Number(r[0] || r.ts), o: Number(r[1] || r.o), h: Number(r[2] || r.h),
    l: Number(r[3] || r.l), c: Number(r[4] || r.c), v: Number(r[5] || r.v)
  })).sort((a, b) => a.ts - b.ts);
}

async function fetchCandles(instId, bar, limit) {
  throw new Error('direct OKX access blocked; use data file instead');
}

// ---------- 指标计算 ----------
function sma(arr, period) {
  const out = [];
  for (let i = 0; i < arr.length; i++) {
    if (i + 1 < period) { out.push(null); continue; }
    let s = 0;
    for (let j = i - period + 1; j <= i; j++) s += arr[j];
    out.push(s / period);
  }
  return out;
}

function ema(arr, period) {
  const out = [];
  const k = 2 / (period + 1);
  let prev = null;
  for (let i = 0; i < arr.length; i++) {
    if (prev === null) {
      // 首值用 SMA 种子
      if (i + 1 < period) { out.push(null); continue; }
      let s = 0;
      for (let j = 0; j < period; j++) s += arr[j];
      prev = s / period;
      out.push(prev);
    } else {
      prev = arr[i] * k + prev * (1 - k);
      out.push(prev);
    }
  }
  return out;
}

// Wilder 平滑 RSI (14)
function rsi(closes, period = 14) {
  const out = [];
  let avgGain = 0, avgLoss = 0;
  for (let i = 0; i < closes.length; i++) {
    if (i === 0) { out.push(null); continue; }
    const chg = closes[i] - closes[i - 1];
    const gain = chg > 0 ? chg : 0;
    const loss = chg < 0 ? -chg : 0;
    if (i < period) { out.push(null); continue; }
    if (i === period) {
      for (let j = 1; j <= period; j++) {
        const c = closes[j] - closes[j - 1];
        avgGain += (c > 0 ? c : 0) / period;
        avgLoss += (c < 0 ? -c : 0) / period;
      }
    } else {
      const c = closes[i] - closes[i - 1];
      avgGain = (avgGain * (period - 1) + (c > 0 ? c : 0)) / period;
      avgLoss = (avgLoss * (period - 1) + (c < 0 ? -c : 0)) / period;
    }
    if (avgLoss === 0) out.push(100);
    else out.push(100 - 100 / (1 + avgGain / avgLoss));
  }
  return out;
}

// MACD (12,26,9)
function macd(closes, fast = 12, slow = 26, signal = 9) {
  const emaFast = ema(closes, fast);
  const emaSlow = ema(closes, slow);
  const dif = closes.map((_, i) => (emaFast[i] !== null && emaSlow[i] !== null) ? emaFast[i] - emaSlow[i] : null);
  // signal = DIF 的 EMA
  const valid = dif.map(d => d === null ? null : d);
  const sigRaw = ema(valid.filter(v => v !== null), signal);
  const sig = [];
  let vi = 0;
  for (let i = 0; i < dif.length; i++) {
    if (dif[i] === null) sig.push(null);
    else { sig.push(sigRaw[vi]); vi++; }
  }
  const hist = dif.map((d, i) => (d !== null && sig[i] !== null) ? d - sig[i] : null);
  return { dif, dea: sig, hist };
}

// Bollinger Bands (20, 2)
function bollinger(closes, period = 20, mult = 2) {
  const mid = sma(closes, period);
  const upper = [], lower = [], width = [];
  for (let i = 0; i < closes.length; i++) {
    if (mid[i] === null) { upper.push(null); lower.push(null); width.push(null); continue; }
    let sd = 0;
    for (let j = i - period + 1; j <= i; j++) sd += Math.pow(closes[j] - mid[i], 2);
    sd = Math.sqrt(sd / period);
    upper.push(mid[i] + mult * sd);
    lower.push(mid[i] - mult * sd);
    width.push((upper[i] - lower[i]) / mid[i]);
  }
  return { mid, upper, lower, width };
}

// ADX (14)
function adx(candles, period = 14) {
  const n = candles.length;
  const plusDM = [], minusDM = [], tr = [], atr = [], plusDI = [], minusDI = [], dx = [];
  // adxOut 必须与 candles 下标一一对齐（长度 = n）：
  // 2026-10-01 修复 —— 原实现主循环对 i<period push 了 period 个 null，回填循环又 push 了 n 个，
  // 导致 adxOut 长度 = n + period，消费者 indicators.js:402 用 i = n-1 读取时，
  // 实际拿到的是「14 根之前」的陈旧 ADX（实盘 ADX>25 门槛因此有约 37~40% 的 K 线判错）。
  const adxOut = new Array(n).fill(null);
  for (let i = 0; i < n; i++) {
    if (i === 0) { plusDM.push(0); minusDM.push(0); tr.push(0); continue; }
    const h = candles[i].h, l = candles[i].l;
    const pH = candles[i - 1].h, pL = candles[i - 1].l, pC = candles[i - 1].c;
    const up = h - pH, down = pL - l;
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    tr.push(Math.max(h - l, Math.abs(h - pC), Math.abs(l - pC)));
  }
  let sTR = 0, sPDM = 0, sMDM = 0;
  for (let i = 1; i <= period; i++) { sTR += tr[i]; sPDM += plusDM[i]; sMDM += minusDM[i]; }
  for (let i = 0; i < n; i++) {
    if (i < period) { atr.push(null); plusDI.push(null); minusDI.push(null); dx.push(null); continue; }
    if (i > period) {
      sTR = sTR - sTR / period + tr[i];
      sPDM = sPDM - sPDM / period + plusDM[i];
      sMDM = sMDM - sMDM / period + minusDM[i];
    }
    const atrV = sTR / period;
    atr.push(atrV);
    plusDI.push(sPDM / sTR * 100);
    minusDI.push(sMDM / sTR * 100);
    const sumDI = plusDI[i] + minusDI[i];
    dx.push(sumDI > 0 ? Math.abs(plusDI[i] - minusDI[i]) / sumDI * 100 : 0);
  }
  // ADX = DX 的 Wilder 平均（按下标回填：adxOut[i] 就是第 i 根的 ADX）
  const validDx = dx.filter(v => v !== null);
  const adxRaw = ema(validDx, period);
  let vi = 0;
  for (let i = 0; i < n; i++) {
    if (dx[i] === null) continue;          // adxOut[i] 保持 null（预热期）
    adxOut[i] = adxRaw[vi]; vi++;
  }
  return { adx: adxOut, plusDI, minusDI, atr };
}

// ATR (14)
function atr(candles, period = 14) {
  const trs = [];
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) { trs.push(candles[i].h - candles[i].l); continue; }
    const h = candles[i].h, l = candles[i].l, pC = candles[i - 1].c;
    trs.push(Math.max(h - l, Math.abs(h - pC), Math.abs(l - pC)));
  }
  return ema(trs, period);
}

// Stochastic (14,3,3)
function stochastic(candles, period = 14, kSmooth = 3, dSmooth = 3) {
  const rawK = [];
  for (let i = 0; i < candles.length; i++) {
    if (i + 1 < period) { rawK.push(null); continue; }
    let hh = -Infinity, ll = Infinity;
    for (let j = i - period + 1; j <= i; j++) {
      hh = Math.max(hh, candles[j].h);
      ll = Math.min(ll, candles[j].l);
    }
    rawK.push(hh === ll ? 50 : (candles[i].c - ll) / (hh - ll) * 100);
  }
  const kRaw = sma(rawK.map(v => v === null ? null : v).filter(v => v !== null), kSmooth);
  const k = []; let vi = 0;
  for (let i = 0; i < rawK.length; i++) {
    if (rawK[i] === null) k.push(null);
    else { k.push(kRaw[vi]); vi++; }
  }
  // D = K 的 SMA（仅对有效 K 值计算，再按位置回填）
  const validK = k.filter(v => v !== null);
  const dRaw = sma(validK, dSmooth);
  const dOut = []; let di = 0;
  for (let i = 0; i < k.length; i++) {
    if (k[i] === null) dOut.push(null);
    else { dOut.push(dRaw[di] === null ? null : dRaw[di]); di++; }
  }
  return { k, d: dOut };
}

// ---------- 新增指标(2026-08-27 阶段1: 只输出观察,不改策略) ----------
function wma(arr, period) {
  const out = [];
  for (let i = 0; i < arr.length; i++) {
    if (i + 1 < period) { out.push(null); continue; }
    let s = 0, wSum = 0;
    for (let j = 0; j < period; j++) { s += arr[i - j] * (period - j); wSum += (period - j); }
    out.push(s / wSum);
  }
  return out;
}

// Hull MA: WMA(2*WMA(n/2) - WMA(n), sqrt(n)) —— 比 EMA 早 2-3 根
function hullMA(arr, period = 9) {
  const half = Math.max(1, Math.floor(period / 2));
  const sqrt = Math.max(1, Math.round(Math.sqrt(period)));
  const w1 = wma(arr, period);
  const w2 = wma(arr, half);
  const raw = arr.map((_, i) => (w1[i] !== null && w2[i] !== null) ? 2 * w2[i] - w1[i] : null);
  const valid = raw.filter(v => v !== null);
  const hRaw = wma(valid, sqrt);
  const out = []; let vi = 0;
  for (let i = 0; i < raw.length; i++) {
    if (raw[i] === null) out.push(null);
    else { out.push(hRaw[vi]); vi++; }
  }
  return out;
}

// Supertrend(10,3): 趋势方向,翻色=转折
function supertrend(candles, period = 10, mult = 3) {
  const n = candles.length;
  const hl2 = candles.map(c => (c.h + c.l) / 2);
  const trs = [];
  for (let i = 0; i < n; i++) {
    if (i === 0) { trs.push(candles[i].h - candles[i].l); continue; }
    trs.push(Math.max(candles[i].h - candles[i].l, Math.abs(candles[i].h - candles[i-1].c), Math.abs(candles[i].l - candles[i-1].c)));
  }
  const atrArr = ema(trs, period);
  const finalUpper = [], finalLower = [], supertrendArr = [], dirArr = [];
  let dir = 1;
  for (let i = 0; i < n; i++) {
    if (atrArr[i] === null) { finalUpper.push(null); finalLower.push(null); supertrendArr.push(null); dirArr.push(null); continue; }
    const mid = hl2[i], band = mult * atrArr[i];
    const bu = mid + band, bl = mid - band;
    if (i === 0 || atrArr[i-1] === null) { finalUpper.push(bu); finalLower.push(bl); dir = 1; }
    else {
      finalUpper.push((bu < finalUpper[i-1]) || (candles[i-1].c > finalUpper[i-1]) ? bu : finalUpper[i-1]);
      finalLower.push((bl > finalLower[i-1]) || (candles[i-1].c < finalLower[i-1]) ? bl : finalLower[i-1]);
      if (supertrendArr[i-1] === finalUpper[i-1]) dir = candles[i].c > finalUpper[i] ? 1 : -1;
      else if (supertrendArr[i-1] === finalLower[i-1]) dir = candles[i].c < finalLower[i] ? -1 : 1;
    }
    supertrendArr.push(dir === 1 ? finalLower[i] : finalUpper[i]);
    dirArr.push(dir);
  }
  return { supertrend: supertrendArr, direction: dirArr };
}

// TTM Squeeze: BB(20,2) 宽度 vs KC(20,1.5) 宽度; squeeze on=收缩, 释放=大趋势
function ttmSqueeze(candles, bbPeriod = 20, bbMult = 2, kcPeriod = 20, kcMult = 1.5) {
  const n = candles.length;
  const closes = candles.map(c => c.c);
  const bb = bollinger(closes, bbPeriod, bbMult);
  const trs = [];
  for (let i = 0; i < n; i++) {
    if (i === 0) { trs.push(candles[i].h - candles[i].l); continue; }
    trs.push(Math.max(candles[i].h - candles[i].l, Math.abs(candles[i].h - candles[i-1].c), Math.abs(candles[i].l - candles[i-1].c)));
  }
  const atrArr = ema(trs, kcPeriod);
  const kcMid = sma(candles.map(c => (c.h + c.l) / 2), kcPeriod);
  const kcUpper = [], kcLower = [], squeezeOn = [], momentum = [];
  for (let i = 0; i < n; i++) {
    if (bb.mid[i] === null || atrArr[i] === null || kcMid[i] === null) { kcUpper.push(null); kcLower.push(null); squeezeOn.push(null); momentum.push(null); continue; }
    kcUpper.push(kcMid[i] + kcMult * atrArr[i]);
    kcLower.push(kcMid[i] - kcMult * atrArr[i]);
    squeezeOn.push(bb.upper[i] < kcUpper[i] && bb.lower[i] > kcLower[i]);
    momentum.push(closes[i] - (kcMid[i] + (kcMid[i-1] !== null ? kcMid[i-1] : kcMid[i])) / 2);
  }
  return { squeezeOn, momentum };
}

// Choppiness Index(14): >61.8 震荡 / <38.2 趋势
function choppiness(candles, period = 14) {
  const n = candles.length;
  const out = [];
  for (let i = 0; i < n; i++) {
    if (i + 1 < period) { out.push(null); continue; }
    let sumTR = 0, hh = -Infinity, ll = Infinity;
    for (let j = i - period + 1; j <= i; j++) {
      const tr = j === 0 ? candles[j].h - candles[j].l : Math.max(candles[j].h - candles[j].l, Math.abs(candles[j].h - candles[j-1].c), Math.abs(candles[j].l - candles[j-1].c));
      sumTR += tr;
      hh = Math.max(hh, candles[j].h);
      ll = Math.min(ll, candles[j].l);
    }
    const range = hh - ll;
    out.push(range > 0 ? 100 * Math.log10(sumTR / range) / Math.log10(period) : 50);
  }
  return out;
}

// VWAP(滚动, lookback=0 用全部数据)
function vwap(candles, lookback = 0) {
  const n = candles.length;
  const start = lookback > 0 ? Math.max(0, n - lookback) : 0;
  let pv = 0, vol = 0;
  for (let i = start; i < n; i++) { pv += candles[i].c * candles[i].v; vol += candles[i].v; }
  return vol > 0 ? pv / vol : null;
}

// Connors RSI: (RSI(3) + streakRSI(2) + pctRank(100)) / 3; <10 超卖 / >90 超买
function connorsRSI(closes, period = 100) {
  const n = closes.length;
  const rsi3 = rsi(closes, 3);
  const streak = [0];
  for (let i = 1; i < n; i++) {
    if (closes[i] > closes[i-1]) streak.push(streak[i-1] > 0 ? streak[i-1] + 1 : 1);
    else if (closes[i] < closes[i-1]) streak.push(streak[i-1] < 0 ? streak[i-1] - 1 : -1);
    else streak.push(0);
  }
  const streakRSI = rsi(streak.map(s => s + 100), 2);
  const pctRank = [];
  for (let i = 0; i < n; i++) {
    if (i + 1 < period) { pctRank.push(null); continue; }
    let below = 0;
    for (let j = i - period + 1; j < i; j++) if (closes[j] < closes[i]) below++;
    pctRank.push(below / (period - 1) * 100);
  }
  const out = [];
  for (let i = 0; i < n; i++) {
    if (rsi3[i] === null || streakRSI[i] === null || pctRank[i] === null) out.push(null);
    else out.push((rsi3[i] + streakRSI[i] + pctRank[i]) / 3);
  }
  return out;
}

// RSI 背离: 近 lookback 根内, 当前价创新高但 RSI 未创新高=顶背离(做空); 反之底背离(做多辅助)
// ===== [ind4-2026-11-04] 对齐官方指标，补 4 个本地缺失的 =====
const IND4 = {
  DON_N: Number(process.env.DON_N || 20),
  KELT_EMA: Number(process.env.KELT_EMA || 20),
  KELT_ATR: Number(process.env.KELT_ATR || 10),
  KELT_MULT: Number(process.env.KELT_MULT || 2),
  HV_N: Number(process.env.HV_N || 20),
  AROON_N: Number(process.env.AROON_N || 14)
};
// 终极振荡器 UO：[uo-2026-11-04] 唯一通过"与现有指标相关性<0.8"检验的新指标
function ultimateOsc(candles, p1 = 7, p2 = 14, p3 = 28) {
  const n = candles.length;
  const out = new Array(n).fill(null);
  const bp = new Array(n).fill(0);
  const tr = new Array(n).fill(0);
  for (let i = 1; i < n; i++) {
    const pc = candles[i - 1].c;
    const lo = Math.min(candles[i].l, pc);
    const hi = Math.max(candles[i].h, pc);
    bp[i] = candles[i].c - lo;
    tr[i] = hi - lo;
  }
  const avg = (win) => {
    const a = new Array(n).fill(null);
    let sb = 0, st = 0;
    for (let i = 1; i < n; i++) {
      sb += bp[i]; st += tr[i];
      if (i > win) { sb -= bp[i - win]; st -= tr[i - win]; }
      if (i >= win) a[i] = st > 0 ? sb / st : null;
    }
    return a;
  };
  const a1 = avg(p1), a2 = avg(p2), a3 = avg(p3);
  for (let i = 0; i < n; i++) {
    if (a1[i] == null || a2[i] == null || a3[i] == null) continue;
    out[i] = 100 * (4 * a1[i] + 2 * a2[i] + a3[i]) / 7;
  }
  return out;
}

// 唐奇安通道：最近 n 根的最高价 / 最低价 / 两者中位
function donchian(candles, n) {
  const out = { upper: [], middle: [], lower: [] };
  for (let i = 0; i < candles.length; i++) {
    if (i < n - 1) { out.upper.push(null); out.middle.push(null); out.lower.push(null); continue; }
    let hi = -Infinity, lo = Infinity;
    for (let j = i - n + 1; j <= i; j++) {
      if (candles[j].h > hi) hi = candles[j].h;
      if (candles[j].l < lo) lo = candles[j].l;
    }
    out.upper.push(hi); out.lower.push(lo); out.middle.push((hi + lo) / 2);
  }
  return out;
}
// 肯特纳通道：中轨 = EMA(收盘, emaN)；上下轨 = 中轨 ± mult × ATR(atrN)
function keltner(candles, emaN, atrN, mult) {
  const closes = candles.map(c => c.c);
  const e = ema(closes, emaN);
  const a = atr(candles, atrN);
  const out = { upper: [], middle: [], lower: [] };
  for (let i = 0; i < candles.length; i++) {
    if (e[i] == null || a[i] == null) { out.upper.push(null); out.middle.push(null); out.lower.push(null); continue; }
    out.middle.push(e[i]); out.upper.push(e[i] + mult * a[i]); out.lower.push(e[i] - mult * a[i]);
  }
  return out;
}
// 历史波动率：最近 n 根对数收益的标准差 × sqrt(365×24) 年化 × 100（百分比）
function histVol(closes, n, barsPerYear) {
  const out = [];
  const ann = Math.sqrt(barsPerYear || (365 * 24));
  for (let i = 0; i < closes.length; i++) {
    if (i < n) { out.push(null); continue; }
    const rets = [];
    for (let j = i - n + 1; j <= i; j++) rets.push(Math.log(closes[j] / closes[j - 1]));
    const m = rets.reduce((s, x) => s + x, 0) / rets.length;
    const v = rets.reduce((s, x) => s + (x - m) * (x - m), 0) / (rets.length - 1);
    out.push(Math.sqrt(v) * ann * 100);
  }
  return out;
}
// 阿隆：up = 100×(n-距最高已过根数)/n；down 同理；osc = up-down
function aroon(candles, n) {
  const out = { up: [], down: [], osc: [] };
  for (let i = 0; i < candles.length; i++) {
    if (i < n) { out.up.push(null); out.down.push(null); out.osc.push(null); continue; }
    let hi = -Infinity, lo = Infinity, hiIdx = i, loIdx = i;
    for (let j = i - n; j <= i; j++) {
      if (candles[j].h >= hi) { hi = candles[j].h; hiIdx = j; }
      if (candles[j].l <= lo) { lo = candles[j].l; loIdx = j; }
    }
    const up = 100 * (n - (i - hiIdx)) / n;
    const dn = 100 * (n - (i - loIdx)) / n;
    out.up.push(up); out.down.push(dn); out.osc.push(up - dn);
  }
  return out;
}
// ===== end [ind4] =====

function rsiDivergence(candles, rsiArr, lookback = 20) {
  const n = candles.length;
  if (n < lookback + 5) return { top: false, bottom: false };
  const i = n - 1;
  const lastClose = candles[i].c;
  const lastRsi = rsiArr[i];
  if (lastRsi === null) return { top: false, bottom: false };
  let maxPx = -Infinity, minPx = Infinity, maxRsi = -Infinity, minRsi = Infinity, maxPxIdx = -1, minPxIdx = -1;
  for (let j = i - lookback; j < i; j++) {
    if (candles[j].c > maxPx) { maxPx = candles[j].c; maxPxIdx = j; }
    if (candles[j].c < minPx) { minPx = candles[j].c; minPxIdx = j; }
  }
  let top = false, bottom = false;
  if (lastClose >= maxPx && maxPxIdx >= 0) {
    const prevRsi = rsiArr[maxPxIdx];
    if (prevRsi !== null && lastRsi < prevRsi - 2) top = true;   // 价新高 + RSI 走弱
  }
  if (lastClose <= minPx && minPxIdx >= 0) {
    const prevRsi = rsiArr[minPxIdx];
    if (prevRsi !== null && lastRsi > prevRsi + 2) bottom = true; // 价新低 + RSI 走强
  }
  return { top, bottom };
}

// ---------- 主流程 ----------
(async () => {
  // 用法: node indicators.js <datafile.json> [bar] [limit]
  // 数据文件由 okx CLI 生成: okx --json market candles BTC-USDT --bar 1H --limit 300 > data.json
  const dataFile = process.argv[2];
  const bar = process.argv[3] || '1H';
  const limit = Number(process.argv[4] || 300);

  let candles;
  if (dataFile && fs.existsSync(dataFile)) {
    candles = loadCandlesFromFile(dataFile);
  } else {
    const instId = dataFile || 'BTC-USDT';
    candles = await fetchCandles(instId, bar, limit);
  }
  if (candles.length < 60) throw new Error('not enough candles: ' + candles.length);
  // [barclose-2026-11-03] 指标只用【已收盘】K 线；price / lastBar 仍取最新一根（可能是正在走的）。
  // 为什么：正在走的那根每 15 分钟就变长一次，同一市场状态会给出不同结论（信号反复）。
  // 为什么价格仍取最新：下单价必须用实时价，否则会对着最多一小时前的旧价挂单。
  const BAR_SEC_MAP = { '15m': 900, '1H': 3600, '4H': 14400, '1D': 86400 };
  const _nowMs = process.env.OKX_BAR_NOW_MS ? Number(process.env.OKX_BAR_NOW_MS) : Date.now();
  const _barSec = BAR_SEC_MAP[bar] || 0;
  const liveCandle = candles[candles.length - 1];
  const _unclosedDropped = !!(_barSec && liveCandle && (liveCandle.ts + _barSec * 1000 > _nowMs));
  const calcCandles = _unclosedDropped ? candles.slice(0, -1) : candles;
  if (calcCandles.length < 60) throw new Error('not enough closed candles: ' + calcCandles.length);
  const closes = calcCandles.map(c => c.c);
  const last = liveCandle;
  const prev = calcCandles[calcCandles.length - 2];

  const rsi14 = rsi(closes, 14);
  const macdRes = macd(closes, 12, 26, 9);
  const bb = bollinger(closes, 20, 2);
  const adxRes = adx(calcCandles, 14);
  const atr14 = atr(calcCandles, 14);
  const stoch = stochastic(calcCandles, 14, 3, 3);
  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);
  const ema200 = ema(closes, 200);
  // 阶段1 新增(只观察)
  const st = supertrend(calcCandles, 10, 3);
  const sq = ttmSqueeze(calcCandles);
  const chop = choppiness(calcCandles, 14);
  const vwapVal = vwap(calcCandles);
  const hma = hullMA(closes, 9);
  const crsi = connorsRSI(closes, 100);
  const rsiDiv = rsiDivergence(calcCandles, rsi14);
  // [ind4-2026-11-04] 新增 4 个指标
  const donRes = donchian(calcCandles, IND4.DON_N);
  const kelRes = keltner(calcCandles, IND4.KELT_EMA, IND4.KELT_ATR, IND4.KELT_MULT);
  const hvRes = histVol(closes, IND4.HV_N, 365);   // [hvfix] 官方按日年化(sqrt(365))，不是 sqrt(365*24)
  const aroonRes = aroon(calcCandles, IND4.AROON_N);
  const uoRes = ultimateOsc(calcCandles, 7, 14, 28);   // [uo-2026-11-04]

  const i = closes.length - 1;
  const pi = closes.length - 2;

  const f = (v, d = 4) => v === null || v === undefined ? null : Number(v.toFixed(d));

  const result = {
    instId: dataFile || 'live', bar,
    lastBar: { ts: last.ts, o: last.o, h: last.h, l: last.l, c: last.c, v: last.v },
    price: last.c,
    changePct24h: null,
    indicators: {
      ema20: f(ema20[i]), ema50: f(ema50[i]), ema200: f(ema200[i]),
      ema20Prev: f(ema20[pi]), ema50Prev: f(ema50[pi]),
      rsi14: f(rsi14[i]), rsi14Prev: f(rsi14[pi]),
      macd: {
        dif: f(macdRes.dif[i]), dea: f(macdRes.dea[i]), hist: f(macdRes.hist[i]),
        difPrev: f(macdRes.dif[pi]), deaPrev: f(macdRes.dea[pi]),
        goldenCross: f(macdRes.dif[pi]) < f(macdRes.dea[pi]) && f(macdRes.dif[i]) > f(macdRes.dea[i]),
        deathCross: f(macdRes.dif[pi]) > f(macdRes.dea[pi]) && f(macdRes.dif[i]) < f(macdRes.dea[i]),
        histRising: macdRes.hist[i] !== null && macdRes.hist[pi] !== null && macdRes.hist[i] > macdRes.hist[pi]
      },
      bollinger: {
        mid: f(bb.mid[i]), upper: f(bb.upper[i]), lower: f(bb.lower[i]), width: f(bb.width[i]),
        nearUpper: bb.upper[i] !== null && last.c >= bb.upper[i] * 0.999,
        nearLower: bb.lower[i] !== null && last.c <= bb.lower[i] * 1.001
      },
      adx: { adx: f(adxRes.adx[i]), plusDI: f(adxRes.plusDI[i]), minusDI: f(adxRes.minusDI[i]),
             trendStrong: adxRes.adx[i] !== null && adxRes.adx[i] > 25,
             bullTrend: adxRes.plusDI[i] !== null && adxRes.minusDI[i] !== null && adxRes.plusDI[i] > adxRes.minusDI[i] },
      atr14: f(atr14[i]),
      stochastic: { k: f(stoch.k[i]), d: f(stoch.d[i]),
                     overbought: stoch.k[i] !== null && stoch.k[i] > 80,
                     oversold: stoch.k[i] !== null && stoch.k[i] < 20 },
      emaTrend: ema20[i] !== null && ema50[i] !== null && ema20[i] > ema50[i] ? 'bull' : 'bear',
      // ---- 阶段1 新增指标(只观察) ----
      supertrend: { value: f(st.supertrend[i]), direction: st.direction[i] === 1 ? 'up' : 'down' },
      ttmSqueeze: { squeezeOn: sq.squeezeOn[i], momentum: f(sq.momentum[i]) },
      choppiness: f(chop[i]),
      vwap: f(vwapVal),
      hullMA: f(hma[i]),
      connorsRSI: f(crsi[i]),
      rsiDivergence: { top: rsiDiv.top, bottom: rsiDiv.bottom },
      // ---- [ind4-2026-11-04] 对齐官方 ----
      donchian: { upper: f(donRes.upper[i]), middle: f(donRes.middle[i]), lower: f(donRes.lower[i]), n: IND4.DON_N },
      keltner: { upper: f(kelRes.upper[i]), middle: f(kelRes.middle[i]), lower: f(kelRes.lower[i]), emaN: IND4.KELT_EMA, atrN: IND4.KELT_ATR, mult: IND4.KELT_MULT },
      hv: f(hvRes[i], 2),
      aroon: { up: f(aroonRes.up[i], 2), down: f(aroonRes.down[i], 2), osc: f(aroonRes.osc[i], 2), n: IND4.AROON_N },
      uo: f(uoRes[i], 2)   // [uo-2026-11-04] 终极振荡器
    }
  };
  console.log(JSON.stringify(result, null, 2));
})().catch(e => { console.error('ERROR: ' + e.message); process.exit(1); });
