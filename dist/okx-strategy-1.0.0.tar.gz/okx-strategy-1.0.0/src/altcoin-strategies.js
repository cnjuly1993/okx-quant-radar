﻿// OKX 山寨币专用策略引擎 - 针对"爆拉→自由落体"特性
// 用法: node altcoin-strategies.js <datafile.json>
// 数据文件: okx --json market candles <instId> --bar 1H --limit 300 > data.json
// 输出: 两个策略的信号 + 推荐的止盈/止损/开仓价位
'use strict';

const fs = require('fs');

function loadCandles(file) {
  let raw = fs.readFileSync(file, 'utf8');
  if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
  const data = JSON.parse(raw);
  let arr = Array.isArray(data) ? data : (data.data || []);
  arr = arr.map(r => (r && r.value && Array.isArray(r.value)) ? r.value : r);
  return arr.map(r => ({
    ts: Number(r[0] || r.ts), o: Number(r[1] || r.o), h: Number(r[2] || r.h),
    l: Number(r[3] || r.l), c: Number(r[4] || r.c), v: Number(r[5] || r.v)
  })).sort((a, b) => a.ts - b.ts);
}

// ---------- 指标 ----------
function smaArr(arr, period) {
  const out = [];
  for (let i = 0; i < arr.length; i++) {
    if (i + 1 < period) { out.push(null); continue; }
    let s = 0; for (let j = i - period + 1; j <= i; j++) s += arr[j];
    out.push(s / period);
  }
  return out;
}
function emaArr(arr, period) {
  const out = []; const k = 2 / (period + 1); let prev = null;
  for (let i = 0; i < arr.length; i++) {
    if (prev === null) {
      if (i + 1 < period) { out.push(null); continue; }
      let s = 0; for (let j = 0; j < period; j++) s += arr[j];
      prev = s / period; out.push(prev);
    } else { prev = arr[i] * k + prev * (1 - k); out.push(prev); }
  }
  return out;
}
function rsiArr(closes, period = 14) {
  const out = []; let avgGain = 0, avgLoss = 0;
  for (let i = 0; i < closes.length; i++) {
    if (i === 0) { out.push(null); continue; }
    const chg = closes[i] - closes[i - 1];
    const gain = chg > 0 ? chg : 0, loss = chg < 0 ? -chg : 0;
    if (i < period) { out.push(null); continue; }
    if (i === period) {
      for (let j = 1; j <= period; j++) {
        const c = closes[j] - closes[j - 1];
        avgGain += (c > 0 ? c : 0) / period; avgLoss += (c < 0 ? -c : 0) / period;
      }
    } else {
      const c = closes[i] - closes[i - 1];
      avgGain = (avgGain * (period - 1) + (c > 0 ? c : 0)) / period;
      avgLoss = (avgLoss * (period - 1) + (c < 0 ? -c : 0)) / period;
    }
    out.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));
  }
  return out;
}
function macdArr(closes, fast = 12, slow = 26, signal = 9) {
  const ef = emaArr(closes, fast), es = emaArr(closes, slow);
  const dif = closes.map((_, i) => (ef[i] !== null && es[i] !== null) ? ef[i] - es[i] : null);
  const valid = dif.filter(v => v !== null);
  const sigRaw = emaArr(valid, signal);
  const dea = []; let vi = 0;
  for (let i = 0; i < dif.length; i++) {
    if (dif[i] === null) dea.push(null); else { dea.push(sigRaw[vi]); vi++; }
  }
  const hist = dif.map((d, i) => (d !== null && dea[i] !== null) ? d - dea[i] : null);
  return { dif, dea, hist };
}
function bbArr(closes, period = 20, mult = 2) {
  const mid = smaArr(closes, period);
  const upper = [], lower = [];
  for (let i = 0; i < closes.length; i++) {
    if (mid[i] === null) { upper.push(null); lower.push(null); continue; }
    let sd = 0;
    for (let j = i - period + 1; j <= i; j++) sd += Math.pow(closes[j] - mid[i], 2);
    sd = Math.sqrt(sd / period);
    upper.push(mid[i] + mult * sd); lower.push(mid[i] - mult * sd);
  }
  return { mid, upper, lower };
}
function adxArr(candles, period = 14) {
  const n = candles.length;
  const plusDM = [], minusDM = [], tr = [], atr = [], plusDI = [], minusDI = [], dx = [], adxOut = [];
  for (let i = 0; i < n; i++) {
    if (i === 0) { plusDM.push(0); minusDM.push(0); tr.push(0); continue; }
    const h = candles[i].h, l = candles[i].l, pH = candles[i - 1].h, pL = candles[i - 1].l, pC = candles[i - 1].c;
    const up = h - pH, down = pL - l;
    plusDM.push(up > down && up > 0 ? up : 0);
    minusDM.push(down > up && down > 0 ? down : 0);
    tr.push(Math.max(h - l, Math.abs(h - pC), Math.abs(l - pC)));
  }
  let sTR = 0, sPDM = 0, sMDM = 0;
  for (let i = 1; i <= period; i++) { sTR += tr[i]; sPDM += plusDM[i]; sMDM += minusDM[i]; }
  for (let i = 0; i < n; i++) {
    if (i < period) { atr.push(null); plusDI.push(null); minusDI.push(null); dx.push(null); adxOut.push(null); continue; }
    if (i > period) {
      sTR = sTR - sTR / period + tr[i]; sPDM = sPDM - sPDM / period + plusDM[i]; sMDM = sMDM - sMDM / period + minusDM[i];
    }
    atr.push(sTR / period);
    plusDI.push(sPDM / sTR * 100); minusDI.push(sMDM / sTR * 100);
    const sumDI = plusDI[i] + minusDI[i];
    dx.push(sumDI > 0 ? Math.abs(plusDI[i] - minusDI[i]) / sumDI * 100 : 0);
  }
  const validDx = dx.filter(v => v !== null);
  const adxRaw = emaArr(validDx, period);
  let vi = 0;
  for (let i = 0; i < n; i++) {
    if (dx[i] === null) adxOut.push(null); else { adxOut.push(adxRaw[vi]); vi++; }
  }
  return { adx: adxOut, plusDI, minusDI, atr };
}

// ============ 策略 A: 动量爆发追踪 (Pump Momentum) ============
// 原理: 山寨币爆拉往往以"放量突破 + 高动量"开始。捕捉启动初期，快进快出。
// 入场: ① 24h 涨幅 > 15%（动量启动） ② 成交量 ≥ 3× 20根均量（放量确认）
//       ③ MACD 金叉或 DIF>DEA（动能确认） ④ RSI 50-80（强势但未极端超买）
// 止盈: +8%（爆拉兑现，不贪）；止损: -6%（硬止损防自由落体）
// 出场: 价格跌破 5 根前高 或 RSI 跌破 50 立即离场
function pumpMomentum(candles) {
  const closes = candles.map(c => c.c);
  const vols = candles.map(c => c.v);
  const rsi = rsiArr(closes, 14);
  const macd = macdArr(closes, 12, 26, 9);
  const n = candles.length;
  const last = candles[n - 1];
  const prev = candles[n - 2];

  // 24h 涨幅（最近 24 根 1H）
  const k24 = Math.min(24, n - 1);
  const open24 = candles[n - 1 - k24].o;
  const chg24 = (last.c - open24) / open24 * 100;

  // 成交量均量（20根）
  const volMA = smaArr(vols, 20);
  const volRatio = volMA[n - 1] ? last.v / volMA[n - 1] : 0;

  // 最近 5 根最高价
  let high5 = -Infinity;
  for (let i = n - 5; i < n - 1; i++) high5 = Math.max(high5, candles[i].h);
  const breakout = last.c > high5;

  const reasons = [];
  let score = 0;
  if (chg24 > 15) { score += 2; reasons.push(`24h涨幅 ${chg24.toFixed(1)}%>15%(+2)`); }
  else reasons.push(`24h涨幅 ${chg24.toFixed(1)}%<15%`);
  if (volRatio >= 3) { score += 2; reasons.push(`量比 ${volRatio.toFixed(1)}x≥3x(+2)`); }
  else reasons.push(`量比 ${volRatio.toFixed(1)}x<3x`);
  if (macd.dif[n - 1] !== null && macd.dea[n - 1] !== null && macd.dif[n - 1] > macd.dea[n - 1]) { score += 1; reasons.push('MACD多头(+1)'); }
  else reasons.push('MACD未多头');
  if (rsi[n - 1] !== null && rsi[n - 1] >= 50 && rsi[n - 1] <= 80) { score += 1; reasons.push(`RSI ${rsi[n - 1].toFixed(0)}强势区(+1)`); }
  else reasons.push(`RSI ${rsi[n - 1] !== null ? rsi[n - 1].toFixed(0) : 'N/A'}不在50-80`);
  if (breakout) { score += 1; reasons.push('突破5根前高(+1)'); }
  else reasons.push('未突破前高');

  const signal = score >= 5 ? 'BUY' : (score <= -3 ? 'AVOID' : 'WATCH');
  return {
    name: '动量爆发追踪',
    signal, score, chg24: chg24.toFixed(1), volRatio: volRatio.toFixed(1), breakout,
    reasons,
    entry: signal === 'BUY' ? last.c : null,
    tp: signal === 'BUY' ? +(last.c * 1.08).toFixed(4) : null,
    sl: signal === 'BUY' ? +(last.c * 0.94).toFixed(4) : null
  };
}

// ============ 策略 C: 爆拉回落做空 (Pump Dump Short) ============
// 原理: 山寨币爆拉后往往自由落体（用户历史：空单几乎不亏）。捕捉爆拉见顶回落做空。
// 入场: ① 24h 涨幅 > 30%（爆拉过） ② 近期从高点回落 > 8%（回落确认）
//       ③ RSI 从超买回落（RSI < 60 且前值 > 70） ④ MACD 死叉或柱转负
// 止盈: -8%（吃回落主段）；止损: +6%（爆拉可能延续，硬止损）
function pumpDumpShort(candles) {
  const closes = candles.map(c => c.c);
  const rsi = rsiArr(closes, 14);
  const macd = macdArr(closes, 12, 26, 9);
  const n = candles.length;
  const last = candles[n - 1];

  const k24 = Math.min(24, n - 1);
  const open24 = candles[n - 1 - k24].o;
  const chg24 = (last.c - open24) / open24 * 100;

  // 近期高点（24 根内最高）
  let high24 = -Infinity;
  for (let i = n - 24; i < n - 1; i++) high24 = Math.max(high24, candles[i].h);
  const dropFromHigh = high24 > 0 ? (high24 - last.c) / high24 * 100 : 0;

  const reasons = [];
  let score = 0;
  if (chg24 > 30) { score += 2; reasons.push(`24h涨幅 ${chg24.toFixed(1)}%>30%(+2)`); }
  else reasons.push(`24h涨幅 ${chg24.toFixed(1)}%<30%`);
  if (dropFromHigh > 8) { score += 2; reasons.push(`自高点回落 ${dropFromHigh.toFixed(1)}%>8%(+2)`); }
  else reasons.push(`自高点回落 ${dropFromHigh.toFixed(1)}%<8%`);
  // RSI 从超买回落
  if (rsi[n-1] !== null && rsi[n-2] !== null && rsi[n-1] < 60 && rsi[n-2] > 70) { score += 1; reasons.push('RSI超买回落(+1)'); }
  else reasons.push('RSI未超买回落');
  // MACD 死叉或负柱
  if (macd.hist[n-1] !== null && macd.hist[n-2] !== null && macd.hist[n-1] < 0 && macd.hist[n-1] < macd.hist[n-2]) { score += 1; reasons.push('MACD负柱扩大(+1)'); }
  else reasons.push('MACD未转弱');

  const signal = score >= 4 ? 'SELL' : 'WATCH';
  return {
    name: '爆拉回落做空',
    signal, score, chg24: chg24.toFixed(1), dropFromHigh: dropFromHigh.toFixed(1),
    reasons,
    entry: signal === 'SELL' ? last.c : null,
    tp: signal === 'SELL' ? +(last.c * 0.92).toFixed(6) : null,
    sl: signal === 'SELL' ? +(last.c * 1.06).toFixed(6) : null
  };
}

// ============ 策略 B: 自由落体反弹 (Freefall Rebound) ============
// 原理: 山寨币爆拉后自由落体，超跌处可能出现技术性反弹。逆势抢反弹，严格止损。
// 入场: ① 24h 跌幅 > 20%（深跌） ② RSI < 30（超卖）
//       ③ 出现止跌迹象: 当前K线收阳 或 长下影线(下影>实体2倍) ④ MACD 柱开始收敛
// 止盈: +6%（反弹有限，快走）；止损: -4%（防继续自由落体）
function freefallRebound(candles) {
  const closes = candles.map(c => c.c);
  const rsi = rsiArr(closes, 14);
  const macd = macdArr(closes, 12, 26, 9);
  const n = candles.length;
  const last = candles[n - 1];

  const k24 = Math.min(24, n - 1);
  const open24 = candles[n - 1 - k24].o;
  const chg24 = (last.c - open24) / open24 * 100;

  // 当前K线形态
  const body = Math.abs(last.c - last.o);
  const lowerShadow = Math.min(last.o, last.c) - last.l;
  const bullish = last.c > last.o;
  const longLowerShadow = body > 0 && lowerShadow > body * 2;

  const reasons = [];
  let score = 0;
  if (chg24 < -20) { score += 2; reasons.push(`24h跌幅 ${chg24.toFixed(1)}%<-20%(+2)`); }
  else reasons.push(`24h跌幅 ${chg24.toFixed(1)}%>-20%`);
  if (rsi[n - 1] !== null && rsi[n - 1] < 30) { score += 2; reasons.push(`RSI ${rsi[n - 1].toFixed(0)}超卖(+2)`); }
  else reasons.push(`RSI ${rsi[n - 1] !== null ? rsi[n - 1].toFixed(0) : 'N/A'}未超卖`);
  if (bullish) { score += 1; reasons.push('当前K线收阳(+1)'); }
  else reasons.push('当前K线收阴');
  if (longLowerShadow) { score += 1; reasons.push('长下影线(+1)'); }
  else reasons.push('无长下影');
  if (macd.hist[n - 1] !== null && macd.hist[n - 2] !== null && macd.hist[n - 1] > macd.hist[n - 2]) { score += 1; reasons.push('MACD柱收敛(+1)'); }
  else reasons.push('MACD柱未收敛');

  const signal = score >= 5 ? 'BUY' : (score <= -3 ? 'AVOID' : 'WATCH');
  return {
    name: '自由落体反弹',
    signal, score, chg24: chg24.toFixed(1),
    reasons,
    entry: signal === 'BUY' ? last.c : null,
    tp: signal === 'BUY' ? +(last.c * 1.06).toFixed(4) : null,
    sl: signal === 'BUY' ? +(last.c * 0.96).toFixed(4) : null
  };
}

// ============ V2 过滤器模块（山寨币策略 V2 深度调研报告） ============
// 通过 child_process 调用 okx CLI 获取辅助数据（资金费率/OI/成交额）
const { execSync } = require('child_process');
const path2 = require('path');
const os = require('os');

function okxCliJson(args) {
  try {
    // 找到 okx.cmd
    let npmPrefix = 'D:\\Program Files\\nodejs';
    try { npmPrefix = execSync('npm.cmd prefix -g', { encoding: 'utf8', shell: 'cmd.exe' }).trim(); } catch (e) {}
    const okx = path2.join(npmPrefix, 'okx.cmd');
    const out = execSync(`"${okx}" --json ${args}`, { encoding: 'utf8', shell: 'cmd.exe', timeout: 20000 });
    if (out.charCodeAt(0) === 0xFEFF) return JSON.parse(out.slice(1));
    return JSON.parse(out);
  } catch (e) { return null; }
}

// V2 过滤器：返回 { pass, filters: [{name, pass, detail}] }
function v2Filters(instId, price, chg24, volBase) {
  const filters = [];
  const swapId = instId.replace(/-USDT$/, '-USDT-SWAP');
  const baseName = instId.replace(/-USDT$/, '');

  // [ctval-2026-11-04] K 线成交量字段是【张数】，必须乘合约面值(ctVal)再乘价格才是 USDT 成交额。
  // 原实现只做了 张数×价格 -> 成交额被低估 1/ctVal 倍（XRP 少 100 倍、DOGE 少 1000 倍），
  // 使「成交额≥500万」这道门槛几乎挡掉所有币，ALT 买入信号长期形同废掉。
  let instMetaCache = null;
  let ctVal = 1;
  try {
    instMetaCache = okxCliJson(`market instruments --instType SWAP --instId ${swapId}`);
    if (instMetaCache && instMetaCache[0] && instMetaCache[0].ctVal) {
      const v = parseFloat(instMetaCache[0].ctVal);
      if (v > 0) ctVal = v;
    }
  } catch (e) {}
  const vol24hUsdt = volBase * ctVal * price;   // 真正的 USDT 成交额

  // 1. 头部山寨/流动性过滤：24h 成交额 ≥ 500 万 USDT
  const liqPass = vol24hUsdt >= 5000000;
  filters.push({ name: '头部山寨(成交额≥500万)', pass: liqPass, detail: `${(vol24hUsdt/10000).toFixed(0)}万U` });

  // 2. 涨幅上限：24h 涨 >80% 不追（动量反转证据）
  const capPass = chg24 <= 80;
  filters.push({ name: '涨幅上限(≤80%)', pass: capPass, detail: `${chg24.toFixed(1)}%` });

  // 3. 资金费率过滤：正费率 >0.1%/8h 禁入（过热）
  let fundingPass = true, fundingDetail = 'N/A';
  const fr = okxCliJson(`market funding-rate ${swapId}`);
  if (fr && fr[0] && fr[0].fundingRate) {
    const fRate = parseFloat(fr[0].fundingRate);
    fundingPass = fRate <= 0.001; // 0.1%
    fundingDetail = (fRate * 100).toFixed(3) + '%/8h';
  }
  filters.push({ name: '资金费率(≤0.1%/8h)', pass: fundingPass, detail: fundingDetail });

  // 4. 假量过滤：Vol/OI > 20x 禁入（正常 3~8x）
  let volOiPass = true, volOiDetail = 'N/A';
  const oi = okxCliJson(`market open-interest --instType SWAP --instId ${swapId}`);
  if (oi && oi[0] && oi[0].oi) {
    // (原此处有一行无意义的死代码：把 OI 乘了 0，已删除)
    // 用现货成交额 / (合约张数×面值×价格) 近似 Vol/OI 比
    const inst = instMetaCache;   // 复用函数开头已取的合约信息
    if (inst && inst[0] && inst[0].ctVal) {
      // ctVal 已在函数开头取得（用于成交额换算），此处复用
      const oiNotional = parseFloat(oi[0].oi) * ctVal * price; // OI 名义价值
      if (oiNotional > 0) {
        const ratio = vol24hUsdt / oiNotional;
        volOiPass = ratio <= 20;
        volOiDetail = ratio.toFixed(1) + 'x';
      }
    }
  }
  filters.push({ name: '假量过滤(Vol/OI≤20x)', pass: volOiPass, detail: volOiDetail });

  const allPass = filters.every(f => f.pass);
  return { pass: allPass, filters };
}

// ============ 主流程 ============
const file = process.argv[2];
if (!file || !fs.existsSync(file)) { console.error('用法: node altcoin-strategies.js <candles.json> [instId]'); process.exit(1); }

const candles = loadCandles(file);
if (candles.length < 60) { console.error('K线不足: ' + candles.length); process.exit(1); }

// [barclose-2026-11-03] 同 indicators.js：策略只用已收盘 K 线，价格仍用最新一根。
// 本脚本的生产调用方 Get-AltSignal 只喂 1H 文件，故默认 1H；可用 argv[4] 覆盖。
const BAR_SEC_MAP = { '15m': 900, '1H': 3600, '4H': 14400, '1D': 86400 };
const _barKey = process.argv[4] || '1H';
const _nowMs = process.env.OKX_BAR_NOW_MS ? Number(process.env.OKX_BAR_NOW_MS) : Date.now();
const _barSec = BAR_SEC_MAP[_barKey] || 0;
const liveCandle = candles[candles.length - 1];
const _unclosedDropped = !!(_barSec && liveCandle && (liveCandle.ts + _barSec * 1000 > _nowMs));
const calcCandles = _unclosedDropped ? candles.slice(0, -1) : candles;

const last = liveCandle;
const a = pumpMomentum(calcCandles);
const b = freefallRebound(calcCandles);
const cStr = pumpDumpShort(calcCandles);
const instId = process.argv[3] || 'unknown';

// V2 过滤器评估（仅当有 BUY 信号时才有意义）
let filterResult = null;
if (a.signal === 'BUY' || b.signal === 'BUY') {
  const chg = parseFloat(a.chg24 || b.chg24 || '0');
  const vol24 = last.v; // 1H 量 × 24 近似（用24根求和更准）
  // 用最近 24 根 K 线成交量合计近似 24h 成交额（USDT 计价需乘价格）
  let volSum = 0;
  for (let i = Math.max(0, calcCandles.length - 24); i < calcCandles.length; i++) volSum += calcCandles[i].v;
  // volSum 是【张数】合计；v2Filters 内部会用 ctVal×价格换算成 USDT 成交额
  filterResult = v2Filters(instId, last.c, chg, volSum);
  if (filterResult.pass) {
    // 过滤通过才保留信号
    if (a.signal === 'BUY') a.signal = 'BUY';
    if (b.signal === 'BUY') b.signal = 'BUY';
  } else {
    a.signal = 'FILTERED'; b.signal = 'FILTERED';
  }
}

const out = {
  instId,
  price: last.c,
  ts: new Date().toISOString(),
  lastBar: { ts: last.ts, o: last.o, h: last.h, l: last.l, c: last.c, v: last.v },
  filters: filterResult ? filterResult.filters : null,
  filterPass: filterResult ? filterResult.pass : null,
  strategies: [a, b, cStr],
  summary: a.signal === 'BUY' || b.signal === 'BUY' || cStr.signal === 'SELL'
    ? '发现信号：买入(动量/反弹) 或 做空(爆拉回落)，按对应策略 TP/SL 执行'
    : (filterResult && !filterResult.pass ? 'V2 过滤拦截：信号被过滤器拒绝' : '暂无明确信号')
};
console.log(JSON.stringify(out, null, 2));
