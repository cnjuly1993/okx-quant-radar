// OKX 策略测试 - 多策略信号引擎
// 用法: node strategies.js <indicators-json-file>
// 输入: indicators.js 的输出文件（或直接传 JSON 字符串路径）
// 输出: 各策略信号 + 综合判断（下一时段看涨/看跌/中性）
'use strict';

const fs = require('fs');

function loadIndicators(file) {
  let raw = fs.readFileSync(file, 'utf8');
  if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
  return JSON.parse(raw);
}

// ============ 策略 1: MACD + RSI + 布林带 三指标共振（Gate 百科经典法） ============
// 看涨: MACD 金叉或 DIF>DEA 且柱体上升 + RSI 在 40-70 强势区（非超买）+ 价格在布林中轨上方
// 看跌: MACD 死叉或 DIF<DEA 且柱体下降 + RSI <50 且下降 + 价格在中轨下方
function strategyConfluence(ind) {
  const m = ind.indicators.macd;
  const r = ind.indicators.rsi14;
  const bb = ind.indicators.bollinger;
  const price = ind.price;
  let score = 0;
  const reasons = [];

  // MACD 部分
  if (m.goldenCross) { score += 3; reasons.push('MACD 金叉(+3)'); }
  else if (m.deathCross) { score -= 3; reasons.push('MACD 死叉(-3)'); }
  else if (m.dif > m.dea) { score += 1; reasons.push('MACD 多头排列(+1)'); }
  else { score -= 1; reasons.push('MACD 空头排列(-1)'); }
  if (m.histRising) { score += 1; reasons.push('MACD 柱放大(+1)'); }

  // RSI 部分
  if (r >= 40 && r <= 70) { score += 1; reasons.push(`RSI ${r.toFixed(0)} 强势区(+1)`); }
  else if (r > 70) { score -= 1; reasons.push(`RSI ${r.toFixed(0)} 超买(-1)`); }
  else if (r < 40) { score -= 1; reasons.push(`RSI ${r.toFixed(0)} 弱势(-1)`); }

  // 布林带部分
  if (price > bb.mid) { score += 1; reasons.push('价格>中轨(+1)'); }
  else { score -= 1; reasons.push('价格<中轨(-1)'); }

  const signal = score >= 3 ? 'LONG' : (score <= -3 ? 'SHORT' : 'NEUTRAL');
  return { name: 'MACD+RSI+布林带共振', signal, score, reasons };
}

// ============ 策略 2: EMA 交叉 + ADX 趋势强度过滤 ============
// 看涨: EMA20>EMA50 + ADX>25(趋势有效) + +DI>-DI
// 看跌: EMA20<EMA50 + ADX>25 + -DI>+DI
// 震荡(ADX<25): 中性，不交易
function strategyEmaAdx(ind) {
  const e = ind.indicators;
  const emaTrend = e.emaTrend;
  const adx = e.adx;
  let score = 0;
  const reasons = [];

  if (!adx.trendStrong) { reasons.push(`ADX ${adx.adx?.toFixed(1)}<25 震荡市，观望`); return { name: 'EMA+ADX趋势过滤', signal: 'NEUTRAL', score: 0, reasons }; }

  if (emaTrend === 'bull') { score += 2; reasons.push('EMA20>EMA50 多头(+2)'); }
  else { score -= 2; reasons.push('EMA20<EMA50 空头(-2)'); }
  if (adx.bullTrend) { score += 1; reasons.push('+DI>-DI 多头主导(+1)'); }
  else { score -= 1; reasons.push('-DI>+DI 空头主导(-1)'); }

  const signal = score >= 2 ? 'LONG' : (score <= -2 ? 'SHORT' : 'NEUTRAL');
  return { name: 'EMA交叉+ADX过滤', signal, score, reasons };
}

// ============ 策略 3: RSI 超卖反弹 + 布林带下轨 + MACD 底部动能 ============
// 看涨(抄底): RSI<30(或从超卖回升) + 价格触及/跌破下轨 + MACD 柱底背离或开始回升
// 看跌(逃顶): RSI>70 + 价格触及/突破上轨 + MACD 动能衰减
function strategyMeanRev(ind) {
  const r = ind.indicators.rsi14;
  const bb = ind.indicators.bollinger;
  const m = ind.indicators.macd;
  const price = ind.price;
  let score = 0;
  const reasons = [];

  if (r < 30 && bb.nearLower) { score += 3; reasons.push(`RSI ${r.toFixed(0)} 超卖+触下轨(+3)`); }
  else if (r > 70 && bb.nearUpper) { score -= 3; reasons.push(`RSI ${r.toFixed(0)} 超买+触上轨(-3)`); }
  else if (r < 40) { score += 1; reasons.push(`RSI ${r.toFixed(0)} 偏超卖(+1)`); }
  else if (r > 60) { score -= 1; reasons.push(`RSI ${r.toFixed(0)} 偏超买(-1)`); }

  // MACD 动能配合
  if (m.hist < 0 && m.histRising) { score += 1; reasons.push('MACD 负柱收敛(+1)'); }
  else if (m.hist > 0 && !m.histRising) { score -= 1; reasons.push('MACD 正柱衰减(-1)'); }

  const signal = score >= 3 ? 'LONG' : (score <= -3 ? 'SHORT' : 'NEUTRAL');
  return { name: 'RSI超卖反弹+布林带', signal, score, reasons };
}

// ============ 策略 4: 随机指标 + MACD 双确认（趋势延续） ============
// 看涨: K>D 金叉 + MACD DIF>DEA + 未超买(<80)
// 看跌: K<D 死叉 + MACD DIF<DEA + 未超卖(>20)
function strategyStochMacd(ind) {
  const s = ind.indicators.stochastic;
  const m = ind.indicators.macd;
  let score = 0;
  const reasons = [];

  if (s.k !== null && s.d !== null) {
    if (s.k > s.d && s.k < 80) { score += 2; reasons.push(`Stoch K${s.k.toFixed(0)}>D 金叉(+2)`); }
    else if (s.k < s.d && s.k > 20) { score -= 2; reasons.push(`Stoch K${s.k.toFixed(0)}<D 死叉(-2)`); }
    else reasons.push('Stoch 超买/超卖区，信号弱');
  }
  if (m.dif > m.dea) { score += 1; reasons.push('MACD 多头(+1)'); }
  else { score -= 1; reasons.push('MACD 空头(-1)'); }

  const signal = score >= 2 ? 'LONG' : (score <= -2 ? 'SHORT' : 'NEUTRAL');
  return { name: 'Stoch+MACD双确认', signal, score, reasons };
}

// ============ 综合判定 ============
function aggregate(results) {
  let longVotes = 0, shortVotes = 0, neutralVotes = 0, totalScore = 0;
  for (const r of results) {
    if (r.signal === 'LONG') { longVotes++; totalScore += r.score; }
    else if (r.signal === 'SHORT') { shortVotes++; totalScore += r.score; }
    else neutralVotes++;
  }
  let consensus;
  if (longVotes > shortVotes && longVotes >= 2) consensus = 'LONG';
  else if (shortVotes > longVotes && shortVotes >= 2) consensus = 'SHORT';
  else consensus = 'NEUTRAL';

  return {
    consensus,
    votes: { LONG: longVotes, SHORT: shortVotes, NEUTRAL: neutralVotes },
    totalScore,
    advice: consensus === 'LONG' ? '下一时段大概率上涨，可考虑做多/持有' :
            consensus === 'SHORT' ? '下一时段大概率下跌，可考虑做空/减仓' :
            '方向不明，观望等待信号'
  };
}

// ============ 主流程 ============
const file = process.argv[2];
if (!file || !fs.existsSync(file)) { console.error('用法: node strategies.js <indicators-json-file>'); process.exit(1); }

const ind = loadIndicators(file);
const strategies = [
  strategyConfluence(ind),
  strategyEmaAdx(ind),
  strategyMeanRev(ind),
  strategyStochMacd(ind)
];

const agg = aggregate(strategies);

const out = {
  instId: ind.instId, bar: ind.bar, price: ind.price,
  timestamp: new Date().toISOString(),
  consensus: agg.consensus,
  advice: agg.advice,
  votes: agg.votes,
  totalScore: agg.totalScore,
  strategies: strategies,
  // 透传新指标(2026-08-27 阶段1): 供 monitor 组合逻辑使用
  indicators: {
    choppiness: ind.indicators ? ind.indicators.choppiness : null,
    ttmSqueeze: ind.indicators ? ind.indicators.ttmSqueeze : null,
    supertrend: ind.indicators ? ind.indicators.supertrend : null,
    rsiDivergence: ind.indicators ? ind.indicators.rsiDivergence : null
  }
};
console.log(JSON.stringify(out, null, 2));
