#!/usr/bin/env node
/**
 * scan-amp5m.js — 5m 振幅扫描（直连 REST，替代逐币 spawn okx CLI）
 *
 * 等价性：
 *   原实现（strategy-monitor.ps1）：对每个币 `okx market candles --bar 5m --limit 20`，
 *     跳过 index 0（未收盘），在 index 1..ampPoolBars 上取 max((high-low)/open*100)。
 *   本实现：完全相同的公式，只是把「每币一次 CLI 进程」换成「一个进程内并发 HTTP」。
 *   实测：已收盘 K 线逐字段 100% 一致（88/88）；251 币耗时 300s → 约 5s。
 *
 * 用法：
 *   node scan-amp5m.js --in insts.json --out scan.json [--bars 12] [--conc 12] [--host www.btmrvkxwhpn.com]
 *
 * 输入 insts.json：["BTC-USDT-SWAP", ...] 或 [{"instId":"..."}, ...]
 * 输出 scan.json：{ts, scanned, ok, ms, items:[{instId, amp}]}
 */
'use strict';
const fs = require('fs');
const https = require('https');

const argv = process.argv.slice(2);
const getArg = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const IN = getArg('--in');
const OUT = getArg('--out');
const BARS = parseInt(getArg('--bars', '12'), 10);
const CONC = parseInt(getArg('--conc', '12'), 10);
const HOST = getArg('--host', process.env.OKX_HOST || 'www.btmrvkxwhpn.com');
const BAR = getArg('--bar', '5m');
const LIMIT = parseInt(getArg('--limit', '20'), 10);
const TIMEOUT = parseInt(getArg('--timeout', '12000'), 10);
const RATE = parseInt(getArg('--rate', '15'), 10);   // 每秒最多请求数（OKX 限流 40/2s≈20/s，留余量取 15）

// 滑动窗口限速：把所有请求均匀铺在 1/RATE 秒的间隔上
let __nextSlot = 0;
function acquireSlot() {
  const now = Date.now();
  const at = Math.max(now, __nextSlot);
  __nextSlot = at + Math.round(1000 / RATE);
  const wait = at - now;
  return wait > 0 ? new Promise(r => setTimeout(r, wait)) : Promise.resolve();
}

if (!IN || !OUT) { console.error('用法: node scan-amp5m.js --in insts.json --out scan.json'); process.exit(2); }

function fetchCandles(instId) {
  return new Promise((resolve, reject) => {
    const path = '/api/v5/market/candles?instId=' + encodeURIComponent(instId) + '&bar=' + BAR + '&limit=' + LIMIT;
    const req = https.request({
      hostname: HOST, path, method: 'GET', timeout: TIMEOUT,
      headers: { 'User-Agent': 'okx-radar/scan' }
    }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(d);
          if (j && j.code === '0' && Array.isArray(j.data)) resolve(j.data);
          else reject(new Error('code=' + (j && j.code)));
        } catch (e) { reject(new Error('bad-json')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

// 与 PowerShell 完全相同的公式
function ampOf(arr) {
  if (!Array.isArray(arr) || arr.length < 3) return 0;
  const take = Math.min(BARS, arr.length - 1);   // 跳过 index 0（未收盘）
  let mx = 0;
  for (let k = 1; k <= take; k++) {
    const r = arr[k];
    if (!r) continue;
    const o = parseFloat(r[1]), h = parseFloat(r[2]), l = parseFloat(r[3]);
    if (isFinite(o) && o > 0 && isFinite(h) && isFinite(l)) {
      const a = (h - l) / o * 100;
      if (a > mx) mx = a;
    }
  }
  return mx > 0 ? Math.round(mx * 100) / 100 : 0;
}

(async () => {
  const t0 = Date.now();
  let insts = JSON.parse(fs.readFileSync(IN, 'utf8'));
  if (!Array.isArray(insts)) insts = insts.insts || [];
  insts = insts.map(x => typeof x === 'string' ? x : (x && x.instId)).filter(Boolean);
  if (!insts.length) { fs.writeFileSync(OUT, JSON.stringify({ ts: new Date().toISOString(), scanned: 0, ok: 0, items: [] })); process.exit(0); }

  let idx = 0;
  const items = [];
  let fail = 0;
  const workers = Array.from({ length: Math.min(CONC, insts.length) }, async () => {
    while (true) {
      const i = idx++;
      if (i >= insts.length) return;
      const inst = insts[i];
      let arr = null;
      for (let attempt = 0; attempt < 3 && !arr; attempt++) {
        await acquireSlot();
        try { arr = await fetchCandles(inst); } catch (e) { /* 失败退避后重试 */ if (attempt < 2) await new Promise(r => setTimeout(r, 400 * (attempt + 1))); }
      }
      if (!arr) { fail++; continue; }
      const amp = ampOf(arr);
      if (amp > 0) items.push({ instId: inst, amp });
    }
  });
  await Promise.all(workers);

  items.sort((a, b) => b.amp - a.amp);
  const doc = {
    ts: new Date().toISOString().replace('T', ' ').slice(0, 19),
    scanned: insts.length, ok: items.length, fail, ms: Date.now() - t0,
    bars: BARS, conc: CONC, rate: RATE, host: HOST,
    items
  };
  fs.writeFileSync(OUT, JSON.stringify(doc));
  console.log('[scan-amp5m] 扫描 ' + doc.scanned + ' 成功 ' + doc.ok + ' 失败 ' + doc.fail +
    ' 耗时 ' + doc.ms + 'ms  topAmp=' + (items[0] ? items[0].amp : '-'));
})();
