#!/usr/bin/env node
/**
 * fetch-candles.js — 批量预取 K 线（直连 REST，替代逐币 spawn okx CLI）
 *
 * 用途：一轮里要拉「N 个候选 × 3 个周期」的 K 线（现状 240 次 CLI 启动），
 *       改成 1 个进程内并发 HTTP，写入与 Get-BarSignal 完全一致的路径
 *       `<dataDir>/<instId>_<bar>.json`，让 Get-BarSignal 直接读缓存。
 *
 * 等价性：写入内容 = OKX /api/v5/market/candles 原始 data 数组，与 CLI `--json` 输出同源。
 *
 * 用法：
 *   node fetch-candles.js --in pairs.json --dir /opt/okx-radar/data
 *      pairs.json: [{"instId":"BTC-USDT-SWAP","bar":"1H","limit":300}, ...]
 *   可选 --out 结果摘要 --rate 15 --conc 8 --timeout 15000
 */
'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');

const argv = process.argv.slice(2);
const getArg = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const IN = getArg('--in');
const DIR = getArg('--dir', '/opt/okx-radar/data');
const OUT = getArg('--out');
const RATE = parseInt(getArg('--rate', '15'), 10);
const CONC = parseInt(getArg('--conc', '8'), 10);
const HOST = getArg('--host', process.env.OKX_HOST || 'www.btmrvkxwhpn.com');
const TIMEOUT = parseInt(getArg('--timeout', '15000'), 10);

if (!IN) { console.error('用法: node fetch-candles.js --in pairs.json --dir <dataDir>'); process.exit(2); }

let __nextSlot = 0;
function acquireSlot() {
  const now = Date.now();
  const at = Math.max(now, __nextSlot);
  __nextSlot = at + Math.round(1000 / RATE);
  const wait = at - now;
  return wait > 0 ? new Promise(r => setTimeout(r, wait)) : Promise.resolve();
}

function fetchOne(instId, bar, limit) {
  return new Promise((resolve, reject) => {
    const p = '/api/v5/market/candles?instId=' + encodeURIComponent(instId) + '&bar=' + encodeURIComponent(bar) + '&limit=' + limit;
    const req = https.request({ hostname: HOST, path: p, method: 'GET', timeout: TIMEOUT,
      headers: { 'User-Agent': 'okx-radar/fetch' } }, (res) => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(d);
          if (j && j.code === '0' && Array.isArray(j.data)) resolve(j.data);
          else reject(new Error('code=' + (j && j.code)));
        } catch (e) { reject(new Error('bad-json')); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    req.end();
  });
}

(async () => {
  const t0 = Date.now();
  let pairs = JSON.parse(fs.readFileSync(IN, 'utf8'));
  if (!Array.isArray(pairs)) pairs = pairs.pairs || [];
  // 去重（同 inst+bar+limit 只拉一次）
  const seen = new Set(); const list = [];
  for (const p of pairs) {
    if (!p || !p.instId || !p.bar) continue;
    const key = p.instId + '|' + p.bar + '|' + (p.limit || 300);
    if (seen.has(key)) continue;
    seen.add(key);
    list.push({ instId: p.instId, bar: p.bar, limit: parseInt(p.limit || 300, 10) });
  }
  if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

  let idx = 0, ok = 0, fail = 0;
  const failed = [];
  const workers = Array.from({ length: Math.min(CONC, list.length) }, async () => {
    while (true) {
      const i = idx++;
      if (i >= list.length) return;
      const { instId, bar, limit } = list[i];
      let data = null;
      for (let attempt = 0; attempt < 3 && !data; attempt++) {
        await acquireSlot();
        try { data = await fetchOne(instId, bar, limit); }
        catch (e) { if (attempt < 2) await new Promise(r => setTimeout(r, 400 * (attempt + 1))); }
      }
      if (!data) { fail++; failed.push(instId + '_' + bar); continue; }
      const file = path.join(DIR, instId + '_' + bar + '.json');
      try { fs.writeFileSync(file, JSON.stringify(data)); ok++; }
      catch (e) { fail++; failed.push(instId + '_' + bar + '(write)'); }
    }
  });
  await Promise.all(workers);

  const summary = {
    ts: new Date().toISOString().replace('T', ' ').slice(0, 19),
    requested: pairs.length, unique: list.length, ok, fail, ms: Date.now() - t0,
    rate: RATE, conc: CONC, host: HOST, failed: failed.slice(0, 20)
  };
  if (OUT) { try { fs.writeFileSync(OUT, JSON.stringify(summary)); } catch (e) {} }
  console.log('[fetch-candles] 去重后 ' + list.length + ' 组，成功 ' + ok + ' 失败 ' + fail + '，耗时 ' + summary.ms + 'ms');
})();
