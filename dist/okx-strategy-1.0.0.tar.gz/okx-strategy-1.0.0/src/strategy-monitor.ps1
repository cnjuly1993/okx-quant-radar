﻿# 策略监控+执行 V3 - 候选池深析 + 交易池自动开仓（合并版）
# 用法: powershell -File strategy-monitor.ps1 [-Once] [-IntervalSec 3600] [-Live]
# 轮次间隔: 2026-10-01 用户要求由 15 分钟改为 1 小时(按小时线收盘触发)。systemd unit 里显式传 -IntervalSec。
param(
  [switch]$Once,
  [int]$IntervalSec = 3600,
  [switch]$Live,
  # 只读探针参数：仅供 test/snapshot.js 做金样本回归，正常运行时全部为空
  [string]$ProbeFunc = '',
  [string]$ProbeInst = '',
  [string]$ProbeDataDir = ''
)

$ErrorActionPreference = 'Continue'
# 多盘模式: 模拟盘(默认) / 实盘(-Live 或 OKX_LIVE=1)。多实盘账户用 OKX_PROFILE(profile 名) + OKX_SUFFIX(数据后缀)区分
$isLive = $Live -or ($env:OKX_LIVE -eq '1')
$liveProfile = if($env:OKX_PROFILE){ $env:OKX_PROFILE } else { 'default' }
$suffix = if($env:OKX_SUFFIX){ $env:OKX_SUFFIX } elseif($isLive){ '-live' } else { '' }
# 跨平台：服务器用 OKX_RADAR_HOME(/opt/okx-radar)，本地用脚本所在目录
$baseDir = if($env:OKX_RADAR_HOME){ $env:OKX_RADAR_HOME } elseif($PSScriptRoot){ $PSScriptRoot } else { (Get-Location).Path }
$dataDir = Join-Path $baseDir ('data' + $suffix)
$strategyLog = Join-Path $baseDir ('strategy-signals' + $suffix + '.log')
$tradeLog = Join-Path $baseDir ('strategy-trades' + $suffix + '.log')
$triedFile = Join-Path $baseDir ('strategy-tried' + $suffix + '.json')
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null

# 跨平台：Windows 用 npm/okx.cmd，Linux 用 PATH 上的 okx
$npmPrefix = (& npm prefix -g 2>$null | Select-Object -First 1)
if(-not $npmPrefix){ $npmPrefix = if($env:OS -eq 'Windows_NT'){ 'D:\Program Files\nodejs' } else { '/usr' } }
$npmPrefix = $npmPrefix.Trim()
$okxPath = if($env:OS -eq 'Windows_NT'){ Join-Path $npmPrefix 'okx.cmd' } else { 'okx' }
# 实盘模式用包装脚本(服务器上 exec okx --profile <name> "$@"), 避免 PowerShell 数组调用问题; 多账户: okx-<profile> ...
$okx = if($isLive){ ("okx-" + $liveProfile) } else { $okxPath }
$nodeExe = 'node'

# 配置: 模拟盘 strategy-config.json / 实盘 live-config.json
$cfg = $null
# 配置: 模拟盘 strategy-config.json / 实盘按 profile 区分(share 账户 -> share-config.json, 其余 live-config.json)
$cfgName = if($isLive){
  if($liveProfile -eq 'share'){ 'share-config.json' } else { 'live-config.json' }
} else { 'strategy-config.json' }
$configFile = Join-Path $baseDir $cfgName
if(Test-Path $configFile){ try { $cfg = Get-Content $configFile -Raw -Encoding UTF8 | ConvertFrom-Json } catch {} }
# 反向排除白名单: config rules.reverseExclude 里的策略永不参与动态/每日反向(只走正向), 2026-09-06 加(组合B:RSI 正反向胜率矛盾, 反向亏)
$script:reverseExclude = @()
try { if($cfg -and $cfg.rules -and $cfg.rules.reverseExclude){ $script:reverseExclude = @($cfg.rules.reverseExclude) } } catch {}
# 仅反向信号源(2026-09-06): 这些策略只当动态反向的信号源, 正向方向不开仓(信号照常记录并进反向判定)
$script:onlyReverseSource = @()
try { if($cfg -and $cfg.rules -and $cfg.rules.onlyReverseSource){ $script:onlyReverseSource = @($cfg.rules.onlyReverseSource) } } catch {}

# ===== AI Builder Code (2026-11-03) =====
# OKX AI Builder Program attribution. Empty Code = no injection (behavior identical to before).
# Priority: env OKX_AI_BUILDER_CODE > config builder.aiBuilderCode
# Official guide: CLI must use --aiBuilderCode (NOT tag / NOT --ai-builder-code).
$script:aiBuilderCode = ''
try {
  $bcRaw = $env:OKX_AI_BUILDER_CODE
  if(-not $bcRaw -and $cfg -and $cfg.builder -and $cfg.builder.aiBuilderCode){ $bcRaw = [string]$cfg.builder.aiBuilderCode }
  if($bcRaw){
    $bcRaw = ([string]$bcRaw).Trim()
    if($bcRaw -match '^[A-Za-z0-9]{1,16}$'){ $script:aiBuilderCode = $bcRaw }
    else { Write-Host ("[aiBuilder][warn] invalid code (need 1-16 alnum), ignored: " + $bcRaw) }
  }
} catch {}
# Fail-safe: if installed CLI lacks --aiBuilderCode, skip injection (lose attribution) instead of breaking orders.
$aiBcArgs = @()
if($script:aiBuilderCode){
  $bcOk = $false
  try { $bcHelp = (& $okx swap place --help 2>&1 | Out-String); if($bcHelp -match 'aiBuilderCode'){ $bcOk = $true } } catch {}
  if($bcOk){ $aiBcArgs = @('--aiBuilderCode', $script:aiBuilderCode); Write-Host ('[aiBuilder] attribution ON: ' + $script:aiBuilderCode) }
  else { Write-Host "[aiBuilder][warn] installed okx CLI lacks --aiBuilderCode; attribution skipped (trading unaffected). Upgrade: npm i -g @okx_ai/okx-trade-cli" }
}
# ===== end AI Builder Code (2026-11-03) =====

# 强制反向(2026-10-14 用户要求: ALT:动量爆发追踪 改做空): config.rules.forceReverse 里的策略**无条件反向**
#   与 reverseExclude 相反; 与动态反向集(reverseSet, 按胜率<阈值)独立 —— 即使胜率回升也保持反向。
$script:forceReverse = @()
try { if($cfg -and $cfg.rules -and $cfg.rules.forceReverse){ $script:forceReverse = @($cfg.rules.forceReverse) } } catch {}
# 暴涨禁空豁免(2026-10-14 用户要求, ALT 改做空配套): config.rules.chg24ShortExemptStrategies 里的策略
#   不受 chg24>maxChg24ShortPct 禁空限制。依据: 原始回测自己记着"chg24>12 的空单均收益 +0.41%(n=682) 是赚钱那档,
#   chg24<=12 的 -0.72%(n=2609) 才是亏源" ⇒ 该闸门拦掉的恰是赚钱档; 且 ALT 动量策略天生只抓暴涨币(实测 67% 信号 chg24>12%)。
$script:chg24ShortExempt = @()
try { if($cfg -and $cfg.rules -and $cfg.rules.chg24ShortExemptStrategies){ $script:chg24ShortExempt = @($cfg.rules.chg24ShortExemptStrategies) } } catch {}
# 白名单保护(2026-09-10 用户规则): config.rules.whitelist 里的策略永不被"每日自动禁用"覆盖(否则白名单会被慢慢掏空)
$script:strategyWhitelist = @()
try { if($cfg -and $cfg.rules -and $cfg.rules.whitelist){ $script:strategyWhitelist = @($cfg.rules.whitelist) } } catch {}
$totalEquity = if($cfg){ [double]$cfg.risk.totalEquity } else { 100 }
$perTradeRiskPct = if($cfg){ [double]$cfg.risk.perTradeRiskPct } else { 0.03 }
$mainTpPct = if($cfg){ [double]$cfg.risk.mainTpPct } else { 0.12 }
$mainSlPct = if($cfg){ [double]$cfg.risk.mainSlPct } else { 0.05 }
$maxOpenPositions = if($cfg -and $cfg.rules -and $cfg.rules.maxOpenPositions){ [int]$cfg.rules.maxOpenPositions } elseif($cfg -and $cfg.risk -and $cfg.risk.maxOpenPositions){ [int]$cfg.risk.maxOpenPositions } else { 2 }
$maxPerDay = if($cfg -and $cfg.rules -and $cfg.rules.maxPerDay){ [int]$cfg.rules.maxPerDay } elseif($cfg -and $cfg.risk -and $cfg.risk.maxPerDay){ [int]$cfg.risk.maxPerDay } else { 5 }
$ddHalt = if($cfg){ [double]$cfg.risk.ddHalt } else { 0.20 }
$shortTrailRatio = if($cfg){ [double]$cfg.risk.shortTrailingStopRatio } else { 0.01 }
# 移动止损开关(risk.enableTrail, 默认开; 2026-09-05 复盘: 4% trail 频繁扫掉均值回归单 → 实盘配置已关, 仅 OCO+盈亏平衡+时间止损)
$enableTrail = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.enableTrail){ [bool]$cfg.risk.enableTrail } else { $true }
$longLever = if($cfg -and $cfg.rules){ [int]$cfg.rules.leverage } else { 15 }
$shortLever = if($cfg -and $cfg.rules){ [int]$cfg.rules.shortLeverage } else { 10 }
# per-coin 覆盖配置(杠杆/移动止损按币种差异化;转 hashtable 支持动态键)
$perCoin = @{}
if($cfg -and $cfg.perCoin){ foreach($p in $cfg.perCoin.PSObject.Properties){ $perCoin[$p.Name] = $p.Value } }
# BTC 方向过滤开关(开仓前确认 BTC 1H 趋势,减少假信号)
$btcFilterOn = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.btcFilter){ [bool]$cfg.rules.btcFilter } else { $true }
$script:btcTrend = 'NEUTRAL'
# [oiq-2026-11-04] 持仓量×价格四象限过滤：价跌OI增=空头增仓(别接飞刀)、价涨OI增=多头增仓(别逆势做空)
# 默认关闭(只记录不拦截)。开启后按 oiQuadrantBlockLong / oiQuadrantBlockShort 拦掉对应象限。
$oiQuadOn = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.oiQuadrantOn){ [bool]$cfg.rules.oiQuadrantOn } else { $false }
$oiQuadBar = if($cfg -and $cfg.rules -and $cfg.rules.oiQuadrantBar){ [string]$cfg.rules.oiQuadrantBar } else { '1H' }
$oiQuadBlockLong = if($cfg -and $cfg.rules -and $cfg.rules.oiQuadrantBlockLong){ @($cfg.rules.oiQuadrantBlockLong) } else { @('跌增') }
$oiQuadBlockShort = if($cfg -and $cfg.rules -and $cfg.rules.oiQuadrantBlockShort){ @($cfg.rules.oiQuadrantBlockShort) } else { @('涨增') }
$script:oiQuad = $null
$script:oiQuadHit = 0
# 账户持仓模式: 双向(long_short_mode)开仓需带 posSide; 单向(net_mode)不能带(不同实盘账户模式可能不同)
$isHedgeMode = $false
if($isLive){
  try {
    $accCfg = & $okx --json account config 2>$null | ConvertFrom-Json
    if($accCfg -and $accCfg[0] -and $accCfg[0].posMode -and [string]$accCfg[0].posMode -eq 'long_short_mode'){ $isHedgeMode = $true }
  } catch {}
}

# 候选池参数
$chgFilter = 1.0
$volFilter = 20000000
# 候选池(2026-10-20 用户要求): 由"涨幅榜一半+跌幅榜一半"改为「按 5 分钟振幅排序取前 N」
#   参数全部可配; ampPoolEnabled=false 即回到老的涨幅榜/跌幅榜选法（一键回滚）
$maxCandidates = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.maxCandidates){ [int]$cfg.rules.maxCandidates } else { 40 }
$ampPoolEnabled = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.ampPoolEnabled){ [bool]$cfg.rules.ampPoolEnabled } else { $true }
$ampPoolBars = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.ampPoolBars){ [int]$cfg.rules.ampPoolBars } else { 12 }
$ampPoolMinVol = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.ampPoolMinVolUsdt){ [double]$cfg.rules.ampPoolMinVolUsdt } else { 0 }
$ampPoolThrottle = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.ampPoolThrottle){ [int]$cfg.rules.ampPoolThrottle } else { 6 }
# [restscan-2026-11-09] 扫描/取数的传输方式：rest=直连 REST 批量（快 8~20 倍）；cli=原来的逐币 spawn okx CLI（可一键回退）
$ampScanMode = if($cfg -and $cfg.rules -and $cfg.rules.ampScanMode){ [string]$cfg.rules.ampScanMode } else { 'rest' }
$restScanRate = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.restScanRate){ [int]$cfg.rules.restScanRate } else { 15 }
$restScanConc = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.restScanConc){ [int]$cfg.rules.restScanConc } else { 8 }
# [restscan-2026-11-09] 批量预取默认关闭（实测该块会抛 Index 错误导致整轮中断，待单独修复后再开）
$restPrefetchOn = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.restPrefetch){ [bool]$cfg.rules.restPrefetch } else { $true }

$script:poolStats = $null

# 交易池(固定池): 从 config.rules.instruments 读; 空数组 = 不限币种(全部候选走动态入池评估)
$tradeList = @()
if($cfg -and $cfg.rules -and $null -ne $cfg.rules.instruments){ $tradeList = @($cfg.rules.instruments) }
# 动态入池最低成交额(config.rules.dynMinVol, 默认 1000 万; 放开币种限制时可调低)
$dynMinVol = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.dynMinVol){ [double]$cfg.rules.dynMinVol } else { 10000000 }
# 每轮最大开仓数(config.rules.maxPerRound, 控制频率)
$maxPerRound = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.maxPerRound){ [int]$cfg.rules.maxPerRound } else { 99 }
# 择优开仓(rules.pickBest, 2026-10-01 用户要求"同一周期只开1个最优的"):
#   第一趟只"收集"所有本可开仓的候选(不真开), 第二趟按 rules.strategyScore(该策略在
#   signal-verify-store-live 的实测平均盈亏%)降序, 只开前 $maxPerRound 个。
$pickBest = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.pickBest){ [bool]$cfg.rules.pickBest } else { $false }
$script:pickBest = $pickBest
$script:deferOpen = $false
$script:deferred = [System.Collections.Generic.List[object]]::new()
$script:strategyScore = @{}
if($cfg -and $cfg.rules -and $cfg.rules.strategyScore){
  foreach($p in $cfg.rules.strategyScore.PSObject.Properties){ $script:strategyScore[[string]$p.Name] = [double]$p.Value }
}
# 打分: 动态反向过的信号优先取"反向:key"; 未列出的策略记 0
function Get-StrategyScore($key, $isReversed){
  $k = if($isReversed){ '反向:' + [string]$key } else { [string]$key }
  if($script:strategyScore.ContainsKey($k)){ return [double]$script:strategyScore[$k] }
  return 0.0
}
# 同币同日只开一次(rules.sameCoinOncePerDay, 默认开; 2026-09-04 用户要求放开可设 false → 同币当天按信号可多次进出)
$sameCoinOncePerDay = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.sameCoinOncePerDay){ [bool]$cfg.rules.sameCoinOncePerDay } else { $true }
# 每币每日开仓上限(rules.coinMaxPerDay, 2026-09-10 用户要求"每币3单/天"; 0=不限)。与 sameCoinOncePerDay 取更严者
$coinMaxPerDay = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.coinMaxPerDay){ [int]$cfg.rules.coinMaxPerDay } else { 0 }
# journal 同 episode 重发时间窗(规则 journalReEmitHours, 默认24h): 同币同方向同策略距上次记录>此值 → 重新记录(2026-09-08 修复验证库停滞)
$journalReEmitH = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.journalReEmitHours){ [double]$cfg.rules.journalReEmitHours } else { 24 }
# 反向空趋势过滤(2026-09-11, rules.reverseShortTrendFilter 默认开): 反向做空遇到该币 4H 趋势向上 或 当日涨幅 > reverseShortMaxChg24Pct(默认20%) → 跳过
$revShortFilterOn = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.reverseShortTrendFilter){ [bool]$cfg.rules.reverseShortTrendFilter } else { $true }
$revShortMaxChg = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.reverseShortMaxChg24Pct){ [double]$cfg.rules.reverseShortMaxChg24Pct } else { 20 }
# 开单成交额硬门槛(2026-09-11 起 200万U; 2026-09-18 用户要求提高到 500万U): 该币 24h 成交额低于此值 → 不开单(信号仍记录/验证)
#   依据: 回测(6602条4h结果) 空单在"成交额>=500万U"币上 均收益 +0.02% (n=694), 不筛时 -0.30% (n=1767); 且降滑点
$minVolOpen = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.minVolUsdt){ [double]$cfg.rules.minVolUsdt } else { 2000000 }
# 暴涨禁空(2026-09-18, rules.maxChg24ShortPct 默认 12): 该币 24h 涨幅 > 此值 → 禁止一切新开空(含组合B背离/ALT反向空)
#   依据: 6602 条已产生 4h 结果的信号回测 —— chg24>12 的空单 682 单胜率 46.6% 均收益 +0.41%(赚钱, 应拦),
#   而 chg24<=12 的空单 2609 单胜率 60.6% 均收益 -0.72%(亏钱, 是主要亏源)。0=关闭
#   注意: 4H趋势作锚经回测证伪(逆势空反而更好), 故此处只用 24h 涨幅, 不用趋势
$maxChg24Short = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.maxChg24ShortPct){ [double]$cfg.rules.maxChg24ShortPct } else { 12 }
# chg24 方向规则(2026-10-23 用户要求; 依据 deploy/audit-cutoff.js 对 672 条 WEAK-LONG 的 15m 真实路径结算):
#   chg24 <  rules.chg24DirLongMax(默认 3%)   → 只允许做多
#   chg24 >= rules.chg24DirShortMin(默认 8%)  → 只允许做空
#   中间 3%~8% = 死区 → 不做（做多 −0.61%~−0.31%/笔, 做空 +0.21%~+0.56%/笔, 都不足以覆盖成本）
#   依据: 分档期望 做多(0~2%) +0.90% / 做空(10~20%) +1.52% / (≥20%) +0.73%；[3%,8%) 结构合计 1.15%/笔（样本内 1.14 / 样本外 1.14）
#   开关默认 false（未配置即不生效）；chg24DirExemptStrategies 可按策略豁免
$chg24DirEnabled = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.chg24DirEnabled){ [bool]$cfg.rules.chg24DirEnabled } else { $false }
$chg24DirLongMax = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.chg24DirLongMax){ [double]$cfg.rules.chg24DirLongMax } else { 3 }
$chg24DirShortMin = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.chg24DirShortMin){ [double]$cfg.rules.chg24DirShortMin } else { 8 }
$script:chg24DirExempt = @()
try { if($cfg -and $cfg.rules -and $cfg.rules.chg24DirExemptStrategies){ $script:chg24DirExempt = @($cfg.rules.chg24DirExemptStrategies) } } catch {}
# 市场宽度观测(2026-09-18, rules.breadthWatch 默认 true): 每轮计算全市场涨跌比并写入 journal 输出, 仅记录不参与决策
#   目的: 累积独立样本 —— 当前宽度与 chg24 高度共线, 无法区分增量贡献; 累积后再决定是否用于决策
$breadthWatch = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.breadthWatch){ [bool]$cfg.rules.breadthWatch } else { $true }
# 宽度统计口径(2026-09-18 用户要求): 只统计 24h 成交额 >= 此值的币种(rules.breadthMinVolUsdt 默认 500万U)
#   低流动性币的涨跌幅噪音大, 会把"少数小币暴涨"误判成"普涨"
$breadthMinVol = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.breadthMinVolUsdt){ [double]$cfg.rules.breadthMinVolUsdt } else { 5000000 }
# 市场宽度禁空(2026-09-18 用户规则, rules.breadthShortBlock 默认 true):
#   全市场(仅统计 24h 成交额>=breadthMinVol 的币) 上涨占比 > breadthShortOnPct(默认75%) → 停止一切做空
#   滞回: 一旦停空, 直到 上涨占比 < breadthShortOffPct(默认70%) 才恢复做空(避免在阈值附近反复开关)
#   依据回测(3650样本): 拦掉组 346单 胜率51.7% 均收益 +0.05%; 保留组 1478单 59.7% -0.33% → 拦掉的是唯一不亏的一档
#   状态持久化到 breadth-block-state{suffix}.json(跨轮/跨重启保持滞回状态)
$breadthShortBlock = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.breadthShortBlock){ [bool]$cfg.rules.breadthShortBlock } else { $true }
$breadthShortOn  = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.breadthShortOnPct){ [double]$cfg.rules.breadthShortOnPct } else { 75 }
$breadthShortOff = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.breadthShortOffPct){ [double]$cfg.rules.breadthShortOffPct } else { 70 }
$breadthStateFile = Join-Path $baseDir ('breadth-block-state' + $suffix + '.json')
$script:shortBlocked = $false   # 本轮是否处于"普涨禁空"状态(每轮由 Get-MarketBreadth 重置)
# 限价入场(低于现价买入/高于现价卖出, config.risk.useLimitEntry + limitEntryDistancePct)
$useLimit = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.useLimitEntry){ [bool]$cfg.risk.useLimitEntry } else { $false }
$limitDist = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.limitEntryDistancePct){ [double]$cfg.risk.limitEntryDistancePct } else { 0.005 }
# 2026-11-01 用户要求: 多单挂单距离 1%、空单 0.5%（可按方向分别配置；缺省回落到 limitEntryDistancePct）
$limitDistLong = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.limitEntryDistancePctLong){ [double]$cfg.risk.limitEntryDistancePctLong } else { $limitDist }
$limitDistShort = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.limitEntryDistancePctShort){ [double]$cfg.risk.limitEntryDistancePctShort } else { $limitDist }
# 组合开关(2026-08-27 第一批): A=震荡猎手(CHOP过滤+Squeeze) B=背离做空(RSI/CVD顶背离) C=Supertrend替代4H趋势
$enableComboA = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.enableComboA){ [bool]$cfg.rules.enableComboA } else { $false }
$enableComboB = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.enableComboB){ [bool]$cfg.rules.enableComboB } else { $false }
$enableComboC = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.enableComboC){ [bool]$cfg.rules.enableComboC } else { $false }
# 组合C方向开关(2026-09-02): comboCUseTrend=true 时 Supertrend 替代 4H EMA 趋势; false 时仅记录跟踪(journal), 趋势用 EMA 共识——Supertrend 累计胜率~41% 方向偏弱, 默认关闭替代
$comboCUseTrend = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.comboCUseTrend){ [bool]$cfg.rules.comboCUseTrend } else { $false }
# 空单收紧(config.rules.requireShortTrend): 开启后 STRONG-SHORT 需 4H 趋势明确 SHORT; WEAK-SHORT 不再触发(避免逆势做空)
$requireShortTrend = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.requireShortTrend){ [bool]$cfg.rules.requireShortTrend } else { $false }
# 动态反向: 策略正向胜率 < reverseWinRateThreshold(默认40%) 且 样本>=reverseMinSamples(默认10) 时, 该策略信号直接取反
$reverseTh = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.reverseWinRateThreshold){ [double]$cfg.rules.reverseWinRateThreshold } else { 40 }
$reverseMinN = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.reverseMinSamples){ [int]$cfg.rules.reverseMinSamples } else { 10 }
# 降频提精度(2026-08-29): strictDoubleConfirm=15m+1H双周期都确认才出信号; strictOrderFlow=订单流必须与方向一致才开仓
$strictDoubleConfirm = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.strictDoubleConfirm){ [bool]$cfg.rules.strictDoubleConfirm } else { $true }
$strictOrderFlow = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.strictOrderFlow){ [bool]$cfg.rules.strictOrderFlow } else { $true }
# 每日反向规则(2026-08-29): 昨天日胜率 < dailyReverseThreshold(默认45%) 且 昨日样本>=dailyReverseMinSamples(默认10) → 今天反向开仓
$dailyTh = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.dailyReverseThreshold){ [double]$cfg.rules.dailyReverseThreshold } else { 45 }
$dailyMinN = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.dailyReverseMinSamples){ [int]$cfg.rules.dailyReverseMinSamples } else { 10 }
# 连续3天熔断(2026-08-29): 同一策略连续 disableConsecutiveDays(默认3) 天日胜率 < dailyTh(45%) → 直接禁用(正反都不开, 永久, 需手动从 disabled-strategies 移除恢复)
$disableDays = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.disableConsecutiveDays){ [int]$cfg.rules.disableConsecutiveDays } else { 3 }
# [dailyfix-2026-11-04] 单日最小样本：某天样本数不够就不计入"连续N天"判定（防凭 1 个样本禁用策略）
$dailyMinPerDay = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.dailyMinSamplesPerDay){ [int]$cfg.rules.dailyMinSamplesPerDay } else { 5 }
# [dailyfix-2026-11-04] .NET 集合被 ConvertTo-Json 序列化时会写出这些属性名，历史上它们被当成策略名写进 history 并永久残留
$script:dailyHistBadKey = @{}
foreach($bk in @('Count','IsSynchronized','IsReadOnly','Length','IsFixedSize','Rank','LongLength','SyncRoot','Capacity','Item')){ $script:dailyHistBadKey[$bk] = $true }
# 直接禁用(2026-09-04): 累计正向样本 n∈[directDisableMinSamples, reverseMinSamples) 且 胜率<directDisableMaxWinRate → 永久禁用(正反都不开);
# 样本>=reverseMinSamples 的低胜率策略走"动态反向"(reverseSet), 不在此禁
$directMinN = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.directDisableMinSamples){ [int]$cfg.rules.directDisableMinSamples } else { 10 }
$directMaxRate = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.directDisableMaxWinRate){ [double]$cfg.rules.directDisableMaxWinRate } else { 40 }
$script:disabledSet = @{}
# 长时间持仓优化(2026-09-01): ①时间止损 maxHoldHours(默认48h, 超时市价平仓) ②多单移动止损(与空单一致) ③盈亏平衡 breakevenPct(默认5%, 浮盈达标把止损移到入场价)
$maxHoldHours = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.maxHoldHours){ [double]$cfg.rules.maxHoldHours } else { 48 }
$breakevenPct = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.breakevenPct){ [double]$cfg.rules.breakevenPct } else { 5 }
$enableBreakeven = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.enableBreakeven){ [bool]$cfg.rules.enableBreakeven } else { $true }
$ledgerFile = Join-Path $baseDir ('strategy-positions' + $suffix + '.json')
# 高胜率策略开仓金额加成(2026-09-01): 命中列表的策略单笔名义 × highWinrateNotionalBoost(默认1.2, 即+20%)
$boostStrategies = @('组合B:RSI顶背离','组合B:CVD顶背离','STRONG-SHORT')
if($cfg -and $cfg.rules -and $cfg.rules.highWinrateStrategies){ $boostStrategies = @($cfg.rules.highWinrateStrategies) }
$boostRate = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.highWinrateNotionalBoost){ [double]$cfg.rules.highWinrateNotionalBoost } else { 1.2 }
# 同策略连续亏损冷却(2026-09-02): 策略实际成交连续亏 cooldownConsecutiveLosses(默认3)笔 → 冷却(信号照常记录验证, 不开单), 冷却期信号胜率恢复到 cooldownWinRateRecover(默认50%) 且样本>=cooldownMinSignals(默认5) → 自动解冻
$cooldownLosses = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.cooldownConsecutiveLosses){ [int]$cfg.rules.cooldownConsecutiveLosses } else { 3 }
$cooldownRecover = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.cooldownWinRateRecover){ [double]$cfg.rules.cooldownWinRateRecover } else { 50 }
$cooldownMinSignals = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.cooldownMinSignals){ [int]$cfg.rules.cooldownMinSignals } else { 5 }
$cooldownFile = Join-Path $baseDir ('strategy-cooldown' + $suffix + '.json')
$script:cooldownSet = @{}
# 高位做空结构止损(2026-09-04): 组合B背离空/反向动量空(拉高后逆势空)用"破新高才走"的结构止损,
# SL = max(固定 mainSlPct, 参考高点上方 buffer), 距离上限 structSlMaxDistPct 保护;
# 参考高点 = 开仓时最近 structSlRefBars 根已收盘 1H K 线最高价(剔除当前未收K线)
$structSlEnabled = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.structSlEnabled){ [bool]$cfg.rules.structSlEnabled } else { $true }
$structSlRefBars = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.structSlRefBars){ [int]$cfg.rules.structSlRefBars } else { 24 }
$structSlBufferPct = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.structSlBufferPct){ [double]$cfg.rules.structSlBufferPct } else { 0.5 }
$structSlMaxDistPct = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.structSlMaxDistPct){ [double]$cfg.rules.structSlMaxDistPct } else { 15 }
$script:reverseSet = @{}
$script:lastTickers = $null   # 候选池原始 ticker 缓存(供 alwaysTrack 取真实 chg/vol)

# ===== PauseSwitch20260920 开单闸门(BI 面板按钮控制) =====
# 作用域: 仅"是否允许新开仓"。已有持仓的止盈止损(OCO)、dyn-protect 动态保护、对账、快照、
#         孤儿算法单清理【全部不受影响】——因为平仓/保护走的是独立的 reduceOnly 市价单与算法单。
$script:tradeSwitchFile = Join-Path $baseDir ('trading-switch' + $suffix + '.json')
$script:tradeSwitchAppliedFile = Join-Path $baseDir ('trading-switch-applied' + $suffix + '.json')
$script:allowOpen = $true              # 默认允许(文件缺失=允许, 与上线前行为一致)
$script:cancelPendingOnPause = $true   # 暂停时是否撤销"未成交的入场限价单"(否则成交即等于开了新仓)
# OI 记录(2026-09-21, rules.oiWatch 默认 true): 开仓前记录当时持仓量状态, 打"四象限"标签
#   仅记录不改交易 —— 用于统计"OI升+价升"这类组合的实际胜率, 再决定是否做过滤器
#   象限: up-acc(增仓上涨) / up-dist(减仓上涨) / dn-acc(增仓下跌) / dn-dist(减仓下跌)
$oiWatch = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.oiWatch){ [bool]$cfg.rules.oiWatch } else { $true }
$oiSnapFile = Join-Path $baseDir 'oi-last-snapshot.json'
$script:oiQuadrantCache = @{}
function Get-TradingSwitch {
  # 文件缺失          -> 允许开单(默认态)
  # 文件存在但读不出  -> 禁止开单(保守): 宁可不开, 也不要在用户以为已暂停时偷偷开仓
  if(-not (Test-Path $script:tradeSwitchFile)){
    return @{ allowOpen=$true; reason=''; missing=$true; cancelPending=$true; updatedAt='' }
  }
  try {
    $o = Get-Content $script:tradeSwitchFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if($o -and $null -ne $o.allowOpen){
      $cp = if($null -ne $o.cancelPendingOnPause){ [bool]$o.cancelPendingOnPause } else { $true }
      return @{ allowOpen=[bool]$o.allowOpen; reason=[string]$o.reason; cancelPending=$cp; updatedAt=[string]$o.updatedAt }
    }
    return @{ allowOpen=$false; reason='switch-file-invalid'; invalid=$true; cancelPending=$true; updatedAt='' }
  } catch {
    return @{ allowOpen=$false; reason='switch-file-unreadable'; invalid=$true; cancelPending=$true; updatedAt='' }
  }
}
function Sync-TradingSwitch {
  $sw = Get-TradingSwitch
  $script:allowOpen = [bool]$sw.allowOpen
  $script:cancelPendingOnPause = [bool]$sw.cancelPending
  return $sw
}

function Get-TriedSet {
  if(Test-Path $triedFile){
    try { $j = Get-Content $triedFile -Raw -Encoding UTF8 | ConvertFrom-Json; return @($j) } catch { return @() }
  }
  return @()
}
function Save-Tried($instId, $dir, $sig){
  $set = @(Get-TriedSet)
  $today = (Get-Date).ToString('yyyy-MM-dd')
  $set += [pscustomobject]@{ instId=$instId; date=$today; dir=$dir; sig=$sig }
  $set | ConvertTo-Json -Depth 4 | Out-File $triedFile -Encoding UTF8
}

function Get-Candidates {
  $tickers = & $okx --json market tickers SWAP 2>$null | ConvertFrom-Json
  if(-not $tickers){ return @() }
  $script:lastTickers = $tickers   # 供 alwaysTrack 固定跟踪列表取真实 chg/vol
  $all = @()
  foreach($t in $tickers){
    if($t.instId -notlike '*-USDT-SWAP'){ continue }
    if(-not $t.last -or -not $t.open24h -or $t.last -eq '0' -or $t.open24h -eq '0'){ continue }
    $chg = [math]::Round(([double]$t.last/[double]$t.open24h-1)*100, 2)
    # 成交额用 USDT 口径(last x volCcy24h); 修复: 原 volCcy24h 是币数量, 与阈值单位不符, 高价币(ETH/SOL/BTC)被误过滤
    $vol = [math]::Round([double]$t.last * [double]$t.volCcy24h, 0)
    $all += [pscustomobject]@{ instId=$t.instId; chg=$chg; vol=$vol }
  }
  # ===== 新选法(2026-10-20): 全市场按"最近 N 根 5M 的最大振幅"排序, 取前 $maxCandidates =====
  #   amp = max( (H-L)/O ) over 最近 ampPoolBars 根**已收盘** 5M  K线
  #   5M 数据逐币拉取(6 路并发); 任一币失败只跳过该币, 不阻塞整轮
  #   ⚠️ 本函数内**禁止 Write-Output**（PowerShell 会把它并入返回值，曾导致候选数组混入字符串 → 整轮崩）
  #      日志改用 $script:poolStats，由 Invoke-Round 在调用点打
  if($ampPoolEnabled -and $all.Count -gt 0){
    try {
      $scan = @($all | Where-Object { $ampPoolMinVol -le 0 -or [double]$_.vol -ge $ampPoolMinVol })
      $sw = [System.Diagnostics.Stopwatch]::StartNew()
      # [restscan-2026-11-09] 优先走直连 REST 批量扫描（1 个进程），失败自动回退逐币 CLI
      $ampRows = @()
      $__restOk = $false
      if($ampScanMode -eq 'rest'){
        try {
          $__si = Join-Path $dataDir 'amp-scan-in.json'
          $__so = Join-Path $dataDir 'amp-scan-out.json'
          @($scan | ForEach-Object { [string]$_.instId }) | ConvertTo-Json -Compress | Out-File $__si -Encoding utf8
          & $nodeExe (Join-Path $baseDir 'scan-amp5m.js') --in $__si --out $__so --bars $ampPoolBars --conc $restScanConc --rate $restScanRate 2>$null | Out-Null
          if(Test-Path $__so){
            $__sj = (Get-Content $__so -Raw -Encoding utf8) | ConvertFrom-Json
            if($__sj -and $__sj.items -and @($__sj.items).Count -gt 0){
              $ampRows = @($__sj.items | ForEach-Object { [pscustomobject]@{ instId=[string]$_.instId; amp=[double]$_.amp } })
              $__restOk = $true
              # REST 扫描统计由 pool-amp5m 汇总行输出（此处禁止 Write-Output，否则会污染 Get-Candidates 返回值）
            }
          }
        } catch { }
      }
      if(-not $__restOk){
      $ampRows = $scan | ForEach-Object -ThrottleLimit $ampPoolThrottle -Parallel {
        $inst = $_.instId
        try {
          $raw = & $using:okx --json market candles $inst --bar 5m --limit 20 2>$null | Out-String
          if(-not $raw){ return }
          $j = $raw | ConvertFrom-Json
          if(-not $j){ return }
          $arr = @($j)
          if($arr.Count -lt 3){ return }
          # OKX candles 返回降序(新→旧): 剔除第 0 根未收盘, 取其后 $using:ampPoolBars 根
          $take = [math]::Min($using:ampPoolBars, $arr.Count - 1)
          $mx = 0.0
          for($k = 1; $k -le $take; $k++){
            $r = $arr[$k]
            if($null -eq $r){ continue }
            $o = [double]$r[1]; $h = [double]$r[2]; $l = [double]$r[3]
            if($o -gt 0){ $a = ($h - $l) / $o * 100; if($a -gt $mx){ $mx = $a } }
          }
          if($mx -le 0){ return }
          [pscustomobject]@{ instId = $inst; amp = [math]::Round($mx, 2) }
        } catch { }
      }
      }
      $sw.Stop()
      $ampOk = @($ampRows | Where-Object { $_ -and $_.instId -and $_.amp -gt 0 })
      if($ampOk.Count -gt 0){
        $top = @($ampOk | Sort-Object -Property amp -Descending | Select-Object -First $maxCandidates)
        $byId = @{}; foreach($x in $all){ if($x.instId){ $byId[$x.instId] = $x } }
        $picked = @()
        foreach($t in $top){
          if(-not $t -or -not $t.instId){ continue }
          $b = $byId[$t.instId]
          if($b){ $picked += [pscustomobject]@{ instId=[string]$b.instId; chg=[double]$b.chg; vol=[double]$b.vol; amp=[double]$t.amp } }
        }
        if($picked.Count -gt 0){
          $script:poolStats = [ordered]@{
            mode='amp5m'; scanned=@($scan).Count; ok=$ampOk.Count; picked=@($picked).Count
            ms=$sw.ElapsedMilliseconds; bars=$ampPoolBars; throttle=$ampPoolThrottle
            topAmp=if(@($top).Count -gt 0){ [double]$top[0].amp } else { $null }
            minVolUsdt=$ampPoolMinVol
          }
          # 防御：只返回带 instId 的对象，杜绝任何字符串/null 混入
        return @($picked | Where-Object { $_ -and $_.instId })
        }
      }
      $script:poolStats = [ordered]@{ mode='amp5m-empty-fallback'; scanned=@($scan).Count; ok=$ampOk.Count; ms=$sw.ElapsedMilliseconds }
    } catch {
      $script:poolStats = [ordered]@{ mode='amp5m-error-fallback'; err=('' + $_.Exception.Message) }
    }
  }
  # ===== 老选法(兜底): 涨幅榜取一半 + 跌幅榜取一半（让空头机会也进候选）=====
  $half = [math]::Max(5, [int]($maxCandidates / 2))
  $gainers = @($all | Where-Object { $_.chg -gt 0 } | Sort-Object chg -Descending | Select-Object -First $half)
  $losers  = @($all | Where-Object { $_.chg -lt 0 } | Sort-Object chg | Select-Object -First $half)
  $cands = @($gainers) + @($losers)
  $script:poolStats = [ordered]@{ mode='chg'; scanned=$all.Count; picked=@($cands).Count }
  return $cands
}

function Get-BarSignal($inst, $bar){
  $candleFile = Join-Path $dataDir ($inst + '_' + $bar + '.json')
  # [restscan-2026-11-09] 优先用本轮 prefetch 预取的文件（3 分钟内视为新鲜），否则回退 CLI 现场拉
  $__needFetch = $true
  try {
    if(Test-Path $candleFile){
      if(((Get-Date) - (Get-Item $candleFile).LastWriteTime).TotalMinutes -lt 3){ $__needFetch = $false }
    }
  } catch { }
  if($__needFetch){ & $okx --json market candles $inst --bar $bar --limit 300 2>$null | Out-File $candleFile -Encoding utf8 }
  $indFile = Join-Path $dataDir ($inst + '_' + $bar + '-ind.json')
  & $nodeExe (Join-Path $baseDir 'indicators.js') $candleFile $bar 300 2>$null | Out-File $indFile -Encoding utf8
  $stratOut = & $nodeExe (Join-Path $baseDir 'strategies.js') $indFile 2>$null | Out-String
  return ($stratOut | ConvertFrom-Json)
}

# 结构止损参考高点: 读本轮回合已抓的 1H K线文件(OKX 行格式 r[0]=ts..r[2]=high), 取最近 structSlRefBars 根已收盘 K 线最高价(剔除最后一根未收盘)
function Get-RefHigh($inst){
  try {
    $cf = Join-Path $dataDir ($inst + '_1H.json')
    if(-not (Test-Path $cf)){ return 0 }
    $raw = Get-Content $cf -Raw -Encoding UTF8
    if($raw){ if($raw[0] -eq [char]0xFEFF){ $raw = $raw.Substring(1) } }
    else { return 0 }
    $rows = $raw | ConvertFrom-Json
    $arr = @()
    if($rows -is [array]){ $arr = @($rows) }
    elseif($rows.data){ $arr = @($rows.data) }
    # [barfix-2026-11-03] 方向自适应：OKX 返回【新->旧】，原代码按【旧->新】取下标 -> 取到了数组另一端。
    # 这里按首尾时间戳判断方向并翻转成【旧->新】，再剔除还没走完的那根。
    $arr = @($arr)
    if($arr.Count -ge 2){
      $tsF = if($arr[0] -is [array]){ [double]$arr[0][0] } else { [double]$arr[0].ts }
      $tsL = if($arr[$arr.Count-1] -is [array]){ [double]$arr[$arr.Count-1][0] } else { [double]$arr[$arr.Count-1].ts }
      if($tsF -gt $tsL){ [array]::Reverse($arr) }
      $fxSec = 3600
      $fxNow = if($env:OKX_BAR_NOW_MS){ [double]$env:OKX_BAR_NOW_MS } else { [double]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) }
      $fxLast = if($arr[$arr.Count-1] -is [array]){ [double]$arr[$arr.Count-1][0] } else { [double]$arr[$arr.Count-1].ts }
      if(($fxLast + $fxSec * 1000) -gt $fxNow){ $arr = @($arr[0..($arr.Count-2)]) }
    }
    # 此时 $arr 已是【旧->新】且已剔除未收盘 -> 直接取末尾 $structSlRefBars 根
    $cnt = $arr.Count
    if($cnt -lt 1){ return 0 }
    $n = [math]::Min($structSlRefBars, $cnt)
    if($n -le 0){ return 0 }
    $hi = 0.0
    for($i = $cnt - $n; $i -lt $cnt; $i++){
      $r = $arr[$i]
      if($null -eq $r){ continue }
      $h = 0.0
      if($r -is [array]){ if($r.Count -gt 2){ $h = [double]$r[2] } }
      elseif($r.h){ $h = [double]$r.h }
      if($h -gt $hi){ $hi = $h }
    }
    return $hi
  } catch { return 0 }
}

# 波动率 regime 系数(2026-09-04): 读本轮 1H K线文件, 当前 ATR20(最近20根TR均值) vs 约40根前基准ATR20
# 当前波动 > 1.25×基准 → 0.7(高波缩仓); < 0.8× → 1.1(低波加仓); 否则 1.0
function Get-VolFactor($inst){
  try {
    $cf = Join-Path $dataDir ($inst + '_1H.json')
    if(-not (Test-Path $cf)){ return 1.0 }
    $raw = Get-Content $cf -Raw -Encoding UTF8
    if($raw){ if($raw[0] -eq [char]0xFEFF){ $raw = $raw.Substring(1) } } else { return 1.0 }
    $rows = $raw | ConvertFrom-Json
    $arr = @()
    if($rows -is [array]){ $arr = @($rows) } elseif($rows.data){ $arr = @($rows.data) }
    # [barfix-2026-11-03] 方向自适应：OKX 返回【新->旧】，原代码按【旧->新】取下标 -> 取到了数组另一端。
    # 这里按首尾时间戳判断方向并翻转成【旧->新】，再剔除还没走完的那根。
    $arr = @($arr)
    if($arr.Count -ge 2){
      $tsF = if($arr[0] -is [array]){ [double]$arr[0][0] } else { [double]$arr[0].ts }
      $tsL = if($arr[$arr.Count-1] -is [array]){ [double]$arr[$arr.Count-1][0] } else { [double]$arr[$arr.Count-1].ts }
      if($tsF -gt $tsL){ [array]::Reverse($arr) }
      $fxSec = 3600
      $fxNow = if($env:OKX_BAR_NOW_MS){ [double]$env:OKX_BAR_NOW_MS } else { [double]([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) }
      $fxLast = if($arr[$arr.Count-1] -is [array]){ [double]$arr[$arr.Count-1][0] } else { [double]$arr[$arr.Count-1].ts }
      if(($fxLast + $fxSec * 1000) -gt $fxNow){ $arr = @($arr[0..($arr.Count-2)]) }
    }
    $hs = New-Object System.Collections.Generic.List[double]
    $ls = New-Object System.Collections.Generic.List[double]
    $cs = New-Object System.Collections.Generic.List[double]
    foreach($r in $arr){
      if($null -eq $r){ continue }
      if($r -is [array]){ if($r.Count -gt 4){ $hs.Add([double]$r[2]); $ls.Add([double]$r[3]); $cs.Add([double]$r[4]) } }
      else { $hs.Add([double]$r.h); $ls.Add([double]$r.l); $cs.Add([double]$r.c) }
    }
    $n = $hs.Count
    if($n -lt 62){ return 1.0 }
    $trs = New-Object System.Collections.Generic.List[double]
    for($i=1; $i -lt $n; $i++){
      $tr = $hs[$i] - $ls[$i]
      $a = [math]::Abs($hs[$i] - $cs[$i-1]); $b = [math]::Abs($ls[$i] - $cs[$i-1])
      if($a -gt $tr){ $tr = $a }; if($b -gt $tr){ $tr = $b }
      $trs.Add($tr)
    }
    if($trs.Count -lt 61){ return 1.0 }
    $nowAtr = 0.0; for($i=$trs.Count-20; $i -lt $trs.Count; $i++){ $nowAtr += $trs[$i] }; $nowAtr /= 20.0
    $baseAtr = 0.0; for($i=$trs.Count-60; $i -lt $trs.Count-40; $i++){ $baseAtr += $trs[$i] }; $baseAtr /= 20.0
    if($baseAtr -le 0){ return 1.0 }
    $ratio = $nowAtr / $baseAtr
    if($ratio -gt 1.25){ return 0.7 }
    if($ratio -lt 0.8){ return 1.1 }
    return 1.0
  } catch { return 1.0 }
}

# 当前资金费率 + 持仓量(CLI 公开行情, 无历史接口 → 前瞻试验用)
function Get-FundingOI($instId){
  try {
    $fr = & $okx --json market funding-rate $instId 2>$null | ConvertFrom-Json
    $oi = & $okx --json market open-interest $instId 2>$null | ConvertFrom-Json
    $funding = if($fr -and $fr[0]){ [double]$fr[0].fundingRate } else { $null }
    $oiVal = if($oi -and $oi[0]){ [double]$oi[0].oi } else { $null }
    if($null -eq $funding){ return $null }
    return @{ funding=$funding; oi=$oiVal }
  } catch { return $null }
}

# 高位做空结构止损触发价: 适用 srcKey=组合B:* / ALT:动量爆发追踪(反向做空); refHigh<=0 或结构止损不比固定近 → 返回 0(用固定止损)
# capPct: 距离上限百分比(perCoin 大币高杠杆收窄到10, 其余默认 structSlMaxDistPct=15)
function Get-StructSlPx($entryPx, $refHigh, $capPct){
  try {
    if($refHigh -le 0){ return 0 }
    if($null -eq $capPct -or $capPct -le 0){ $capPct = $structSlMaxDistPct }
    $fixedSl = [math]::Round($entryPx * (1 + $mainSlPct), 6)
    $s2 = [math]::Round($refHigh * (1 + $structSlBufferPct / 100.0), 6)
    if($s2 -le $fixedSl){ return 0 }
    $capPx = [math]::Round($entryPx * (1 + $capPct / 100.0), 6)
    if($s2 -gt $capPx){ $s2 = $capPx }
    if($s2 -le $fixedSl){ return 0 }
    return $s2
  } catch { return 0 }
}

# 订单流确认(返回 {signal, divergence}; divergence: bull-divergence=顶背离做空信号)
function Get-OrderFlowSignal($inst){
  try {
    $ofOut = & $nodeExe (Join-Path $baseDir 'orderflow.js') $inst 500 2>$null | Out-String
    $of = $ofOut | ConvertFrom-Json
    return @{
      signal = if($of.signal){ [string]$of.signal } else { 'NEUTRAL' }
      divergence = if($of.divergence){ [string]$of.divergence } else { 'aligned' }
    }
  } catch { return @{ signal='NEUTRAL'; divergence='aligned' } }
}

# 风险检查（持仓上限 + 回撤熔断）
# 该币"今日最近一笔真实成交"的已实现盈亏(okx swap fills 的 fillPnl)
# 2026-10-06 用户需求: 同币当日 ①上一笔成交盈利 → 放行(可再开) ②亏损 → 当日关闭
#   返回: 正数=盈利 / 负数=亏损 / $null=无法判定(今日无成交·只有撤单·查询失败) → 调用方按"关闭"处理(保守)
function Get-CoinLastTradePnlToday($inst){
  try {
    $rows = & $okx --json swap fills --instId $inst 2>$null | ConvertFrom-Json
    if(-not $rows){ return $null }
    $today = (Get-Date).ToString('yyyy-MM-dd')
    $best = $null; $bestTs = 0
    foreach($r in @($rows)){
      if($null -eq $r.fillPnl){ continue }
      $pnl = 0.0; try { $pnl = [double]$r.fillPnl } catch { continue }
      if($pnl -eq 0){ continue }
      $ts = 0.0; try { $ts = [double]$r.fillTime } catch { continue }
      if($ts -le 0){ continue }
      $d = ([DateTimeOffset]::FromUnixTimeMilliseconds([long]$ts)).ToLocalTime().ToString('yyyy-MM-dd')
      if($d -ne $today){ continue }
      if($ts -gt $bestTs){ $bestTs = $ts; $best = $pnl }
    }
    return $best
  } catch { return $null }
}

# ===== 2026-10-07 用户需求(选项2): 币级"当日已试过"的盈亏判定**收窄到同一策略** =====
# 起因: RAY 案例 —— STRONG-LONG 亏的 4.94U 封掉了 组合B:RSI顶背离(全表最可信的腿)同日在该币的机会;
#       实测近 7 天 43 条 already-tried 里 72% 属于"别的策略的交易封了这个币"。
# 新语义: 同币同日 —— **同一策略**最多 1 笔; 该策略在本币今日上一笔成交盈利 -> 放行, 亏损/无法判定 -> 关闭。
#         币级硬上限 coinMaxPerDay 与"已有持仓/挂单"闸门(live-skip-has-position, 防叠仓)保持不变。
# 数据源(均带策略维度): order-events<suffix>.jsonl(实时) / strategy-real-ledger<suffix>.json(10分钟) / trade-attribution<suffix>.json(15分钟)
function Build-ReentryCache($today){
  $c = @{}
  try {
    $oe = Join-Path $baseDir ('order-events' + $suffix + '.jsonl')
    if(Test-Path $oe){
      foreach($line in @(Get-Content $oe -Tail 500 -Encoding UTF8)){
        if(-not $line){ continue }
        $o = $null; try { $o = $line | ConvertFrom-Json } catch { continue }
        if(-not $o -or $o.kind -ne 'open' -or -not $o.instId -or -not $o.strategy){ continue }
        if([string]$o.ts -notlike ($today + '*')){ continue }
        $k = [string]$o.instId + '|' + [string]$o.strategy
        if(-not $c.ContainsKey($k)){ $c[$k] = @{ tried=$true; pnl=$null; closeTs=''; src='order-events' } }
      }
    }
  } catch {}
  try {
    $rl = Join-Path $baseDir ('strategy-real-ledger' + $suffix + '.json')
    if(Test-Path $rl){
      foreach($r in @(Get-Content $rl -Raw -Encoding UTF8 | ConvertFrom-Json)){
        if(-not $r -or -not $r.instId -or -not $r.strategy){ continue }
        if([string]$r.ts -notlike ($today + '*')){ continue }
        if(-not $r.traded){ continue }
        $k = [string]$r.instId + '|' + [string]$r.strategy
        if(-not $c.ContainsKey($k)){ $c[$k] = @{ tried=$true; pnl=$null; closeTs=''; src='real-ledger' } }
      }
    }
  } catch {}
  try {
    $af = Join-Path $baseDir ('trade-attribution' + $suffix + '.json')
    if(Test-Path $af){
      $a = Get-Content $af -Raw -Encoding UTF8 | ConvertFrom-Json
      foreach($x in @($a.closes)){
        if(-not $x -or -not $x.instId){ continue }
        if($null -eq $x.strategy -or [string]$x.strategy -eq ''){ continue }
        if([string]$x.closeTs -notlike ($today + '*')){ continue }
        $k = [string]$x.instId + '|' + [string]$x.strategy
        if(-not $c.ContainsKey($k)){ $c[$k] = @{ tried=$true; pnl=$null; closeTs=''; src='attribution' } }
        if([string]$x.closeTs -gt [string]$c[$k].closeTs){
          $c[$k].closeTs = [string]$x.closeTs
          $c[$k].pnl = [double]$x.pnl
          $c[$k].tried = $true
        }
      }
    }
  } catch {}
  return $c
}
function Get-CoinStrategyReentry($instId, $strategyKey, $today){
  if($null -eq $script:reentryCache){ $script:reentryCache = Build-ReentryCache $today }
  $k = [string]$instId + '|' + [string]$strategyKey
  if($script:reentryCache.ContainsKey($k)){ return $script:reentryCache[$k] }
  return @{ tried=$false; pnl=$null; closeTs=''; src='none' }
}

function Test-RiskOk {
  $positions = & $okx --json account positions 2>$null | ConvertFrom-Json
  $openCount = @($positions | Where-Object { $_.pos -and [double]$_.pos -ne 0 }).Count
  if($openCount -ge $maxOpenPositions){ return @{ok=$false; reason="持仓数 $openCount >= $maxOpenPositions"} }
  $bal = & $okx --json account balance 2>$null | ConvertFrom-Json
  $curEq = if($bal -and $bal[0] -and $bal[0].totalEq){ [double]$bal[0].totalEq } else { 0 }
  $eqFile = Join-Path $baseDir ('equity-baseline' + $suffix + '.json')
  $baselineEq = $null
  if(Test-Path $eqFile){ try { $baselineEq = [double](Get-Content $eqFile -Raw -Encoding UTF8 | ConvertFrom-Json).baseline } catch {} }
  if(-not $baselineEq -and $curEq -gt 0){ $baselineEq = $curEq; @{ baseline=$curEq } | ConvertTo-Json | Out-File $eqFile -Encoding UTF8 }
  if($ddHalt -gt 0 -and $baselineEq -and $curEq -gt 0 -and $curEq -lt $baselineEq * (1 - $ddHalt)){ return @{ok=$false; reason="回撤超 $($ddHalt*100)% 熔断"} }
  return @{ok=$true; openPositions=$openCount}
}

# 仓位轮换：满仓时若新信号 STRONG 且现有持仓有浮亏，先平最弱仓
function Try-Rotate($newInst, $direction){
  try {
    $positions = & $okx --json swap positions 2>$null | ConvertFrom-Json
    $open = @($positions | Where-Object { $_.pos -and [double]$_.pos -ne 0 })
    if($open.Count -lt $maxOpenPositions){ return @{rotated=$false; reason='not-full'} }
    # 找浮亏最大的仓位（upl 最小）
    $weakest = $open | Sort-Object { [double]$_.upl } | Select-Object -First 1
    if(-not $weakest){ return @{rotated=$false; reason='no-position'} }
    $weakUpl = [double]$weakest.upl
    if($weakUpl -ge 0){ return @{rotated=$false; reason='no-losing-position'} }  # 无浮亏仓不轮换
    # 平掉最弱仓（市价反向）
    $instId = $weakest.instId
    $side = if([double]$weakest.pos -gt 0){ 'sell' } else { 'buy' }
    $sz = [math]::Abs([double]$weakest.pos)
    $res = & $okx --json swap place --instId $instId --side $side --ordType market --sz $sz --tdMode cross --clOrdId (New-StratClOrdId 'RC') @aiBcArgs 2>$null | ConvertFrom-Json
    if($res -and $res[0] -and [string]$res[0].sCode -eq '0'){
      Add-OrderEvent 'rotate-close' @{ instId=$instId; ordId=[string]$res[0].ordId; clOrdId=[string]$res[0].clOrdId; posSide=$(if($side -eq 'sell'){ 'long' } else { 'short' }); ordType='market'; reduceOnly=$true; why=('仓位轮换: 平掉浮亏最弱仓(' + $weakUpl + 'U)'); round=$script:round }
      return @{rotated=$true; closedInst=$instId; closedUpl=$weakUpl}
    }
    return @{rotated=$false; reason='close-fail'}
  } catch { return @{rotated=$false; reason=$_.Exception.Message} }
}

# 山寨币策略信号（动量爆发/自由落体反弹 + V2 过滤器）按 config 开关启用/禁用
function Get-AltSignal($inst, $candleFile){
  try {
    $altOut = & $nodeExe (Join-Path $baseDir 'altcoin-strategies.js') $candleFile $inst 2>$null | Out-String
    $p = $altOut | ConvertFrom-Json
    if(-not $p -or -not $p.strategies){ return $null }
    $pump = $p.strategies[0]; $rebound = $p.strategies[1]; $dump = $p.strategies[2]
    # 策略开关(config.alt.enablePump/enableRebound/enableDump,默认开)
    $enablePump = if($cfg -and $cfg.alt -and $null -ne $cfg.alt.enablePump){ [bool]$cfg.alt.enablePump } else { $true }
    $enableRebound = if($cfg -and $cfg.alt -and $null -ne $cfg.alt.enableRebound){ [bool]$cfg.alt.enableRebound } else { $true }
    $enableDump = if($cfg -and $cfg.alt -and $null -ne $cfg.alt.enableDump){ [bool]$cfg.alt.enableDump } else { $true }
    # 过滤：V2 过滤器拦截则无信号（仅对买入信号；做空是反向操作不过滤）
    if($p.filterPass -eq $false -and $dump.signal -ne 'SELL'){ return @{signal='FILTERED'; detail='v2-filter-blocked'} }
    if($enablePump -and $pump.signal -eq 'BUY'){ return @{signal='LONG'; strategy=$pump.name; score=[int]$pump.score; tp=[double]$pump.tp; sl=[double]$pump.sl} }
    if($enableRebound -and $rebound.signal -eq 'BUY'){ return @{signal='LONG'; strategy=$rebound.name; score=[int]$rebound.score; tp=[double]$rebound.tp; sl=[double]$rebound.sl} }
    if($enableDump -and $dump.signal -eq 'SELL'){ return @{signal='SHORT'; strategy=$dump.name; score=[int]$dump.score; tp=[double]$dump.tp; sl=[double]$dump.sl} }
    return $null
  } catch { return $null }
}

# 交易池标的开仓执行（LONG/SHORT）
# 策略下单标记(2026-09-22): 所有策略下单带 clOrdId 前缀 DSH —— 用于把策略单与手动单精确区分。
# 背景: 此前策略订单 clOrdId/tag/source 全为空, 无法与手动单区分, 归因只能靠猜。
# OKX clOrdId 规则: 字母(区分大小写)+数字, 1-32 位。格式: DSH + MMddHHmmss + 2位序号 + 4位随机 = 19 位。
$script:clOrdSeq = 0
function New-StratClOrdId($tag){
  $script:clOrdSeq++
  $t = Get-Date -Format 'MMddHHmmss'
  $r = Get-Random -Minimum 1000 -Maximum 9999
  $p = if($tag){ ([string]$tag -replace '[^A-Za-z0-9]','') } else { 'X' }
  if($p.Length -gt 4){ $p = $p.Substring(0,4) }
  $id = ('DSH{0}{1:D2}{2}{3}' -f $t, $script:clOrdSeq, $r, $p)
  if($id.Length -gt 32){ $id = $id.Substring(0,32) }
  return $id
}

# 事件台账(2026-09-23): 策略每次 下单/成交/撤单/挂保护 当场追加一条记录 —— 开单归因的唯一真相源。
#   设计要点: signalTs/sigPrice 只记录、不参与判定 —— 彻底删除"时间窗 + 价格容差"这类猜测参数,
#   因此它们不可能再被设错。消费者(Bi/attrib)只做查表, 不做推断。
#   写入永不影响交易: 整段 try/catch, 失败只输出 warn; 记录缺口由 verify-attrib.js 的 A2 断言抓出。
$script:orderEventFile = Join-Path $baseDir ('order-events' + $suffix + '.jsonl')
function Add-OrderEvent($kind, $h){
  try {
    $ev = [ordered]@{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); kind=$kind }
    foreach($k in $h.Keys){ if($null -ne $h[$k] -and "$($h[$k])" -ne ''){ $ev[$k] = $h[$k] } }
    ($ev | ConvertTo-Json -Depth 4 -Compress) | Add-Content -Path $script:orderEventFile -Encoding UTF8
  } catch { Write-Output ('{"warn":"order-event-write-fail ' + $kind + ' ' + $_.Exception.Message + '"}') }
}

function Invoke-Trade($inst, $direction, $price, $srcKey, $forceMarket = $false){
  # 【开单闸门·硬拦截】PauseSwitch20260920: 本函数是所有开仓(含限价挂单)的唯一出口。
  # 平仓不走这里(止损/止盈/时间止损/dyn-protect 用独立 reduceOnly 单), 故此处拦截绝不影响平仓。
  # 每次调用现场重读开关文件 -> 点击按钮后无需重启, 下一次判定即生效。
  try {
    $swNow = Sync-TradingSwitch
    if(-not $script:allowOpen){
      return @{ok=$false; reason=('trading-paused-by-user' + $(if($swNow.reason){ '(' + $swNow.reason + ')' } else { '' })) }
    }
  } catch {}
  $swapId = $inst
  $curPos = & $okx --json swap positions $swapId 2>$null | ConvertFrom-Json
  # 双向模式下同一币种可能有 long/short 两行,累加所有方向持仓
  $curSz = 0
  if($curPos){
    foreach($pp in $curPos){ if($pp -and $pp.pos){ try { $curSz += [double]$pp.pos } catch {} } }
  }
  # 实盘模式: 该币已有持仓(含用户自有仓)绝不开新仓(不加仓/不反向)
  if($isLive -and $curSz -ne 0){ return @{ok=$false; reason='live-skip-has-position'} }
  # 币种方向覆盖层(2026-09-05): rules.coinDirOverride 按币种把信号方向反转或禁开
  #   例: "DASH-USDT-SWAP":{SHORT:LONG} 空单连止损→反向做多; "USELESS-USDT-SWAP":{*:OFF} 整体弃; "BTC-USDT-SWAP":{SHORT:OFF} 禁空
  if($cfg -and $cfg.rules -and $cfg.rules.coinDirOverride){
    foreach($cp in $cfg.rules.coinDirOverride.PSObject.Properties){
      if($cp.Name -ne $inst){ continue }
      $ovMap = $cp.Value
      if($ovMap.PSObject.Properties['*'] -and $ovMap.PSObject.Properties['*'].Value -eq 'OFF'){
        return @{ok=$false; reason=("coin-dir-off:{0}(all)" -f $inst)}
      }
      $dirProp = $ovMap.PSObject.Properties[$direction]
      if($dirProp){
        $ov = $dirProp.Value
        if($ov -eq 'OFF'){ return @{ok=$false; reason=("coin-dir-off:{0}({1})" -f $inst,$direction)} }
        elseif($ov -eq 'LONG' -or $ov -eq 'SHORT'){ $direction = $ov; Write-Host ('{"info":"coin-dir-override ' + $inst + ' ' + ($(if($ov -eq 'LONG'){'->LONG'}else{'->SHORT'})) + '"}') }
      }
      break
    }
  }
  # 币种熔断(2026-09-05): 该币连续 coinCooldownConsecLosses(默认4)笔亏损 → 临时禁开(盈利1笔解除)
  if($script:coinCooldownSet -and $script:coinCooldownSet[$inst]){ return @{ok=$false; reason=("coin-cooldown:{0}" -f $inst)} }
  # B(2026-09-10 修复): 按**该币自身**平仓历史精确算连续亏损(不依赖台账 status, 绕开"限价仓卡 pending → Reconcile 不归因 → 计数不累加"的失效)
  # 全局 positions-history --limit 100 会漏早期记录(实测 RAY 全局仅1条, 按币查出4连亏) → 必须按币查
  try {
    $cch = @(& $okx --json account positions-history --instType SWAP --instId $inst --limit 100 2>$null | ConvertFrom-Json)
    if($cch.Count -gt 0){
      $sortedH = @($cch | Where-Object { $_.cTime } | Sort-Object { [int64]$_.cTime } -Descending)
      $closs = 0; $cstop = $false
      foreach($x in $sortedH){ if($cstop){ break }; if([double]$x.pnl -lt 0){ $closs++ } else { $cstop = $true } }
      if($closs -ge $script:coinCooldownConsecLosses){
        Write-Output ('{"info":"coin-cooldown-hist ' + $inst + ' ' + $closs + '连亏 拒绝开仓"}')
        return @{ok=$false; reason=("coin-cooldown-hist:{0}({1}连亏)" -f $inst,$closs)}
      }
    }
  } catch {}
  # 反向持仓保护
  if($direction -eq 'LONG' -and $curSz -lt 0){ return @{ok=$false; reason='has-opposite-short'} }
  if($direction -eq 'SHORT' -and $curSz -gt 0){ return @{ok=$false; reason='has-opposite-long'} }
  # BTC 方向过滤：多单遇 BTC 1H SHORT、空单遇 BTC 1H LONG -> 跳过
  if($script:btcTrend -eq 'SHORT' -and $direction -eq 'LONG'){ return @{ok=$false; reason="btc-filter(BTC-1H=SHORT)"} }
  if($script:btcTrend -eq 'LONG' -and $direction -eq 'SHORT'){ return @{ok=$false; reason="btc-filter(BTC-1H=LONG)"} }
  # [oiq-2026-11-04] 四象限过滤：不逆着"增仓方向"做（默认关闭；该币无数据则放行）
  if($oiQuadOn -and $script:oiQuad -and $script:oiQuad.ContainsKey($inst)){
    $oq = $script:oiQuad[$inst]
    $oqQ = [string]$oq.quad
    if($direction -eq 'LONG' -and ($oiQuadBlockLong -contains $oqQ)){
      $script:oiQuadHit = $script:oiQuadHit + 1
      return @{ok=$false; reason=("oi-quad-block LONG:{0}({1} 价{2}% OI{3}%)" -f $inst, $oqQ, $oq.dp, $oq.doi)}
    }
    if($direction -eq 'SHORT' -and ($oiQuadBlockShort -contains $oqQ)){
      $script:oiQuadHit = $script:oiQuadHit + 1
      return @{ok=$false; reason=("oi-quad-block SHORT:{0}({1} 价{2}% OI{3}%)" -f $inst, $oqQ, $oq.dp, $oq.doi)}
    }
  }

  # per-coin 覆盖（杠杆/移动止损按币种差异化）
  $pc = $null
  if($perCoin -and $perCoin[$inst]){ $pc = $perCoin[$inst] }
  # 高价币自动按大币处理(2026-09-04): 现价 > risk.highPriceTh(默认500) 且配置了 risk.highPriceMarginUsdt → 杠杆30x + 固定保证金档(同 perCoin 大币, 跳过风险预算/上下限); 小账户(share 未配置)=不启用
  $dynBig = $false
  $hpMargin = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.highPriceMarginUsdt){ [double]$cfg.risk.highPriceMarginUsdt } else { 0 }
  $hpTh = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.highPriceTh){ [double]$cfg.risk.highPriceTh } else { 500 }
  if($hpMargin -gt 0 -and $price -gt $hpTh){ $dynBig = $true }
  $lever = if($direction -eq 'LONG'){
    if($pc -and $pc.leverage){ [int]$pc.leverage } elseif($dynBig){ 30 } else { $longLever }
  } else {
    if($pc -and $pc.shortLeverage){ [int]$pc.shortLeverage } elseif($dynBig){ 30 } else { $shortLever }
  }
  $trailRatio = if($pc -and $pc.trailStopRatio){ [double]$pc.trailStopRatio } else { $shortTrailRatio }
  # perCoin.noProtect(高杠杆手动管理币, 2026-09-02): 裸开——不挂OCO/移动止损、不进台账(不受时间止损/盈亏平衡管理), 由用户自行止盈止损
  $naked = ($pc -and $pc.noProtect)
  # 高位做空结构止损(2026-09-04): 组合B背离空 / ALT:动量爆发追踪反向做空(SHORT) → 记录开仓时 1H 参考高点, 止损=破新高才走(max(7%, 高点+0.5%))
  # 距离上限: perCoin/高价大币(30x 高杠杆)收窄到 10%(单笔最多亏 ~10%×名义), 其余用全局 structSlMaxDistPct(默认15)
  $structRefHigh = 0
  if($structSlEnabled -and $direction -eq 'SHORT' -and ($srcKey -like '组合B:*' -or $srcKey -eq 'ALT:动量爆发追踪')){
    $structRefHigh = Get-RefHigh $swapId
    if($structRefHigh -gt 0){ Write-Host ('{"info":"struct-sl-short ' + $swapId + ' src=' + $srcKey + ' refHigh=' + $structRefHigh + '"}') }
  }
  $structCapPct = $structSlMaxDistPct
  if($srcKey -like '组合B:*' -or $srcKey -eq 'ALT:动量爆发追踪'){
    if($pc){ $structCapPct = if($pc.structSlMaxDistPct){ [double]$pc.structSlMaxDistPct } else { 10 } }
    elseif($dynBig){ $structCapPct = 10 }
  }
  # 空头护盾(2026-09-04, 前瞻试验): 高位空(SHORT 且 srcKey 组合B/ALT动量范围) 开仓前查资金费率/OI 并记入日志;
  # config.risk.fundingShieldOn=true 时费率 < fundingShieldFloor(默认 -0.0001/期=空头拥挤逼空风险) → 跳过开仓; 默认关(先攒 2-4 周数据评估再开)
  $fundRec = $null
  if($direction -eq 'SHORT' -and ($srcKey -like '组合B:*' -or $srcKey -eq 'ALT:动量爆发追踪')){
    $fundRec = Get-FundingOI $swapId
    if($fundRec){
      Write-Host ('{"info":"funding ' + $swapId + ' rate=' + $fundRec.funding + ' oi=' + $fundRec.oi + ' src=' + $srcKey + '"}')
      $shieldOn = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.fundingShieldOn){ [bool]$cfg.risk.fundingShieldOn } else { $false }
      if($shieldOn){
        $floor = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.fundingShieldFloor){ [double]$cfg.risk.fundingShieldFloor } else { -0.0001 }
        if($fundRec.funding -lt $floor){ return @{ok=$false; reason=('funding-squeeze-shield(' + $fundRec.funding + ')')} }
      }
    }
  }
  # 双向持仓模式(实盘用户账户): 开仓/算法单需显式 posSide; 但全仓模式设置杠杆不带 posSide(按币种统一)
  # 注意: 必须用数组参数拼接(--posSide 独立 token), 不能拼进 tdMode/reduceOnly
  $psArgs = @()
  if($isHedgeMode){ $psArgs = @('--posSide', $(if($direction -eq 'LONG'){ 'long' } else { 'short' })) }
  $psArgs += $aiBcArgs   # AI Builder attribution
  $lv = & $okx --json swap leverage --instId $swapId --lever $lever --mgnMode cross 2>$null | ConvertFrom-Json
  if(-not ($lv -and $lv[0] -and [string]$lv[0].lever)){ return @{ok=$false; reason='leverage-fail'} }

  # ===== 仓位计算 =====
  # 动态权益: 实时余额优先
  $dynEq = $totalEquity
  $balNow = & $okx --json account balance 2>$null | ConvertFrom-Json
  if($balNow -and $balNow[0] -and $balNow[0].totalEq){ try { $dynEq = [double]$balNow[0].totalEq } catch {} }
  # 可用资金门槛(2026-09-15 用户要求): 可用保证金 < risk.minAvailEqUsdt(默认50U) → 暂停开新单(已有持仓不受影响)
  $minAvail = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.minAvailEqUsdt){ [double]$cfg.risk.minAvailEqUsdt } else { 50 }
  if($minAvail -gt 0){
    $availNow = 0.0
    if($balNow -and $balNow[0]){
      foreach($fld in @('availEq','availBal')){
        try { if($availNow -le 0){ $v = [double]$balNow[0].$fld; if($v -gt 0){ $availNow = $v } } } catch {}
      }
      if($availNow -le 0){
        try { foreach($d in @($balNow[0].details)){ try { $v = [double]$d.availEq; if($v -gt 0){ $availNow += $v } } catch {} } } catch {}
      }
    }
    if($availNow -lt $minAvail){ return @{ok=$false; reason=("avail-low({0}U<{1}U)" -f [math]::Round($availNow,2), $minAvail)} }
  }
  $riskPct = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.perTradeRiskPct){ [double]$cfg.risk.perTradeRiskPct } else { 0.10 }
  $notional = [math]::Round($dynEq * $riskPct, 2)   # 旧默认: 权益×10%
  # perCoin.marginUsdt(固定保证金覆盖, 2026-09-02): 名义 = 保证金 × 杠杆, 跳过 min/max 与风险预算
  $marginFixed = $false
  if($pc -and $null -ne $pc.marginUsdt -and [double]$pc.marginUsdt -gt 0){
    $notional = [math]::Round([double]$pc.marginUsdt * $lever, 2)
    $marginFixed = $true
  } elseif($dynBig){
    # 高价大币(现价>500): 固定保证金档(默认10U, 可配置 highPriceMarginUsdt 5-10) × 30x
    $notional = [math]::Round($hpMargin * $lever, 2)
    $marginFixed = $true
    Write-Host ('{"info":"dynbig ' + $swapId + ' px=' + $price + ' lever=' + $lever + ' margin=' + $hpMargin + ' notional=' + $notional + '"}')
  }
  # 波动率 regime 系数(2026-09-04, config.risk.volRegimeOn): 1H ATR20 vs 约40根前基准, 高波×0.7 / 低波×1.1 (Carver 波动率目标化简化版; perCoin 固定保证金不参与)
  $volFactor = 1.0
  $volRegimeOn = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.volRegimeOn){ [bool]$cfg.risk.volRegimeOn } else { $false }
  if($volRegimeOn -and -not $marginFixed){ $volFactor = Get-VolFactor $swapId }
  # 风险预算模式(2026-09-04, config.risk.tradeRiskEqPct>0): 每笔风险额=权益×pct, 名义=风险额÷实际止损距离(固定或结构止损), ×regime系数
  $riskMode = $false
  $tradeRiskEqPct = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.tradeRiskEqPct){ [double]$cfg.risk.tradeRiskEqPct } else { 0 }
  if(-not $marginFixed -and $tradeRiskEqPct -gt 0){
    $riskMode = $true
    $slDistPct = $mainSlPct
    if($direction -eq 'SHORT' -and $structRefHigh -gt 0){
      $ss = Get-StructSlPx $price $structRefHigh $structCapPct
      if($ss -gt 0){ $slDistPct = ($ss / $price) - 1 }
      if($slDistPct -lt $mainSlPct){ $slDistPct = $mainSlPct }
    }
    if($slDistPct -le 0.001){ $slDistPct = $mainSlPct }
    $riskU = $dynEq * $tradeRiskEqPct
    if($srcKey -and $boostStrategies -contains $srcKey){ $riskU = $riskU * $boostRate }   # 高胜率加成=放大风险预算
    $notional = $riskU / $slDistPct
    $notional = $notional * $volFactor
  }
  # 单笔名义上限: 优先 config.risk.maxNotionalCap, 默认账户30%
  $maxNotional = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.maxNotionalCap){ [double]$cfg.risk.maxNotionalCap } else { $dynEq * 0.30 }
  if(-not $marginFixed -and $notional -gt $maxNotional){ $notional = $maxNotional }
  # 最小下单: 风险模式用 risk.minRiskNotional(默认5, 放开旧 50 下限让宽止损小仓可下); 旧模式用 rules.minNotional
  if(-not $marginFixed){
    if($riskMode){
      $minRiskNotional = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.minRiskNotional){ [double]$cfg.risk.minRiskNotional } else { 5 }
      if($notional -lt $minRiskNotional){ $notional = $minRiskNotional }
    } else {
      $minNotional = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.minNotional){ [double]$cfg.rules.minNotional } else { 5 }
      if($notional -lt $minNotional){ $notional = $minNotional }
    }
  }
  # 高胜率加成: 风险模式已在 riskU×boost 体现; 非风险模式(非perCoin)保留乘法加成
  if(-not $riskMode -and -not $marginFixed -and $srcKey -and $boostStrategies -contains $srcKey){
    $notional = [math]::Round($notional * $boostRate, 2)
    $maxNotional = $maxNotional * $boostRate
    if($notional -gt $maxNotional){ $notional = $maxNotional }
  }
  # 固定名义(2026-09-08, config.risk.fixedNotionalUsdt>0): 普通单固定名义(如 50U), 不随权益浮动(山寨10x→保证金5U);
  # perCoin/高价大币(marginFixed)不受影响; risk-on 空单缩量在下方仍生效
  $fixedN = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.fixedNotionalUsdt){ [double]$cfg.risk.fixedNotionalUsdt } else { 0 }
  if($fixedN -gt 0 -and -not $marginFixed){ $notional = $fixedN }
  $notional = [math]::Round($notional, 2)
  # risk-on 空单缩量(2026-09-07; 2026-09-12 调整: 组合B顶背离不缩量——实测其风险收益更好): risk-on 时其余保留空单名义 ×riskOnShortScale(0.7); perCoin 固定保证金不缩
  if($script:riskOn -and $direction -eq 'SHORT' -and -not $marginFixed -and $script:riskOnShortScale -gt 0 -and ($srcKey -notlike '组合B:*')){
    $notional = [math]::Round($notional * $script:riskOnShortScale, 2)
  }
  if($riskMode -or $volFactor -ne 1.0){ Write-Host ('{"info":"size ' + $swapId + ' ' + $direction + ' notional=' + $notional + ' riskMode=' + $riskMode + ' volF=' + $volFactor + '"}') }

  # 限价入场: 低于现价买入(LONG) / 高于现价卖出(SHORT); 不带附带TP/SL(由挂单追踪成交后补挂OCO全平保护)
  if($useLimit -and -not $forceMarket){
    if($direction -eq 'LONG'){
      $entryPx = [math]::Round($price * (1 - $limitDistLong), 6)
      $coid = New-StratClOrdId 'L'
      $placeArgs = @('swap','place','--instId',$swapId,'--side','buy','--ordType','limit','--px',"$entryPx",'--sz',"$notional",'--tgtCcy','quote_ccy','--tdMode','cross','--clOrdId',$coid) + $psArgs
      $res = & $okx --json @placeArgs 2>$null | ConvertFrom-Json
      if(-not ($res -and $res[0] -and [string]$res[0].sCode -eq '0')){ return @{ok=$false; reason=if($res -and $res[0]){[string]$res[0].sMsg}else{'place-fail'}} }
      Add-OrderEvent 'open' @{ clOrdId=$coid; ordId=[string]$res[0].ordId; instId=$swapId; side='buy'; posSide='long'; ordType='limit'; px=$entryPx; sz=$notional; notionalUsdt=$notional; reduceOnly=$false; strategy=$srcKey; signalTs=$ts; sigPrice=$price; round=$script:round; sCode='0'; why=('限价开多 ' + $srcKey) }
      # noProtect 裸开: 不记录限价追踪(成交后也无保护), 不进台账
      if($naked){ return @{ok=$true; type='swap-long'; lever=$lever; notionalUsdt=$notional; entryPx=$entryPx; ordId=[string]$res[0].ordId; clOrdId=$coid; pending='limit-naked'; naked=$true} }
      # 记录限价挂单(成交后由 Check-LimitOrders 补挂 OCO 全平保护)
      $loFile = Join-Path $baseDir ('limit-orders' + $suffix + '.json')
      $los = @()
      if(Test-Path $loFile){ try { $los = @(Get-Content $loFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch {} }
      # [timeout-20261105] 超时撤单按"挂单时间"计时(此前用信号/轮次时间 ts, 会提前 6+ 分钟撤单)
      $placedTs = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
      $los += [ordered]@{ instId=$swapId; ordId=[string]$res[0].ordId; clOrdId=$coid; dir='LONG'; entryPx=$entryPx; notional=$notional; ts=$ts; placedTs=$placedTs; srcKey=$srcKey }
      $los | ConvertTo-Json -Depth 4 | Out-File $loFile -Encoding UTF8
      Add-StrategyPosition $swapId 'long' $entryPx $notional 'pending' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $srcKey $coid
      return @{ok=$true; type='swap-long'; lever=$lever; notionalUsdt=$notional; entryPx=$entryPx; ordId=[string]$res[0].ordId; clOrdId=$coid; pending='limit'}
    } else {
      $entryPx = [math]::Round($price * (1 + $limitDistShort), 6)
      $coid = New-StratClOrdId 'S'
      $placeArgs = @('swap','place','--instId',$swapId,'--side','sell','--ordType','limit','--px',"$entryPx",'--sz',"$notional",'--tgtCcy','quote_ccy','--tdMode','cross','--clOrdId',$coid) + $psArgs
      $res = & $okx --json @placeArgs 2>$null | ConvertFrom-Json
      if(-not ($res -and $res[0] -and [string]$res[0].sCode -eq '0')){ return @{ok=$false; reason=if($res -and $res[0]){[string]$res[0].sMsg}else{'place-fail'}} }
      Add-OrderEvent 'open' @{ clOrdId=$coid; ordId=[string]$res[0].ordId; instId=$swapId; side='sell'; posSide='short'; ordType='limit'; px=$entryPx; sz=$notional; notionalUsdt=$notional; reduceOnly=$false; strategy=$srcKey; signalTs=$ts; sigPrice=$price; round=$script:round; sCode='0'; why=('限价开空 ' + $srcKey) }
      if($naked){ return @{ok=$true; type='swap-short'; lever=$lever; notionalUsdt=$notional; entryPx=$entryPx; ordId=[string]$res[0].ordId; clOrdId=$coid; pending='limit-naked'; naked=$true} }
      $loFile = Join-Path $baseDir ('limit-orders' + $suffix + '.json')
      $los = @()
      if(Test-Path $loFile){ try { $los = @(Get-Content $loFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch {} }
      # [timeout-20261105] 超时撤单按"挂单时间"计时
      $placedTs = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
      $los += [ordered]@{ instId=$swapId; ordId=[string]$res[0].ordId; clOrdId=$coid; dir='SHORT'; entryPx=$entryPx; notional=$notional; ts=$ts; placedTs=$placedTs; slRefHigh=$structRefHigh; srcKey=$srcKey }
      $los | ConvertTo-Json -Depth 4 | Out-File $loFile -Encoding UTF8
      Add-StrategyPosition $swapId 'short' $entryPx $notional 'pending' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $srcKey $coid
      return @{ok=$true; type='swap-short'; lever=$lever; notionalUsdt=$notional; entryPx=$entryPx; ordId=[string]$res[0].ordId; clOrdId=$coid; pending='limit'}
    }
  }

  if($direction -eq 'LONG'){
    $coid = New-StratClOrdId 'L'
    $placeArgs = @('swap','place','--instId',$swapId,'--side','buy','--ordType','market','--sz',"$notional",'--tgtCcy','quote_ccy','--tdMode','cross','--clOrdId',$coid) + $psArgs
    $res = & $okx --json @placeArgs 2>$null | ConvertFrom-Json
    if(-not ($res -and $res[0] -and [string]$res[0].sCode -eq '0')){ return @{ok=$false; reason=if($res -and $res[0]){[string]$res[0].sMsg}else{'place-fail'}} }
    Add-OrderEvent 'open' @{ clOrdId=$coid; ordId=[string]$res[0].ordId; instId=$swapId; side='buy'; posSide='long'; ordType='market'; px=$price; sz=$notional; notionalUsdt=$notional; reduceOnly=$false; strategy=$srcKey; signalTs=$ts; sigPrice=$price; round=$script:round; sCode='0'; why=('市价开多 ' + $srcKey) }
    # noProtect 裸开: 市价成交后不挂任何保护, 不进台账
    if($naked){ return @{ok=$true; type='swap-long'; lever=$lever; notionalUsdt=$notional; ordId=[string]$res[0].ordId; clOrdId=$coid; naked=$true} }
    $tpPx = [math]::Round($price * (1 + $mainTpPct), 6); $slPx = [math]::Round($price * (1 - $mainSlPct), 6)
    $ocoArgs = @('swap','algo','place','--instId',$swapId,'--side','sell','--ordType','oco','--tpTriggerPx',"$tpPx",'--tpOrdPx=-1','--slTriggerPx',"$slPx",'--slOrdPx=-1','--tdMode','cross','--reduceOnly','--closeFraction','1') + $psArgs
    $oco = & $okx --json @ocoArgs 2>$null | ConvertFrom-Json
    # 多单移动止损(2026-09-01; risk.enableTrail=false 时去掉, 2026-09-05 —— 复盘显示 4% trail 扫掉均值回归单)
    $trail = $null
    if($enableTrail){
      Start-Sleep -Milliseconds 800
      $szC = Get-PosSz $swapId
      $trailArgs = @('swap','algo','trail','--instId',$swapId,'--side','sell','--sz',"$szC",'--callbackRatio',"$trailRatio",'--tdMode','cross','--reduceOnly') + $psArgs
      $trail = if($szC -gt 0){ & $okx --json @trailArgs 2>$null | ConvertFrom-Json } else { $null }
    }
    # 台账: 记录策略自营持仓(供时间止损/盈亏平衡)
    Add-StrategyPosition $swapId 'long' $price $notional 'open' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $srcKey $coid
    return @{ok=$true; type='swap-long'; lever=$lever; notionalUsdt=$notional; ordId=[string]$res[0].ordId; clOrdId=$coid; tp=$tpPx; sl=$slPx; oco=if($oco -and $oco[0]){[string]$oco[0].algoId}else{'fail'}; trail=if($trail -and $trail[0]){[string]$trail[0].algoId}elseif($enableTrail){'fail'}else{'off'}}
  } else {
    $coid = New-StratClOrdId 'S'
    $placeArgs = @('swap','place','--instId',$swapId,'--side','sell','--ordType','market','--sz',"$notional",'--tgtCcy','quote_ccy','--tdMode','cross','--clOrdId',$coid) + $psArgs
    $res = & $okx --json @placeArgs 2>$null | ConvertFrom-Json
    if(-not ($res -and $res[0] -and [string]$res[0].sCode -eq '0')){ return @{ok=$false; reason=if($res -and $res[0]){[string]$res[0].sMsg}else{'place-fail'}} }
    Add-OrderEvent 'open' @{ clOrdId=$coid; ordId=[string]$res[0].ordId; instId=$swapId; side='sell'; posSide='short'; ordType='market'; px=$price; sz=$notional; notionalUsdt=$notional; reduceOnly=$false; strategy=$srcKey; signalTs=$ts; sigPrice=$price; round=$script:round; sCode='0'; why=('市价开空 ' + $srcKey) }
    if($naked){ return @{ok=$true; type='swap-short'; lever=$lever; notionalUsdt=$notional; ordId=[string]$res[0].ordId; clOrdId=$coid; naked=$true} }
    $tpPx = [math]::Round($price * (1 - $mainTpPct), 6)
    $slPx = [math]::Round($price * (1 + $mainSlPct), 6)
    # 高位做空结构止损: 破开仓时参考新高才走(见 Get-StructSlPx)
    $structSl = Get-StructSlPx $price $structRefHigh $structCapPct
    if($structSl -gt 0){ $slPx = $structSl }
    $ocoArgs = @('swap','algo','place','--instId',$swapId,'--side','buy','--ordType','oco','--tpTriggerPx',"$tpPx",'--tpOrdPx=-1','--slTriggerPx',"$slPx",'--slOrdPx=-1','--tdMode','cross','--reduceOnly','--closeFraction','1') + $psArgs
    $oco = & $okx --json @ocoArgs 2>$null | ConvertFrom-Json
    # 移动止损 sz 必须是张数(算法单不支持 quote_ccy); 从刚开的持仓取张数 (risk.enableTrail=false 去掉, 2026-09-05)
    $trail = $null
    if($enableTrail){
      Start-Sleep -Milliseconds 800
      $szC = Get-PosSz $swapId
      $trailArgs = @('swap','algo','trail','--instId',$swapId,'--side','buy','--sz',"$szC",'--callbackRatio',"$trailRatio",'--tdMode','cross','--reduceOnly') + $psArgs
      $trail = if($szC -gt 0){ & $okx --json @trailArgs 2>$null | ConvertFrom-Json } else { $null }
    }
    Add-StrategyPosition $swapId 'short' $price $notional 'open' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $srcKey $coid
    return @{ok=$true; type='swap-short'; lever=$lever; notionalUsdt=$notional; ordId=[string]$res[0].ordId; clOrdId=$coid; tp=$tpPx; sl=$slPx; trail=if($trail -and $trail[0]){[string]$trail[0].algoId}elseif($enableTrail){'fail'}else{'off'}; funding=if($fundRec){$fundRec.funding}else{$null}; oi=if($fundRec){$fundRec.oi}else{$null}}
  }
}

# 取当前持仓张数(算法单 trail 的 sz 必须是张数, 不支持 quote_ccy)
function Get-PosSz($instId){
  try {
    $ps = & $okx --json swap positions $instId 2>$null | ConvertFrom-Json
    $tot = 0.0
    if($ps){ foreach($pp in $ps){ if($pp -and $pp.pos){ $tot += [math]::Abs([double]$pp.pos) } } }
    return $tot
  } catch { return 0 }
}

# 限价挂单追踪: 成交后补挂 OCO(closeFraction 1 全平) + 移动止损
function Protect-NakedStrategyPositions {
  # [naked-2026-11-05] 裸仓兜底：策略台账里 status=open 的持仓若查不到 algo 单 → 按现价补挂 OCO
  #   起因：2026-11-04 PARTI 限价单撤单静默失败、21:38 才成交，成交后无人补挂保护，裸仓到 -56%。
  #   本函数每轮跑一次，任何原因导致的裸仓（撤单竞态/重启/静默失败/对账补回）都能兜住。
  $attached = @()
  try {
    $led = @(Get-StrategyLedger)
    $openL = @($led | Where-Object { $_ -and $_.status -eq 'open' -and $_.instId })
    if($openL.Count -eq 0){ return $attached }
    $psAll = & $okx --json swap positions 2>$null | ConvertFrom-Json
    $posL = @(@($psAll) | Where-Object { $_ -and $_.pos -and [math]::Abs([double]$_.pos) -gt 0 })
    if($posL.Count -eq 0){ return $attached }
    $algAll = & $okx --json swap algo orders 2>$null | ConvertFrom-Json
    $protSet = @{}
    foreach($a in @($algAll)){ if($a -and $a.instId){ $protSet[[string]$a.instId] = $true } }
    foreach($e in $openL){
      $inst = [string]$e.instId
      if(-not $inst){ continue }
      if($protSet.ContainsKey($inst)){ continue }
      $p = @($posL | Where-Object { $_.instId -eq $inst -and [string]$_.posSide -eq [string]$e.posSide }) | Select-Object -First 1
      if(-not $p){ continue }
      $lastPx = 0.0
      try { $lastPx = [double]$p.last } catch { $lastPx = 0.0 }
      if($lastPx -le 0){ continue }
      $isLong = ([string]$e.posSide -eq 'long')
      $tpPx = [math]::Round($lastPx * $(if($isLong){ 1 + $mainTpPct } else { 1 - $mainTpPct }), 6)
      $slPx = [math]::Round($lastPx * $(if($isLong){ 1 - $mainSlPct } else { 1 + $mainSlPct }), 6)
      $side = if($isLong){ 'sell' } else { 'buy' }
      $ps2 = @()
      if($isHedgeMode){ $ps2 = @('--posSide', [string]$e.posSide) }
      $ocoA = @('swap','algo','place','--instId',$inst,'--side',$side,'--ordType','oco','--tpTriggerPx',"$tpPx",'--tpOrdPx=-1','--slTriggerPx',"$slPx",'--slOrdPx=-1','--tdMode','cross','--reduceOnly','--closeFraction','1') + $ps2
      $ocR = & $okx --json @ocoA 2>$null | ConvertFrom-Json
      if($ocR -and $ocR[0] -and [string]$ocR[0].sCode -eq '0'){
        $attached += $inst
        Add-OrderEvent 'protect' @{ instId=$inst; posSide=[string]$e.posSide; ordType='oco'; why=('裸仓巡检补挂保护 现价=' + $lastPx + ' tp=' + $tpPx + ' sl=' + $slPx); round=$script:round }
        Write-Output ('{"warn":"naked-protected ' + $inst + ' ' + [string]$e.posSide + ' ' + $lastPx + ' tp=' + $tpPx + ' sl=' + $slPx + '"}')
      } else {
        $sMsg = if($ocR -and $ocR[0]){ [string]$ocR[0].sMsg } else { 'no-resp' }
        Write-Output ('{"warn":"naked-protect-failed ' + $inst + ' ' + ($sMsg -replace '"','') + '"}')
      }
    }
  } catch { Write-Output '{"warn":"naked-sweep-error"}' }
  return $attached
}

function Check-LimitOrders {
  # PauseSwitch20260920: 本函数在两轮之间每 60 秒跑一次 -> 暂停后 60 秒内即可撤销未成交挂单
  try { Sync-TradingSwitch | Out-Null } catch {}
  $ordersFile = Join-Path $baseDir ('limit-orders' + $suffix + '.json')
  if(-not (Test-Path $ordersFile)){ return @() }
  $orders = @()
  try { $orders = @(Get-Content $ordersFile -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return @() }
  if($orders.Count -eq 0){ return @() }
  $remain = New-Object System.Collections.Generic.List[object]
  $done = @()
  foreach($lo in $orders){
    try {
      $ord = & $okx --json swap get --instId $lo.instId --ordId $lo.ordId 2>$null | ConvertFrom-Json
      $state = if($ord -and $ord[0]){ [string]$ord[0].state } else { '' }
      if($state -eq 'filled'){
        $px = [double]$lo.entryPx
        $notional = [double]$lo.notional
        $dir = [string]$lo.dir
        $psArgs = @()
        if($isHedgeMode){ $psArgs = @('--posSide', $(if($dir -eq 'LONG'){ 'long' } else { 'short' })) }
        $psArgs += $aiBcArgs   # AI Builder attribution
        if($dir -eq 'LONG'){
          $tpPx = [math]::Round($px * (1 + $mainTpPct), 6); $slPx = [math]::Round($px * (1 - $mainSlPct), 6)
          $ocoArgs = @('swap','algo','place','--instId',$lo.instId,'--side','sell','--ordType','oco','--tpTriggerPx',"$tpPx",'--tpOrdPx=-1','--slTriggerPx',"$slPx",'--slOrdPx=-1','--tdMode','cross','--reduceOnly','--closeFraction','1') + $psArgs
          & $okx --json @ocoArgs 2>$null | Out-Null
          # 多单移动止损(与空单一致, 2026-09-01); OCO 后等 800ms 再挂(否则瞬时被拒, 2026-09-04 修复); risk.enableTrail=false 时不挂(2026-09-05)
          if($enableTrail){
            Start-Sleep -Milliseconds 800
            $szC = Get-PosSz $lo.instId
            $trailArgs = @('swap','algo','trail','--instId',$lo.instId,'--side','sell','--sz',"$szC",'--callbackRatio',"$trailRatio",'--tdMode','cross','--reduceOnly') + $psArgs
            if($szC -gt 0){
              $tr = & $okx --json @trailArgs 2>$null | ConvertFrom-Json
              Write-Output ('{"info":"trail-attach ' + $lo.instId + ' ' + $(if($tr -and $tr[0] -and [string]$tr[0].sCode -eq '0'){ 'ok algoId=' + [string]$tr[0].algoId } elseif($tr -and $tr[0]){ 'fail ' + [string]$tr[0].sMsg } else { 'fail no-resp' }) + '"}')
            }
          }
        } else {
          $tpPx = [math]::Round($px * (1 - $mainTpPct), 6)
          $slPx = [math]::Round($px * (1 + $mainSlPct), 6)
          # 高位做空结构止损: 破开仓时参考新高才走(限价单 slRefHigh 由开仓时记录); perCoin 大币上限收窄到10%
          $refH = 0.0
          if($lo.slRefHigh){ try { $refH = [double]$lo.slRefHigh } catch { $refH = 0.0 } }
          $capPct = $structSlMaxDistPct
          $pc2 = if($perCoin -and $perCoin[$lo.instId]){ $perCoin[$lo.instId] } else { $null }
          if($pc2){ $capPct = if($pc2.structSlMaxDistPct){ [double]$pc2.structSlMaxDistPct } else { 10 } }
          $structSl = Get-StructSlPx $px $refH $capPct
          if($structSl -gt 0){ $slPx = $structSl }
          $ocoArgs = @('swap','algo','place','--instId',$lo.instId,'--side','buy','--ordType','oco','--tpTriggerPx',"$tpPx",'--tpOrdPx=-1','--slTriggerPx',"$slPx",'--slOrdPx=-1','--tdMode','cross','--reduceOnly','--closeFraction','1') + $psArgs
          & $okx --json @ocoArgs 2>$null | Out-Null
          # 移动止损 sz 按持仓张数(算法单不支持 quote_ccy); OCO 后等 800ms 再挂(2026-09-04 修复瞬时拒绝); risk.enableTrail=false 时不挂(2026-09-05)
          if($enableTrail){
            Start-Sleep -Milliseconds 800
            $szC = Get-PosSz $lo.instId
            $trailArgs = @('swap','algo','trail','--instId',$lo.instId,'--side','buy','--sz',"$szC",'--callbackRatio',"$trailRatio",'--tdMode','cross','--reduceOnly') + $psArgs
            if($szC -gt 0){
              $tr = & $okx --json @trailArgs 2>$null | ConvertFrom-Json
              Write-Output ('{"info":"trail-attach ' + $lo.instId + ' ' + $(if($tr -and $tr[0] -and [string]$tr[0].sCode -eq '0'){ 'ok algoId=' + [string]$tr[0].algoId } elseif($tr -and $tr[0]){ 'fail ' + [string]$tr[0].sMsg } else { 'fail no-resp' }) + '"}')
            }
          }
        }
        # 限价成交 → 台账 pending 转 open
        Set-LedgerOpen $lo.instId $(if($dir -eq 'LONG'){ 'long' } else { 'short' })
        Add-OrderEvent 'fill' @{ clOrdId=[string]$lo.clOrdId; ordId=[string]$lo.ordId; instId=$lo.instId; posSide=$(if($dir -eq 'LONG'){ 'long' } else { 'short' }); ordType='limit'; px=$px; sz=$notional; notionalUsdt=$notional; strategy=[string]$lo.srcKey; signalTs=[string]$lo.ts; round=$script:round; why='限价单成交→补挂保护' }
        Add-OrderEvent 'protect' @{ instId=$lo.instId; ordId=[string]$lo.ordId; clOrdId=[string]$lo.clOrdId; posSide=$(if($dir -eq 'LONG'){ 'long' } else { 'short' }); ordType='oco'; strategy=[string]$lo.srcKey; why='成交后补挂 OCO 全平保护' }
        $done += @{ instId=$lo.instId; action='attached' }
      } elseif($state -eq 'canceled' -or $state -eq 'cancelled' -or $state -eq '' -or $state -eq 'partially_filled') {
        # 已取消/异常 → 移除(部分成交的仓位靠市场保护? 保留检查)
        if($state -eq 'partially_filled'){ $remain.Add($lo) }
      } else {
        # PauseSwitch20260920: 暂停开单期间, 未成交的"入场限价单"立即撤销 —— 否则一旦成交就等于开了新仓(与禁止开单矛盾)。
        # 撤的只是未成交入场单, 不涉及任何已成交持仓, 【不是平仓】。
        if(-not $script:allowOpen -and $script:cancelPendingOnPause){
          # [naked-2026-11-05] 撤单必须校验：原来丢弃输出+无条件删台账 ⇒ 撤失败也当成功，订单稍后成交就成裸仓
          $ocRes = (& $okx --json swap cancel --instId $lo.instId --ordId $lo.ordId 2>$null | Out-String)
          $ocOk = $false
          try { $ocJ = $ocRes | ConvertFrom-Json; if($ocJ -and $ocJ[0] -and [string]$ocJ[0].sCode -eq '0'){ $ocOk = $true } } catch {}
          if(-not $ocOk){
            $ocMsg = ($ocRes -replace '\s+', ' ').Trim()
            Write-Output ('{"warn":"pause-cancel-failed ' + $lo.instId + ' ' + $lo.dir + ' resp=' + $ocMsg.Substring(0, [Math]::Min(140, $ocMsg.Length)) + '"}')
            $remain.Add($lo)
            continue
          }
          Remove-StrategyPosition $lo.instId $(if($lo.dir -eq 'LONG'){ 'long' } else { 'short' })
          Add-OrderEvent 'pause-cancel' @{ instId=$lo.instId; ordId=[string]$lo.ordId; clOrdId=[string]$lo.clOrdId; posSide=$(if($lo.dir -eq 'LONG'){ 'long' } else { 'short' }); strategy=[string]$lo.srcKey; signalTs=[string]$lo.ts; why='暂停开单期间撤销未成交入场单(非平仓)'; round=$script:round }
          Write-Output ('{"info":"limit-canceled-by-pause ' + $lo.instId + ' ' + $lo.dir + ' ts=' + $lo.ts + '"}')
          $done += @{ instId=$lo.instId; action='limit-canceled-by-pause' }
          continue
        }
        # live 未成交: 超过 limitOrderTimeoutMin(默认10分钟, 按挂单时间 placedTs 计) → 直接撤单放弃该信号(2026-09-08 不转市价; 2026-11-05 改挂单时间计时)
        $timeoutMin = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.limitOrderTimeoutMin){ [double]$cfg.risk.limitOrderTimeoutMin } else { 10 }
        $expired = $false
        if($timeoutMin -gt 0 -and $lo.ts){
          # [timeout-20261105] 优先按挂单时间 placedTs 计时(旧记录无该字段则回退 ts)
          $ageTs = if($lo.placedTs){ [string]$lo.placedTs } else { [string]$lo.ts }
          try { if(((Get-Date) - [datetime]$ageTs).TotalMinutes -ge $timeoutMin){ $expired = $true } } catch {}
        }
        if($expired){
          # [naked-2026-11-05] 撤单必须校验：非 sCode=0 一律保留台账、下轮重试（PARTI 事故根因）
          $ocRes = (& $okx --json swap cancel --instId $lo.instId --ordId $lo.ordId 2>$null | Out-String)
          $ocOk = $false
          try { $ocJ = $ocRes | ConvertFrom-Json; if($ocJ -and $ocJ[0] -and [string]$ocJ[0].sCode -eq '0'){ $ocOk = $true } } catch {}
          if(-not $ocOk){
            $ocMsg = ($ocRes -replace '\s+', ' ').Trim()
            Write-Output ('{"warn":"timeout-cancel-failed ' + $lo.instId + ' ' + $lo.dir + ' resp=' + $ocMsg.Substring(0, [Math]::Min(140, $ocMsg.Length)) + '"}')
            $remain.Add($lo)
            continue
          }
          # 清 pending 台账(该信号放弃)
          Remove-StrategyPosition $lo.instId $(if($lo.dir -eq 'LONG'){ 'long' } else { 'short' })
          Add-OrderEvent 'timeout-cancel' @{ instId=$lo.instId; ordId=[string]$lo.ordId; clOrdId=[string]$lo.clOrdId; posSide=$(if($lo.dir -eq 'LONG'){ 'long' } else { 'short' }); strategy=[string]$lo.srcKey; signalTs=[string]$lo.ts; why=('限价单超过 ' + $timeoutMin + ' 分钟未成交, 撤单放弃该信号'); round=$script:round }
          Write-Output ('{"info":"limit-timeout-canceled ' + $lo.instId + ' ' + $lo.dir + ' ts=' + $lo.ts + '"}')
          $done += @{ instId=$lo.instId; action='limit-timeout-canceled' }
          # 不再 remain(避免每次轮询重复处理)
        } else {
          $remain.Add($lo)   # live: 继续等成交
        }
      }
    } catch { $remain.Add($lo) }
  }
  if($remain.Count -gt 0){ $remain.ToArray() | ConvertTo-Json -Depth 4 | Out-File $ordersFile -Encoding UTF8 }
  elseif(Test-Path $ordersFile){ Remove-Item $ordersFile -Force }
  return $done
}

# 三重障碍标签辅助(2026-09-04): 信号记录时算止盈/止损触发价(主15%/7%, 高位空含结构止损, 与开仓一致), 供 verify 判"先触TP/SL/超时"
function Get-BarrierPx($px, $dir, $src, $inst){
  try {
    if($px -le 0){ return @{tp=0.0; sl=0.0} }
    $tp = 0.0; $sl = 0.0
    if($dir -eq 'LONG'){
      $tp = [math]::Round($px * (1 + $mainTpPct), 6)
      $sl = [math]::Round($px * (1 - $mainSlPct), 6)
    } else {
      $tp = [math]::Round($px * (1 - $mainTpPct), 6)
      $sl = [math]::Round($px * (1 + $mainSlPct), 6)
      if($structSlEnabled -and ($src -like '组合B:*' -or $src -eq 'ALT:动量爆发追踪')){
        $refH = Get-RefHigh $inst
        if($refH -gt 0){
          $s2 = Get-StructSlPx $px $refH $structSlMaxDistPct
          if($s2 -gt 0){ $sl = $s2 }
        }
      }
    }
    return @{ tp=$tp; sl=$sl }
  } catch { return @{ tp=0.0; sl=0.0 } }
}

# 孤儿止盈止损清理(2026-09-04): 平仓后 OKX 不自动撤已附着的算法单(reduceOnly), 残留单可能误平未来同币新仓。
# 每轮结束时调用: 列出持仓+算法单, 撤掉"该币无持仓 或 持仓方向不匹配"的算法单; 保留有仓的保护单
function Cleanup-OrphanAlgos {
  try {
    $ps = & $okx --json swap positions 2>$null | ConvertFrom-Json
    $open = @{}
    if($ps){
      foreach($p in $ps){
        if($p -and $p.instId -and $p.pos -and [double]$p.pos -ne 0){
          $ik = [string]$p.instId; $sd = [string]$p.posSide
          if(-not $open.ContainsKey($ik)){ $open[$ik] = @{} }
          $open[$ik][$sd] = $true
        }
      }
    }
    $algos = & $okx --json swap algo orders 2>$null | ConvertFrom-Json
    if(-not $algos){ return }
    $canceled = 0
    foreach($a in $algos){
      if(-not $a -or -not $a.instId){ continue }
      $ik = [string]$a.instId
      $keep = $false
      if($open.ContainsKey($ik) -and $open[$ik].Count -gt 0){
        $as = [string]$a.posSide
        if($as -eq '' -or $as -eq 'net'){ $keep = $true }
        elseif($open[$ik].ContainsKey($as)){ $keep = $true }
      }
      if(-not $keep){
        $ot = [string]$a.ordType
        if($ot -eq ''){ $ot = if($a.callbackRatio){ 'move_order_stop' } else { 'oco' } }
        $r = & $okx --json swap algo cancel --instId $ik --algoId ([string]$a.algoId) --ordType $ot 2>$null | ConvertFrom-Json
        if($r -and $r[0] -and [string]$r[0].sCode -eq '0'){ $canceled++ }
      }
    }
    if($canceled -gt 0){ Write-Output ('{"info":"orphan-algos-canceled ' + $canceled + '"}') }
  } catch { Write-Output ('{"warn":"orphan-cleanup ' + $_.Exception.Message + '"}') }
}

# 动态反向策略集: 合并三盘验证store, 正向胜率 < 阈值 且 样本>=最小样本 → 该策略信号方向取反
# 结果缓存 30 分钟(reverse-state<suffix>.json): 避免每轮读取三盘大 store, 降低 1核服务器负担
# 返回 hashtable: 策略名 -> 当前正向胜率(%)
function Get-ReverseSet {
  $cacheFile = Join-Path $baseDir ('reverse-state' + $suffix + '.json')
  try {
    if(Test-Path $cacheFile){
      $c = Get-Content $cacheFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if($c -and $c.ts -and $c.map){
        $age = ((Get-Date) - [datetime]$c.ts).TotalMinutes
        if($age -lt 30){
          $rev = @{}
          foreach($p in $c.map.PSObject.Properties){ $rev[$p.Name] = [double]$p.Value }
          # revexclude-cache-fix-20261011: 缓存命中也要应用反向排除(否则改配置后最多 30 分钟不生效)
          if($script:reverseExclude -and $script:reverseExclude.Count -gt 0){ foreach($x in @($script:reverseExclude)){ if($rev.ContainsKey($x)){ [void]$rev.Remove($x) } } }
          return $rev
        }
      }
    }
  } catch {}
  $rev = @{}
  try {
    $g = @{}
    # 只统计实盘数据(live 实盘账户; share 模拟盘已关闭, 数据不参与决策) —— 2026-09-06 去掉 share
    foreach($sf in @('signal-verify-store-live.json')){
      $p = Join-Path $baseDir $sf
      if(-not (Test-Path $p)){ continue }
      try { $s = @(Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { continue }
      foreach($x in $s){
        if(-not $x -or -not $x.strategy){ continue }
        $st = [string]$x.strategy
        if($st -like '反向对照*' -or $st -eq 'TRADE' -or $st -like '反向:*' -or $st -like '组合A:*' -or $st -like '组合C:*'){ continue }
        if(-not $g.ContainsKey($st)){ $g[$st] = @{n=0; w=0} }
        $g[$st].n++
        if($x.result -eq 'WIN'){ $g[$st].w++ }
      }
    }
    foreach($k in $g.Keys){
      if($script:reverseExclude -and $script:reverseExclude -contains $k){ continue }  # 反向白名单排除, 2026-09-06
      if($g[$k].n -ge $reverseMinN){
        $rate = $g[$k].w / $g[$k].n * 100
        if($rate -lt $reverseTh){ $rev[$k] = [math]::Round($rate,1) }
      }
    }
    @{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); map=$rev } | ConvertTo-Json -Depth 3 | Out-File $cacheFile -Encoding UTF8
  } catch {}
  return $rev
}

# 每日反向规则: 昨天日胜率 < 阈值(默认45%) 且 昨日样本>=最小样本(默认10) 的策略 → 今天反向开仓
# 状态持久化 daily-reverse-state<suffix>.json(decisionDate=今天): 每天首次调用时按"昨天"数据重算, 当天内复用
function Get-DailyReverseSet {
  $stateFile = Join-Path $baseDir ('daily-reverse-state' + $suffix + '.json')
  $today = (Get-Date).ToString('yyyy-MM-dd')
  try {
    if(Test-Path $stateFile){
      $st = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if($st -and $st.decisionDate -eq $today -and $st.map){
        $rev = @{}
        foreach($p in $st.map.PSObject.Properties){ $rev[$p.Name] = [double]$p.Value.rate }
        # revexclude-cache-fix-20261011: 当日持久化状态命中也要应用反向排除
        if($script:reverseExclude -and $script:reverseExclude.Count -gt 0){ foreach($x in @($script:reverseExclude)){ if($rev.ContainsKey($x)){ [void]$rev.Remove($x) } } }
        return $rev
      }
    }
  } catch {}
  $rev = @{}
  try {
    $yesterday = (Get-Date).AddDays(-1).ToString('yyyy-MM-dd')
    $g = @{}
    # 只统计实盘数据(live 实盘账户), 按信号日(ts)过滤为"昨天"; share 模拟盘已关闭不参与 —— 2026-09-06
    foreach($sf in @('signal-verify-store-live.json')){
      $p = Join-Path $baseDir $sf
      if(-not (Test-Path $p)){ continue }
      try { $s = @(Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { continue }
      foreach($x in $s){
        if(-not $x -or -not $x.strategy){ continue }
        if([string]$x.ts -notlike ($yesterday + '*')){ continue }
        $st2 = [string]$x.strategy
        if($st2 -like '反向对照*' -or $st2 -eq 'TRADE' -or $st2 -like '反向:*' -or $st2 -like '组合A:*' -or $st2 -like '组合C:*'){ continue }
        if(-not $g.ContainsKey($st2)){ $g[$st2] = @{n=0; w=0} }
        $g[$st2].n++
        if($x.result -eq 'WIN'){ $g[$st2].w++ }
      }
    }
    foreach($k in $g.Keys){
      if($script:reverseExclude -and $script:reverseExclude -contains $k){ continue }  # 反向白名单排除, 2026-09-06
      if($g[$k].n -ge $dailyMinN){
        $rate = $g[$k].w / $g[$k].n * 100
        if($rate -lt $dailyTh){ $rev[$k] = [math]::Round($rate,1) }
      }
    }
    $stOut = [ordered]@{ decisionDate=$today; map=[ordered]@{} }
    foreach($k in $rev.Keys){ $stOut.map[$k] = [ordered]@{ rate=$rev[$k] } }
    $stOut | ConvertTo-Json -Depth 4 | Out-File $stateFile -Encoding UTF8
  } catch {}
  return $rev
}

# 连续3天熔断: 每天把"昨天"的日胜率追加进 daily-history 历史, 检查连续 N 天(默认3) < dailyTh(45%) → 加入禁用集
# 禁用集持久化 disabled-strategies<suffix>.json, 永久生效(需手动移除恢复); 每天只追加一次(updatedDate 判重)
function Update-DailyDisable {
  $histFile = Join-Path $baseDir ('daily-history' + $suffix + '.json')
  $disFile = Join-Path $baseDir ('disabled-strategies' + $suffix + '.json')
  $today = (Get-Date).ToString('yyyy-MM-dd')
  $hist = @{}
  $disabled = @{}
  try {
  if(Test-Path $histFile){
    $h = Get-Content $histFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if($h -and $h.strategies){
      # [dailyfix-2026-11-04] 跳过 .NET 集合属性名（历史上曾被当成策略名写进 history 并永久残留）
      foreach($p in $h.strategies.PSObject.Properties){
        if($script:dailyHistBadKey -and $script:dailyHistBadKey.ContainsKey([string]$p.Name)){ continue }
        $hist[$p.Name] = @($p.Value)
      }
    }
    if($h -and $h.updatedDate -eq $today){ $done = $true }
  }
} catch {}
  try { if(Test-Path $disFile){ $d = Get-Content $disFile -Raw -Encoding UTF8 | ConvertFrom-Json; if($d -and $d.strategies){ foreach($s in $d.strategies){ $disabled[[string]$s] = $true } } } } catch {}
  # 白名单保护(2026-09-10 用户规则): config.rules.whitelist 里的策略永不被自动禁用(连续N天/直接禁用都豁免); 已误禁的自动移除并写回文件
  if($script:strategyWhitelist -and $script:strategyWhitelist.Count -gt 0){
    $removed = $false
    foreach($w in @($script:strategyWhitelist)){ if($disabled.ContainsKey($w)){ $disabled.Remove($w); $removed = $true } }
    if($removed){
      try { ([ordered]@{ updatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); note='白名单保护: 自动移除被误禁的白名单策略'; strategies=@($disabled.Keys) } | ConvertTo-Json -Depth 3) | Out-File $disFile -Encoding UTF8 } catch {}
    }
  }
  if($done){ return $disabled }
  try {
    $yesterday = (Get-Date).AddDays(-1).ToString('yyyy-MM-dd')
    $g = @{}
    foreach($sf in @('signal-verify-store-live.json')){  # share 模拟盘已关, 不参与决策 —— 2026-09-06
      $p = Join-Path $baseDir $sf
      if(-not (Test-Path $p)){ continue }
      try { $s = @(Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { continue }
      foreach($x in $s){
        if(-not $x -or -not $x.strategy){ continue }
        if([string]$x.ts -notlike ($yesterday + '*')){ continue }
        $st = [string]$x.strategy
        if($st -like '反向对照*' -or $st -eq 'TRADE' -or $st -like '反向:*' -or $st -like '组合A:*' -or $st -like '组合C:*'){ continue }
        if(-not $g.ContainsKey($st)){ $g[$st] = @{n=0; w=0} }
        $g[$st].n++
        if($x.result -eq 'WIN'){ $g[$st].w++ }
      }
    }
    foreach($k in $g.Keys){
      $rate = $g[$k].w / $g[$k].n * 100
      if(-not $hist.ContainsKey($k)){ $hist[$k] = @() }
      $lastE = if($hist[$k].Count -gt 0){ $hist[$k][$hist[$k].Count-1] } else { $null }
      if(-not $lastE -or [string]$lastE.date -ne $yesterday){
        $hist[$k] += [ordered]@{ date=$yesterday; rate=[math]::Round($rate,1); n=$g[$k].n }
        if($hist[$k].Count -gt 7){ $hist[$k] = @($hist[$k][($hist[$k].Count-7)..($hist[$k].Count-1)]) }
      }
    }
    # 连续 N 天日胜率 < 阈值 -> 禁用
    # [dailyfix-2026-11-04] 补两个漏洞：
    #   ① 必须真的是"连续日历日"（原实现只取最近 N 条记录，中间断档也算；实测出现过 09-30/10-01/10-11/10-23 被当成连续）
    #   ② 每天样本数必须 >= $dailyMinPerDay（原实现 n=1 的一天也算，历史上曾凭 1 个样本永久禁用策略）
    foreach($k in $hist.Keys){
      $tail = @($hist[$k] | Select-Object -Last $disableDays)
      if($tail.Count -ge $disableDays){
        $dfCont = $true
        $dfEnough = $true
        $dfPrev = $null
        foreach($e in $tail){
          if($null -eq $e -or -not $e.date){ $dfCont = $false; break }
          $dfDt = $null
          try { $dfDt = [datetime]::ParseExact([string]$e.date, 'yyyy-MM-dd', $null) } catch { $dfCont = $false; break }
          if($null -ne $dfPrev -and [math]::Abs(($dfDt - $dfPrev).TotalDays - 1.0) -gt 0.001){ $dfCont = $false; break }
          $dfPrev = $dfDt
          if($null -ne $e.n -and [int]$e.n -lt $dailyMinPerDay){ $dfEnough = $false }
        }
        $allBelow = ($dfCont -and $dfEnough)
        if($allBelow){ foreach($e in $tail){ if([double]$e.rate -ge $dailyTh){ $allBelow = $false; break } } }
        if($allBelow -and -not ($script:strategyWhitelist -contains $k)){ $disabled[$k] = $true }
      }
    }
    # 直接禁用(2026-09-04): 累计正向样本 n∈[directMinN, reverseMinN) 且 胜率<directMaxRate → 永久禁用(正反都不开)
    $tot = @{}
    foreach($sf in @('signal-verify-store-live.json')){  # share 模拟盘已关, 不参与决策 —— 2026-09-06
      $p = Join-Path $baseDir $sf
      if(-not (Test-Path $p)){ continue }
      try { $s = @(Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { continue }
      foreach($x in $s){
        if(-not $x -or -not $x.strategy){ continue }
        $st = [string]$x.strategy
        if($st -like '反向对照*' -or $st -eq 'TRADE' -or $st -like '反向:*' -or $st -like '组合A:*' -or $st -like '组合C:*'){ continue }
        if(-not $tot.ContainsKey($st)){ $tot[$st] = @{n=0; w=0} }
        $tot[$st].n++
        if($x.result -eq 'WIN'){ $tot[$st].w++ }
      }
    }
    foreach($k in $tot.Keys){
      if($disabled.ContainsKey($k)){ continue }
      if($tot[$k].n -lt $directMinN){ continue }
      if($tot[$k].n -ge $reverseMinN){ continue }   # 样本足 → 走动态反向, 不禁
      $rate = $tot[$k].w / $tot[$k].n * 100
      if($rate -lt $directMaxRate -and -not ($script:strategyWhitelist -contains $k)){ $disabled[$k] = $true }
    }
    $histOut = [ordered]@{ updatedDate=$today; strategies=[ordered]@{} }
    foreach($k in $hist.Keys){ $histOut.strategies[$k] = @($hist[$k]) }
    $histOut | ConvertTo-Json -Depth 5 | Out-File $histFile -Encoding UTF8
    $disOut = [ordered]@{ updatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); strategies=@($disabled.Keys) }
    $disOut | ConvertTo-Json -Depth 3 | Out-File $disFile -Encoding UTF8
  } catch {}
  return $disabled
}

# ===== 长时间持仓优化(2026-09-01): 策略自营持仓台账 + 时间止损 + 盈亏平衡 =====
function Get-StrategyLedger {
  try { if(Test-Path $ledgerFile){ $l = Get-Content $ledgerFile -Raw -Encoding UTF8 | ConvertFrom-Json; if($l -and $l.positions){ return @($l.positions) } } } catch {}
  return @()
}
function Save-StrategyLedger($positions) {
  try { @{ updatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); positions=@($positions) } | ConvertTo-Json -Depth 4 | Out-File $ledgerFile -Encoding UTF8 } catch {}
}
function Add-StrategyPosition($instId, $posSide, $entryPx, $notional, $status, $openTs, $src, $clOrdId = '') {
  $list = New-Object System.Collections.Generic.List[object]
  foreach($e in @(Get-StrategyLedger)){ $list.Add($e) }
  $list.Add([ordered]@{ instId=$instId; posSide=$posSide; entryPx=[double]$entryPx; notional=[double]$notional; openTs=$openTs; status=$status; breakevenDone=$false; src=$src; clOrdId=[string]$clOrdId })
  Save-StrategyLedger $list.ToArray()
}
function Set-LedgerOpen($instId, $posSide) {
  $list = New-Object System.Collections.Generic.List[object]
  foreach($e in @(Get-StrategyLedger)){
    if($e.instId -eq $instId -and $e.posSide -eq $posSide -and $e.status -eq 'pending'){ $e.status = 'open'; $e.openTs = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }
    $list.Add($e)
  }
  Save-StrategyLedger $list.ToArray()
}
function Remove-StrategyPosition($instId, $posSide) {
  $list = New-Object System.Collections.Generic.List[object]
  foreach($e in @(Get-StrategyLedger)){ if(-not ($e.instId -eq $instId -and $e.posSide -eq $posSide)){ $list.Add($e) } }
  Save-StrategyLedger $list.ToArray()
}

# ===== 同策略连续亏损冷却(2026-09-02) =====
function Get-CooldownState {
  try { if(Test-Path $cooldownFile){ $c = Get-Content $cooldownFile -Raw -Encoding UTF8 | ConvertFrom-Json; if($c -and $c.strategies){ return $c.strategies } } } catch {}
  return @{}
}
function Save-CooldownState($strategies) {
  try { @{ updatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); strategies=$strategies } | ConvertTo-Json -Depth 5 | Out-File $cooldownFile -Encoding UTF8 } catch {}
}
# 平仓归因: 某策略一笔成交平仓后更新连续亏损计数
function Update-StrategyCooldown($src, $pnl) {
  if(-not $src -or $src -eq 'unknown'){ return }
  try {
    $st = Get-CooldownState
    $k = [string]$src
    $en = if($st.ContainsKey($k)){ $st[$k] } else { $null }
    $loss = [double]$pnl -lt 0
    if($en){
      if($loss){
        $en.consecLosses = [int]$en.consecLosses + 1
        if(-not $en.inCooldown -and [int]$en.consecLosses -ge $cooldownLosses){ $en.inCooldown = $true; $en.cooldownSince = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }
      } else {
        if(-not $en.inCooldown){ $en.consecLosses = 0 }   # 冷却期间不靠单笔盈利解冻, 只看冷却期信号胜率
      }
    } else {
      $en = [ordered]@{ consecLosses = if($loss){1}else{0}; inCooldown=$false; cooldownSince='' }
      if($loss -and $cooldownLosses -le 1){ $en.inCooldown = $true; $en.cooldownSince = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }
    }
    $st[$k] = $en
    Save-CooldownState $st
  } catch {}
}
# ==================== 币种熔断(连续亏损临时禁开) 2026-09-05 ====================
# 某币连续 coinCooldownConsecLosses(默认4)笔平仓亏损 → 该币 temp 禁开；下一笔盈利即解除(重置计数)
$script:coinCooldownConsecLosses = 4
$script:coinCooldownHours = 24   # 熔断冷却时长(小时), 到期自动解除(2026-09-05 修复死锁)
$coinCooldownFile = Join-Path $baseDir ('strategy-coin-cooldown' + $suffix + '.json')
function Get-CoinCooldownState {
  try { if(Test-Path $coinCooldownFile){ $c = Get-Content $coinCooldownFile -Raw -Encoding UTF8 | ConvertFrom-Json; if($c -and $c.coins){ return $c.coins } } } catch {}
  return @{}
}
function Save-CoinCooldownState($coins) {
  try { @{ updatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); coins=$coins } | ConvertTo-Json -Depth 4 | Out-File $coinCooldownFile -Encoding UTF8 } catch {}
}
# 更新某币连续亏损：亏损++ / 盈利重置(视为解除)；达到阈值标记熔断
function Update-CoinCooldown($instId, $pnl) {
  if(-not $instId){ return }
  try {
    $coins = Get-CoinCooldownState
    $loss = [double]$pnl -lt 0
    $en = if($coins.ContainsKey($instId)){ $coins[$instId] } else { $null }
    if($en){
      if($loss){ $en.consecLosses = [int]$en.consecLosses + 1 } else { $en.consecLosses = 0; $en.cooled = $false }
      if([int]$en.consecLosses -ge $script:coinCooldownConsecLosses){ $en.cooled = $true; if(-not $en.since){ $en.since = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } }
    } else {
      $en = [ordered]@{ consecLosses = if($loss){1}else{0}; cooled = ($loss -and $script:coinCooldownConsecLosses -le 1); since = if($loss){ (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }else{''} }
    }
    $coins[$instId] = $en
    Save-CoinCooldownState $coins
  } catch {}
}
# 熔断有效集(2026-09-05 修复死锁): 返回应拦截的币(cooled 且未过冷却时长); 冷却到期的币自动解除(cooled=false 写回)
# 说明: 熔断=临时冷却, 到期自动解除重新观察; 不再依赖"盈利笔解除"(熔断期禁开→无新平仓→盈利解除不可达, 原为死锁)
function Get-CoinCooldownActiveSet {
  $set = @{}
  # B(2026-09-10): 精确的"同币连续亏损"判定放在 Invoke-Trade 内按币查询——全局 --limit 100 会漏早期记录(实测 RAY 全局仅1条, 按币查到4条)
  $cc = Get-CoinCooldownState
  if(-not $cc){ return $set }
  $changed = $false
  foreach($k in @($cc.Keys)){
    $en = $cc[$k]
    if(-not $en -or -not $en.cooled){ continue }
    $expired = $false
    if($en.since -and $script:coinCooldownHours -gt 0){
      try { if(((Get-Date) - [datetime]$en.since).TotalHours -ge $script:coinCooldownHours){ $expired = $true } } catch {}
    }
    if($expired){ $en.cooled = $false; $en.since = ''; $cc[$k] = $en; $changed = $true }
    else { $set[$k] = $true }
  }
  if($changed){ Save-CoinCooldownState $cc }
  return $set
}
# 冷却解除: 冷却中策略在 cooldownSince 之后验证的信号胜率 >= 阈值 且 样本足够 → 解冻
function Check-CooldownExit {
  try {
    $st = Get-CooldownState
    if($st.Count -eq 0){ return }
    $changed = $false
    foreach($k in @($st.Keys)){
      $en = $st[$k]
      if(-not $en -or -not $en.inCooldown){ continue }
      $since = [string]$en.cooldownSince
      $n = 0; $w = 0
      foreach($sf in @('signal-verify-store-live.json')){  # share 模拟盘已关, 不参与决策 —— 2026-09-06
        $p = Join-Path $baseDir $sf
        if(-not (Test-Path $p)){ continue }
        try { $s = @(Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { continue }
        foreach($x in $s){
          if([string]$x.strategy -ne $k -or [string]$x.strategy -like '反向对照*'){ continue }
          if([string]$x.ts -lt $since){ continue }
          $n++; if($x.result -eq 'WIN'){ $w++ }
        }
      }
      if($n -ge $cooldownMinSignals -and ($w / $n * 100) -ge $cooldownRecover){
        $en.inCooldown = $false; $en.consecLosses = 0; $changed = $true
      }
    }
    if($changed){ Save-CooldownState $st }
  } catch {}
}

# 对账: 移除已平仓条目 + 首次运行从轮次日志回填存量策略仓(openTs=开仓时间)
function Reconcile-StrategyPositions {
  $cur = & $okx --json swap positions 2>$null | ConvertFrom-Json
  $openMap = @{}
  if($cur){ foreach($p in $cur){ if($p -and $p.pos -and [double]$p.pos -ne 0){ $openMap["$($p.instId)|$($p.posSide)"] = $p } } }
  $list = New-Object System.Collections.Generic.List[object]
  foreach($e in @(Get-StrategyLedger)){ $list.Add($e) }
  # 已平仓的 open 条目: 归因平仓盈亏(同策略连续亏损冷却)后移除; pending 保留(限价未成交)
  $newList = New-Object System.Collections.Generic.List[object]
  $closedAny = $false
  foreach($e in $list){
    $key = "$($e.instId)|$($e.posSide)"
    # A(2026-09-10 修复): pending 也参与平仓判定(限价开仓成交后若未被 Set-LedgerOpen 标记, 会一直卡 pending → 平仓不归因不清理)
    if(($e.status -eq 'open' -or $e.status -eq 'pending') -and -not $openMap.ContainsKey($key)){
      $closedAny = $true
      continue
    }
    $newList.Add($e)
  }
  # 有平仓时: 拉平仓历史, 逐条匹配盈亏归因
  if($closedAny){
    try {
      $hist = @(& $okx --json account positions-history --instType SWAP --limit 100 2>$null | ConvertFrom-Json)
      foreach($e in @($list)){
        $key = "$($e.instId)|$($e.posSide)"
        if(($e.status -ne 'open' -and $e.status -ne 'pending') -or $openMap.ContainsKey($key)){ continue }
        $openMs = [int64]0
        try { $openMs = [int64]([datetimeoffset]([datetime]::ParseExact([string]$e.openTs, 'yyyy-MM-dd HH:mm:ss', $null))).ToUnixTimeMilliseconds() } catch {}
        $best = $null; $bestDiff = [double]::MaxValue
        foreach($h in $hist){
          if([string]$h.instId -ne $e.instId){ continue }
          $hDir = if($h.posSide){ [string]$h.posSide } elseif([double]$h.pos -gt 0){ 'long' } else { 'short' }
          if($hDir -ne $e.posSide){ continue }
          $hTime = [int64]$h.cTime
          if($hTime -lt $openMs){ continue }
          $diff = $hTime - $openMs
          if($diff -lt $bestDiff){ $bestDiff = $diff; $best = $h }
        }
        if($best){ Update-StrategyCooldown $e.src ([double]$best.pnl); Update-CoinCooldown $e.instId ([double]$best.pnl) }
      }
    } catch {}
  }
  # clOrdId 自愈(2026-09-22): 用带 DSH 标记的策略订单历史认领策略自己的持仓。
  # 台账丢失/被清空时也能自动恢复, 且绝不会把手动仓误认成策略仓(手动单没有 DSH 标记)。
  try {
    $known = @{}
    foreach($e in $newList){ $known["$($e.instId)|$($e.posSide)"] = $true }
    $ordHist = @(& $okx --json swap orders --history 2>$null | ConvertFrom-Json)
    $adopted = 0
    foreach($o in $ordHist){
      $cid = [string]$o.clOrdId
      if(-not $cid -or -not $cid.ToUpper().StartsWith('DSH')){ continue }
      if([string]$o.reduceOnly -eq 'true'){ continue }
      $key = "$([string]$o.instId)|$([string]$o.posSide)"
      if($known.ContainsKey($key) -or -not $openMap.ContainsKey($key)){ continue }
      $p = $openMap[$key]
      $openTsStr = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
      if($p.cTime){ try { $openTsStr = ([System.DateTimeOffset]::FromUnixTimeMilliseconds([int64]$p.cTime)).LocalDateTime.ToString('yyyy-MM-dd HH:mm:ss') } catch {} }
      $newList.Add([ordered]@{ instId=[string]$o.instId; posSide=[string]$o.posSide; entryPx=[double]$p.avgPx; notional=0; openTs=$openTsStr; status='open'; breakevenDone=$false; src='adopted'; clOrdId=$cid })
      $known[$key] = $true
      $adopted++
    }
    if($adopted -gt 0){ Write-Output ('{"info":"ledger-adopt-by-clordid ' + $adopted + '"}') }
  } catch {}

  # 首次运行(台账为空)回填: 解析轮次日志的成交, 匹配当前持仓
  if($newList.Count -eq 0){
    try {
      # 内存保护(2026-09-23 事故修复): 日志已 46MB, Get-Content -Raw 会把整个文件读进内存
      # (PowerShell 字符串膨胀数倍) —— 1.6G 无 swap 的机器上这是 OOM 主因之一(machine 11:41 被 oom-kill)。
      # 改为只读末尾 4MB(回填只关心最近的成交, 末尾足够)。
      $logText = ''
      try {
        $fs = [System.IO.File]::Open($strategyLog, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $len = [int64]$fs.Length
        $take = [int][Math]::Min($len, 4MB)
        if($take -gt 0){
          [void]$fs.Seek(-$take, [System.IO.SeekOrigin]::End)
          $buf = New-Object byte[] $take
          $read = 0
          while($read -lt $take){ $n = $fs.Read($buf, $read, $take - $read); if($n -le 0){ break }; $read += $n }
          $logText = [System.Text.Encoding]::UTF8.GetString($buf, 0, $read)
        }
        $fs.Close()
      } catch { $logText = '' }
      $re = '"instId":\s*"([^"]+)".*?"trade":\s*\{[^}]*?"type":\s*"(swap-long|swap-short)"'
      # 简化: 直接按轮次切分太重; 用正则粗略提取 instId+type, 再按当前持仓匹配
      foreach($m in [regex]::Matches($logText, '"instId":\s*"([^"]+)"[^}]*?"type":\s*"(swap-long|swap-short)"')){
        $inst = $m.Groups[1].Value; $tp = $m.Groups[2].Value
        $ps = if($tp -eq 'swap-long'){ 'long' } else { 'short' }
        $key = "$inst|$ps"
        if($openMap.ContainsKey($key)){
          $p = $openMap[$key]
          $openTsStr = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
          if($p.cTime){ try { $openTsStr = ([System.DateTimeOffset]::FromUnixTimeMilliseconds([int64]$p.cTime)).LocalDateTime.ToString('yyyy-MM-dd HH:mm:ss') } catch {} }
          $newList.Add([ordered]@{ instId=$inst; posSide=$ps; entryPx=[double]$p.avgPx; notional=0; openTs=$openTsStr; status='open'; breakevenDone=$false; src='unknown' })
          $openMap.Remove($key)
        }
      }
    } catch {}
  }
  Save-StrategyLedger $newList.ToArray()
  return $newList.ToArray()
}

# 长时间持仓处理: ①超时市价平仓 ③浮盈达标把OCO止损移到入场价(盈亏平衡)
function Check-StalePositions {
  $actions = @()
  $positions = Get-StrategyLedger
  if($positions.Count -eq 0){ return $actions }
  $cur = & $okx --json swap positions 2>$null | ConvertFrom-Json
  $posMap = @{}
  if($cur){ foreach($p in $cur){ if($p -and $p.pos -and [double]$p.pos -ne 0){ $posMap["$($p.instId)|$($p.posSide)"] = $p } } }
  $now = Get-Date
  foreach($lp in $positions){
    if($lp.status -ne 'open'){ continue }
    $key = "$($lp.instId)|$($lp.posSide)"
    if(-not $posMap.ContainsKey($key)){ continue }
    $p = $posMap[$key]
    $openTs = [datetime]::MinValue
    try { $openTs = [datetime]::ParseExact([string]$lp.openTs, 'yyyy-MM-dd HH:mm:ss', $null) } catch {}
    $ageH = if($openTs -gt [datetime]::MinValue){ ($now - $openTs).TotalHours } else { 0 }
    $sz = [math]::Abs([double]$p.pos)
    $psArgs = if($isHedgeMode){ @('--posSide', [string]$lp.posSide) } else { @() }
    $psArgs += $aiBcArgs   # AI Builder attribution
    $side = if($lp.posSide -eq 'long'){ 'sell' } else { 'buy' }
    # ① 时间止损(config rules.maxHoldHours; 2026-09-15 用户要求关闭 48h 自动平仓: 设为 0 即停用 —— 与 dyn-protect 动态止盈止损冲突)
    if($maxHoldHours -gt 0 -and $ageH -ge $maxHoldHours){
      $res = & $okx --json swap place --instId $lp.instId --side $side --ordType market --sz $sz --tdMode cross --reduceOnly --clOrdId (New-StratClOrdId 'TS') @psArgs 2>$null | ConvertFrom-Json
      $ok = ($res -and $res[0] -and [string]$res[0].sCode -eq '0')
      Add-OrderEvent 'time-stop' @{ instId=$lp.instId; ordId=$(if($res -and $res[0]){[string]$res[0].ordId}else{''}); clOrdId=$(if($res -and $res[0]){[string]$res[0].clOrdId}else{''}); posSide=[string]$lp.posSide; ordType='market'; reduceOnly=$true; strategy=[string]$lp.src; openTs=[string]$lp.openTs; ageH=[math]::Round($ageH,2); okEvent=$ok; why='时间止损(maxHoldHours)'; round=$script:round }
      # 取消该币所有待触发算法单
      try { $algos = & $okx --json swap algo orders --instId $lp.instId 2>$null | ConvertFrom-Json; foreach($a in $algos){ if($a.algoId){ & $okx --json swap algo cancel --instId $lp.instId --algoId $a.algoId 2>$null | Out-Null } } } catch {}
      $actions += [ordered]@{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); instId=$lp.instId; posSide=$lp.posSide; action='time-stop'; ageH=[math]::Round($ageH,1); status=if($ok){'OK'}else{if($res -and $res[0]){[string]$res[0].sMsg}else{'fail'}} }
      # 不直接删台账: 由下一轮 Reconcile 归因平仓盈亏(连续亏损冷却)后移除
      continue
    }
    # ③ 盈亏平衡: 价格朝有利方向移动 >= breakevenPct% 且未做过 → 把OCO止损移到入场价
    if($enableBreakeven -and -not $lp.breakevenDone -and $p.avgPx -and $p.last){
      $entryPx = [double]$p.avgPx; $lastPx = [double]$p.last
      $pnlPct = if($lp.posSide -eq 'long'){ ($lastPx - $entryPx) / $entryPx * 100 } else { ($entryPx - $lastPx) / $entryPx * 100 }
      if($pnlPct -ge $breakevenPct){
        $oid = $null
        try { $al = & $okx --json swap algo orders --instId $lp.instId --ordType oco 2>$null | ConvertFrom-Json; if($al -and $al[0]){ $oid = [string]$al[0].algoId } } catch {}
        if($oid){
          $ep = [math]::Round($entryPx, 6)
          & $okx --json swap algo amend --instId $lp.instId --algoId $oid --newSlTriggerPx $ep 2>$null | Out-Null
          $actions += [ordered]@{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); instId=$lp.instId; posSide=$lp.posSide; action='breakeven'; pnlPct=[math]::Round($pnlPct,2); slMovedTo=$ep }
          # 标记已完成, 并持久化
          $l2 = New-Object System.Collections.Generic.List[object]
          foreach($e in @(Get-StrategyLedger)){ if($e.instId -eq $lp.instId -and $e.posSide -eq $lp.posSide){ $e.breakevenDone = $true }; $l2.Add($e) }
          Save-StrategyLedger $l2.ToArray()
        }
      }
    }
  }
  return $actions
}

# BTC 1H 趋势(开仓方向过滤,减少假信号;失败返回 NEUTRAL 不拦截)
function Get-BTCTrend {
  try {
    $cf = Join-Path $dataDir 'BTC-USDT-SWAP_1H.json'
    & $okx --json market candles BTC-USDT-SWAP --bar 1H --limit 300 2>$null | Out-File $cf -Encoding utf8
    $if = Join-Path $dataDir 'BTC-USDT-SWAP_1H-ind.json'
    & $nodeExe (Join-Path $baseDir 'indicators.js') $cf 1H 300 2>$null | Out-File $if -Encoding utf8
    $s = & $nodeExe (Join-Path $baseDir 'strategies.js') $if 2>$null | Out-String | ConvertFrom-Json
    return if($s -and $s.consensus){ [string]$s.consensus } else { 'NEUTRAL' }
  } catch { return 'NEUTRAL' }
}

# 趋势反转止损：持仓方向与 4H 趋势冲突时果断平仓
# 节流：4H K线每4小时才生成新线，4小时内趋势不变 -> 每4小时检查一次
$trendCheckFile = Join-Path $baseDir ('trend-check-time' + $suffix + '.json')

function Get-LastTrendCheck {
  if(Test-Path $trendCheckFile){
    try { return [datetime](Get-Content $trendCheckFile -Raw -Encoding UTF8 | ConvertFrom-Json).lastCheck } catch { return [datetime]'2000-01-01' }
  }
  return [datetime]'2000-01-01'
}

function Check-TrendStop {
  $actions = @()
  # 节流检查：距上次 <4 小时直接跳过
  $lastCheck = Get-LastTrendCheck
  $now = Get-Date
  if(($now - $lastCheck).TotalHours -lt 4){
    $actions += [ordered]@{ ts=$now.ToString('yyyy-MM-dd HH:mm:ss'); action='skip'; reason="4H趋势未到检查周期（距上次 $([math]::Round(($now-$lastCheck).TotalHours,1))h < 4h）" }
    return $actions
  }
  # 记录本次检查时间
  @{ lastCheck=$now.ToString('yyyy-MM-dd HH:mm:ss') } | ConvertTo-Json | Out-File $trendCheckFile -Encoding UTF8
  try {
    $positions = & $okx --json swap positions 2>$null | ConvertFrom-Json
    $open = @($positions | Where-Object { $_.pos -and [double]$_.pos -ne 0 })
    foreach($p in $open){
      $instId = $p.instId
      $posSz = [double]$p.pos
      $dir = if($posSz -gt 0){ 'LONG' } else { 'SHORT' }
      # 拉 4H 趋势
      try {
        $cf4h = Join-Path $dataDir ($instId + '_1D.json')
        & $okx --json market candles $instId --bar 4H --limit 300 2>$null | Out-File $cf4h -Encoding utf8
        $if4h = Join-Path $dataDir ($instId + '_1D-ind.json')
        & $nodeExe (Join-Path $baseDir 'indicators.js') $cf4h 4H 300 2>$null | Out-File $if4h -Encoding utf8
        $s4h = & $nodeExe (Join-Path $baseDir 'strategies.js') $if4h 2>$null | Out-String | ConvertFrom-Json
        $trend = $s4h.consensus
      } catch { $trend = 'NEUTRAL' }
      # 方向反转判断：多单遇 4H SHORT，空单遇 4H LONG -> 果断止损
      $shouldStop = ($dir -eq 'LONG' -and $trend -eq 'SHORT') -or ($dir -eq 'SHORT' -and $trend -eq 'LONG')
      if($shouldStop){
        $side = if($dir -eq 'LONG'){ 'sell' } else { 'buy' }
        $sz = [math]::Abs($posSz)
        $res = & $okx --json swap place --instId $instId --side $side --ordType market --sz $sz --tdMode cross --clOrdId (New-StratClOrdId 'RS') @aiBcArgs 2>$null | ConvertFrom-Json
        $ok = ($res -and $res[0] -and [string]$res[0].sCode -eq '0')
        Add-OrderEvent 'trend-close' @{ instId=$instId; ordId=$(if($res -and $res[0]){[string]$res[0].ordId}else{''}); clOrdId=$(if($res -and $res[0]){[string]$res[0].clOrdId}else{''}); ordType='market'; reduceOnly=$true; dir4h=$dir; trend4h=$trend; okEvent=$ok; why=('4H趋势反转止损(' + $trend + ')'); round=$script:round }
        $actions += [ordered]@{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); instId=$instId; dir=$dir; trend4h=$trend; action='trend-reversal-stop'; status=if($ok){'OK'}else{if($res -and $res[0]){[string]$res[0].sMsg}else{'fail'}} }
      }
    }
  } catch {}
  return $actions
}

# 观察快照（原 obs-snapshot 精简版，每轮顺带记录）
function Write-Snapshot {
  $ts = Get-Date -Format 'yyyy-MM-dd HH:mm'
  try {
    $bal = & $okx --json account balance 2>$null | ConvertFrom-Json
    $eq = if($bal -and $bal[0]){ [math]::Round([double]$bal[0].totalEq, 2) } else { 0 }
    $swaps = & $okx --json swap positions 2>$null | ConvertFrom-Json
    $cnt = @($swaps | Where-Object { $_.pos -and [double]$_.pos -ne 0 }).Count
    $upl = 0; foreach($p in $swaps){ if($p.pos -and [double]$p.pos -ne 0){ $upl += [double]$p.upl } }
    $line = "$ts,$eq,$cnt,$([math]::Round($upl,2))"
    $snapFile = Join-Path (Join-Path $baseDir ('observation' + $suffix)) 'snapshots.csv'
    if(-not (Test-Path (Split-Path $snapFile))){ New-Item -ItemType Directory -Force -Path (Split-Path $snapFile) | Out-Null }
    if(-not (Test-Path $snapFile)){ "ts,equity,swapCount,swapUpl" | Out-File $snapFile -Encoding UTF8 }
    Add-Content -Path $snapFile -Value $line -Encoding UTF8
  } catch {}
}

# 主流币(BTC/ETH/SOL)当日(1D open→last)平均涨跌%: risk-on/off 判定用; 任一失败跳过该币, 至少2个成功否则返回0(未知=不触发risk-on)
function Get-MajorsDailyPct {
  $sum = 0.0; $ok = 0
  foreach($m in @('BTC-USDT-SWAP','ETH-USDT-SWAP','SOL-USDT-SWAP')){
    try {
      $rows = & $okx --json market candles $m --bar 1D --limit 2 2>$null | ConvertFrom-Json
      $last = $null
      if($rows){ foreach($r in @($rows)){ if($r -and $r[4]){ $last = $r } } }
      if($last){
        $o = [double]$last[1]; $c = [double]$last[4]
        if($o -gt 0 -and $c -gt 0){ $sum += ($c / $o - 1) * 100; $ok++ }
      }
    } catch {}
  }
  if($ok -ge 2){ return $sum / $ok }
  return 0.0
}

# OI 快照(2026-09-21, 仅记录不改交易): 取该币"开仓当时"的持仓量与方向象限
#   数据源优先级: ① oi-last-snapshot.json 与上一轮 OI 快照对比(5分钟粒度, 自算 ΔOI 与 Δ价)
#                ② market oi-change 榜单(官方 1H 口径, 仅当该币在变化榜前 100 时可得)
#   返回 $null 表示数据不可用(不影响开仓, 仅少记字段)
function Get-OISnapshot($instId, $priceNow){
  if(-not $oiWatch){ return $null }
  if($script:oiQuadrantCache.ContainsKey($instId)){ return $script:oiQuadrantCache[$instId] }
  $res = $null
  try {
    $prevOi = $null; $prevPx = $null
    if(Test-Path $oiSnapFile){
      try {
        $snap = Get-Content $oiSnapFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if($snap -and $snap.oi -and $snap.oi.$instId){
          $prevOi = [double]$snap.oi.$instId.oiUsd
          $prevPx = [double]$snap.oi.$instId.last
        }
      } catch {}
    }
    $oiNow = $null
    try {
      $one = & $okx --json market open-interest --instType SWAP --instId $instId 2>$null | ConvertFrom-Json
      if($one -and $one[0] -and $one[0].oiUsd){ $oiNow = [double]$one[0].oiUsd }
    } catch {}
    $dOi = $null
    if($prevOi -and $prevOi -gt 0 -and $oiNow){ $dOi = ($oiNow - $prevOi) / $prevOi * 100 }
    $dPx = $null
    if($prevPx -and $prevPx -gt 0 -and $priceNow){ $dPx = ([double]$priceNow - $prevPx) / $prevPx * 100 }
    $oi1h = $null; $px1h = $null
    try {
      $hot = & $okx --json market oi-change --instType SWAP --bar 1H --limit 100 2>$null | ConvertFrom-Json
      $rows = if($hot -and $hot.rows){ $hot.rows } else { $hot }
      foreach($r in @($rows)){ if($r.instId -eq $instId){ $oi1h = [double]$r.oiDeltaPct; $px1h = [double]$r.pxChgPct; break } }
    } catch {}
    $qOi = if($null -ne $oi1h){ $oi1h } else { $dOi }
    $qPx = if($null -ne $px1h){ $px1h } else { $dPx }
    $quad = 'unknown'
    if($null -ne $qOi -and $null -ne $qPx){
      if($qOi -gt 0.5 -and $qPx -gt 0.5){ $quad = 'up-acc' }
      elseif($qOi -lt -0.5 -and $qPx -gt 0.5){ $quad = 'up-dist' }
      elseif($qOi -gt 0.5 -and $qPx -lt -0.5){ $quad = 'dn-acc' }
      elseif($qOi -lt -0.5 -and $qPx -lt -0.5){ $quad = 'dn-dist' }
      else { $quad = 'flat' }
    }
    $res = [ordered]@{
      oiUsd = if($oiNow){ [math]::Round($oiNow, 0) } else { $null }
      oiChgPct = if($null -ne $dOi){ [math]::Round($dOi, 3) } else { $null }
      pxChgPct = if($null -ne $dPx){ [math]::Round($dPx, 3) } else { $null }
      oiDeltaPct1H = if($null -ne $oi1h){ [math]::Round($oi1h, 3) } else { $null }
      pxChgPct1H = if($null -ne $px1h){ [math]::Round($px1h, 3) } else { $null }
      quadrant = $quad
      src = if($null -ne $oi1h){ 'official1h' } elseif($null -ne $dOi){ 'self5m' } else { 'none' }
    }
  } catch { $res = $null }
  $script:oiQuadrantCache[$instId] = $res
  return $res
}

# 市场宽度(2026-09-18): 全市场 USDT 永续 24h 涨跌家数 → 涨跌比/上涨占比/中位涨幅
# 数据源: 复用本轮已拉取的 $script:lastTickers(不额外请求), 失败返回 $null 不影响主流程
# ⚠️ 口径(2026-10-14 更正): 本函数返回**两套口径** ——
#   ① 过滤口径(upPct/regime/…): 只统计 24h 成交额 >= breadthMinVolUsdt 的币, 是**"普涨禁空"状态机的判定依据**(非仅展示)
#   ② 全市场口径(upPctAll/regimeAll/…, breadthAll-20261014): 不加任何成交额限制, 供 BI「市场环境简报」展示
function Get-MarketBreadth {
  try {
    $tk = $script:lastTickers
    if(-not $tk){ return $null }
    $ups = 0; $downs = 0; $flats = 0; $chgs = New-Object System.Collections.Generic.List[double]
    # breadthAll-20261014(用户要求): 简报口径＝**全市场、不加成交额限制**; 过滤口径继续保留, 只给"普涨禁空"判定用
    $upsAll = 0; $downsAll = 0; $flatsAll = 0; $chgsAll = New-Object System.Collections.Generic.List[double]
    $total = 0; $kept = 0
    foreach($t in @($tk)){
      if(-not $t -or -not $t.instId){ continue }
      if($t.instId -notlike '*-USDT-SWAP'){ continue }
      $last = [double]$t.last; $open = [double]$t.open24h
      if($last -le 0 -or $open -le 0){ continue }
      $total++
      $c = ($last / $open - 1) * 100
      # 全市场口径(不加任何成交额限制) —— 简报/环境展示用
      $chgsAll.Add($c)
      if($c -gt 0.1){ $upsAll++ } elseif($c -lt -0.1){ $downsAll++ } else { $flatsAll++ }
      # 过滤口径(2026-09-18, breadthMinVolUsdt) —— 仅"普涨禁空"判定沿用, 简报不再用
      $vol = $last * [double]$t.volCcy24h
      if($breadthMinVol -gt 0 -and $vol -lt $breadthMinVol){ continue }
      $kept++
      $chgs.Add($c)
      if($c -gt 0.1){ $ups++ } elseif($c -lt -0.1){ $downs++ } else { $flats++ }
    }
    $n = $chgs.Count
    if($n -lt 15){ return $null }
    $sorted = @($chgs | Sort-Object)
    $median = $sorted[[int][math]::Floor($n / 2)]
    $avg = ($chgs | Measure-Object -Average).Average
    $sd = [math]::Sqrt((($chgs | ForEach-Object { ($_ - $avg) * ($_ - $avg) }) | Measure-Object -Sum).Sum / $n)
    $ratio = if($downs -gt 0){ [math]::Round($ups / $downs, 2) } elseif($ups -gt 0){ 99.99 } else { 0 }
    $upPct = [math]::Round($ups / $n * 100, 1)
    # 三态环境判定(2026-09-18 回测口径): 以上涨占比为主, ratio 辅助
    $regime = if($upPct -ge 75){ '普涨' } elseif($upPct -le 35){ '下跌' } else { '正常' }
    # 全市场口径统计(breadthAll-20261014): 简报展示用, 与"普涨禁空"判定口径分离
    $nAll = $chgsAll.Count
    if($nAll -ge 15){
      $sortedAll = @($chgsAll | Sort-Object)
      $medianAll = $sortedAll[[int][math]::Floor($nAll / 2)]
      $avgAll = ($chgsAll | Measure-Object -Average).Average
      $sdAll = [math]::Sqrt((($chgsAll | ForEach-Object { ($_ - $avgAll) * ($_ - $avgAll) }) | Measure-Object -Sum).Sum / $nAll)
      $ratioAll = if($downsAll -gt 0){ [math]::Round($upsAll / $downsAll, 2) } elseif($upsAll -gt 0){ 99.99 } else { 0 }
      $upPctAll = [math]::Round($upsAll / $nAll * 100, 1)
      $regimeAll = if($upPctAll -ge 75){ '普涨' } elseif($upPctAll -le 35){ '下跌' } else { '正常' }
    } else {
      $medianAll = $null; $avgAll = $null; $sdAll = $null; $ratioAll = $null; $upPctAll = $null; $regimeAll = $null
    }
    # 滞回禁空状态机: >on 停空 → 维持 → <off 恢复; 状态持久化(跨轮/跨重启)
    $blocked = $false; $blockedSince = ''
    if($breadthShortBlock){
      try {
        if(Test-Path $breadthStateFile){
          $ps = Get-Content $breadthStateFile -Raw -Encoding UTF8 | ConvertFrom-Json
          if($ps){ $blocked = [bool]$ps.blocked; $blockedSince = [string]$ps.since }
        }
      } catch {}
      $prevBlocked = $blocked
      if(-not $blocked -and $upPct -gt $breadthShortOn){ $blocked = $true; $blockedSince = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }
      elseif($blocked -and $upPct -lt $breadthShortOff){ $blocked = $false; $blockedSince = '' }
      if($blocked -ne $prevBlocked -or -not (Test-Path $breadthStateFile)){
        try {
          @{ blocked=$blocked; since=$blockedSince; upPct=[math]::Round($upPct,1); updatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } |
            ConvertTo-Json | Out-File $breadthStateFile -Encoding UTF8
        } catch {}
      }
    }
    return [ordered]@{
      n=$n; total=$total; kept=$kept
      up=$ups; down=$downs; flat=$flats
      ratio=$ratio
      upPct=$upPct
      median=[math]::Round($median, 2)
      avg=[math]::Round($avg, 2)
      sd=[math]::Round($sd, 2)
      regime=$regime
      minVolUsdt=$breadthMinVol
      shortBlocked=$blocked
      blockedSince=$blockedSince
      # breadthAll-20261014: 全市场口径(不加成交额限制) —— 简报用; 上面那组(过滤口径)是"普涨禁空"的判定依据
      nAll=$nAll; upAll=$upsAll; downAll=$downsAll; flatAll=$flatsAll
      ratioAll=$ratioAll; upPctAll=$upPctAll; regimeAll=$regimeAll
      medianAll=if($null -ne $medianAll){ [math]::Round($medianAll, 2) } else { $null }
      avgAll=if($null -ne $avgAll){ [math]::Round($avgAll, 2) } else { $null }
      sdAll=if($null -ne $sdAll){ [math]::Round($sdAll, 2) } else { $null }
      gateBasis='vol-filtered(>=minVolUsdt)'
    }
  } catch { return $null }
}

function Invoke-Round($round){
  $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
  $out = [ordered]@{ ts=$ts; round=$round; signals=@(); trades=@(); errors=@() }
  $script:disabledSignalSkipped = 0   # 2026-11-04: 被禁用策略丢弃的信号数（只计数留痕）
  $roundTrades = 0
  $script:deferred = [System.Collections.Generic.List[object]]::new()
  $script:deferOpen = [bool]$script:pickBest   # 本轮已开仓数(控频 maxPerRound)
  # 动态反向策略集(每轮重算): 全时段规则(胜率<阈值) + 每日规则(昨天日胜率<阈值→今天反向), 合并取反向
  $allRev = Get-ReverseSet
  $dailyRev = Get-DailyReverseSet
  $script:reverseSet = @{}
  foreach($k in $allRev.Keys){ $script:reverseSet[$k] = $allRev[$k] }
  foreach($k in $dailyRev.Keys){ if(-not $script:reverseSet.ContainsKey($k)){ $script:reverseSet[$k] = $dailyRev[$k] } }
  if($script:reverseSet.Count -gt 0){ $out.reverseSet = $script:reverseSet }
  if($script:forceReverse -and $script:forceReverse.Count -gt 0){ $out.forceReverse = @($script:forceReverse) }   # forcereverse-20261014: 可观测
  if($script:chg24ShortExempt -and $script:chg24ShortExempt.Count -gt 0){ $out.chg24ShortExempt = @($script:chg24ShortExempt) }   # chg24exempt-20261014: 可观测
  if($dailyRev.Count -gt 0){ $out.dailyReverse = $dailyRev }
  # 连续3天熔断: 更新每日历史并加载禁用集(禁用策略正反都不开)
  $script:disabledSet = Update-DailyDisable
  if($script:disabledSet.Count -gt 0){ $out.disabledStrategies = @($script:disabledSet.Keys) }
  # 同策略连续亏损冷却: 加载冷却集 + 尝试解除(信号胜率回升到阈值)
  try {
    Check-CooldownExit
    $script:cooldownSet = @{}
    $cs = Get-CooldownState
    if($cs){ foreach($k in @($cs.Keys)){ if($cs[$k].inCooldown){ $script:cooldownSet[$k] = $true } } }
    if($script:cooldownSet.Count -gt 0){ $out.cooldownStrategies = @($script:cooldownSet.Keys) }
    # 币种熔断状态加载 + 阈值(默认4)/冷却时长(默认24h)
    $script:coinCooldownConsecLosses = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.coinCooldownConsecLosses){ [int]$cfg.rules.coinCooldownConsecLosses } else { 4 }
    $script:coinCooldownHours = if($cfg -and $cfg.rules -and $null -ne $cfg.rules.coinCooldownHours){ [int]$cfg.rules.coinCooldownHours } else { 24 }
    $script:coinCooldownSet = Get-CoinCooldownActiveSet
    if($script:coinCooldownSet.Count -gt 0){ $out.coinCooldowns = @($script:coinCooldownSet.Keys) }
  } catch {}
  # 长时间持仓优化: 台账对账 + ①时间止损 ③盈亏平衡(每轮检查)
  try {
    Reconcile-StrategyPositions | Out-Null
    $stale = @(Check-StalePositions)
    if($stale.Count -gt 0){ $out.staleActions = $stale }
  } catch {}
  # 熔断状态同步(2026-09-05): 对账后立即重载 coinCooldownSet——消除"本轮刚被判满4亏的币, 本轮内仍可开第5笔"的窗口(含冷却到期自动解除)
  try {
    $script:coinCooldownSet = Get-CoinCooldownActiveSet
    if($script:coinCooldownSet.Count -gt 0){ $out.coinCooldowns = @($script:coinCooldownSet.Keys) }
  } catch {}
  # 限价挂单追踪: 成交后补挂 OCO(全平)保护
  try { $attached = @(Check-LimitOrders); if($attached.Count -gt 0){ $out.limitAttached = $attached } } catch {}
  # [naked-2026-11-05] 裸仓巡检：策略台账 open 但无 algo 单 → 补挂保护
  try { $nk = @(Protect-NakedStrategyPositions); if($nk.Count -gt 0){ $out.nakedProtected = $nk } } catch {}

  # BTC 1H 方向过滤(每轮一次,供开仓确认;失败/关闭则为 NEUTRAL 不拦截)
  $script:btcTrend = if($btcFilterOn){ Get-BTCTrend } else { 'NEUTRAL' }
  # [oiq-2026-11-04] 每轮取一次四象限快照（一次 oi-change 调用约 1~2 秒；失败不拦截，只记录）
  $script:oiQuad = $null
  try {
    $oqTxt = (& $nodeExe (Join-Path $baseDir 'oi-quadrant.js') --json --bar $oiQuadBar 2>$null | Out-String).Trim()
    if($oqTxt){
      $oqObj = $oqTxt | ConvertFrom-Json
      if($oqObj -and $oqObj.map){
        $script:oiQuad = @{}
        foreach($oqP in $oqObj.map.PSObject.Properties){ $script:oiQuad[$oqP.Name] = $oqP.Value }
        Write-Output ('{"info":"oi-quadrant bar=' + $oiQuadBar + ' coins=' + [string]$oqObj.coins + ' elapsed=' + [string]$oqObj.elapsedMs + 'ms"}')
      }
    }
  } catch { Write-Output '{"warn":"oi-quadrant 取数失败(不拦截)"}' }
  $out.btcTrend = $script:btcTrend

  # 风险偏好总开关(2026-09-07): 主流币(BTC/ETH/SOL)当日(1D open→last)平均涨跌 > riskOnThPct(默认2%) → risk-on
  # 2026-09-18 用户指令: 取消 mainstream 当日涨幅对山寨开单的限制(普涨行情误杀过多) → 默认 riskOnOff=false(关闭)
  #   关闭后: 空单不再被降级/不加 0.7 缩量; 如需恢复把 live-config.json risk.riskOnOff 改为 true 即可
  $riskOnOff = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.riskOnOff){ [bool]$cfg.risk.riskOnOff } else { $false }
  $script:riskOn = $false
  $script:majorsDailyPct = 0.0
  $riskOnOn = $riskOnOff -and (if($cfg -and $cfg.risk -and $null -ne $cfg.risk.riskOnOffOn){ [bool]$cfg.risk.riskOnOffOn } else { $true })
  if($riskOnOn){
    $script:majorsDailyPct = Get-MajorsDailyPct
    $script:riskOnThPct = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.riskOnThPct){ [double]$cfg.risk.riskOnThPct } else { 2 }
    $script:riskOnShortScale = if($cfg -and $cfg.risk -and $null -ne $cfg.risk.riskOnShortScale){ [double]$cfg.risk.riskOnShortScale } else { 0.7 }
    if($script:majorsDailyPct -gt $script:riskOnThPct){ $script:riskOn = $true }
  }
  $out.riskOn = $script:riskOn
  $out.majorsDailyPct = [math]::Round($script:majorsDailyPct,2)


  # 0. 趋势反转止损（持仓方向与 4H 趋势冲突 -> 果断平仓）
  # 实盘模式禁用: 可能误平用户自有持仓, 策略仓靠自身 TP/SL/移动止损保护
  $trendStops = if($isLive){ @() } else { @(Check-TrendStop) }
  if($trendStops.Count -gt 0){ $out.trendStops = $trendStops }

  # 1. 候选池
  $cands = @(Get-Candidates)
  if($script:poolStats){ $out.pool = $script:poolStats }   # amppool-20261020: 候选池选法与耗时可观测
  # 池子日志在调用点打（函数内不能用 Write-Output，否则会混进返回值）
  if($script:poolStats -and $script:poolStats.mode -eq 'amp5m'){
    Write-Output ('{"info":"pool-amp5m scanned=' + $script:poolStats.scanned + ' ok=' + $script:poolStats.ok + ' picked=' + $script:poolStats.picked + ' ' + $script:poolStats.ms + 'ms topAmp=' + $script:poolStats.topAmp + '"}')
  } elseif($script:poolStats -and $script:poolStats.mode -ne 'chg'){
    Write-Output ('{"info":"pool mode=' + $script:poolStats.mode + ' -> fallback chg pool"}')
  }
  # 市场宽度(2026-09-18): 必须在 Get-Candidates 之后(它填充 $script:lastTickers)
  # ① 记录 breadth 供 BI/分析帖展示; ② 驱动"普涨禁空"滞回状态($script:shortBlocked)
  $script:shortBlocked = $false
  if($breadthWatch -or $breadthShortBlock){
    $bd = Get-MarketBreadth
    if($bd){
      $out.breadth = $bd
      if($bd.shortBlocked){ $script:shortBlocked = $true; $out.shortBlocked = $true; $out.shortBlockedSince = $bd.blockedSince }
    }
  }
  $instSet = @{}
  foreach($c in $cands){ $instSet[$c.instId] = $c }
  foreach($t in $tradeList){ if(-not $instSet.ContainsKey($t)){ $instSet[$t] = [pscustomobject]@{ instId=$t; chg=0; vol=0 } } }
  # 固定跟踪列表(蓝筹, config.rules.alwaysTrack, 默认 ETH/SOL/BTC): 无论是否在候选池都评估
  $alwaysTrack = @('ETH-USDT-SWAP','SOL-USDT-SWAP','BTC-USDT-SWAP')
  if($cfg -and $cfg.rules -and $cfg.rules.alwaysTrack){ $alwaysTrack = @($cfg.rules.alwaysTrack) }
  foreach($t in $alwaysTrack){
    if(-not $instSet.ContainsKey($t)){
      $cand = [pscustomobject]@{ instId=$t; chg=0; vol=999999999 }
      try {
        $tk = @($script:lastTickers | Where-Object { $_.instId -eq $t }) | Select-Object -First 1
        if($tk -and $tk.last -and $tk.open24h -and $tk.volCcy24h -and $tk.last -ne '0'){
          $cand.chg = [math]::Round(([double]$tk.last/[double]$tk.open24h-1)*100, 2)
          $cand.vol = [math]::Round([double]$tk.last * [double]$tk.volCcy24h, 0)
        }
      } catch {}
      $instSet[$t] = $cand
    }
  }

  # 2. 深析 + 执行
  # PauseSwitch20260920: 每轮开头读一次开单闸门 -> 记入轮次日志, 并把"监控侧已生效"写回供 BI 显示
  $swRound = @{ allowOpen=$true; reason=''; updatedAt='' }
  try {
    $swRound = Sync-TradingSwitch
    $out.tradingSwitch = [ordered]@{ allowOpen=$script:allowOpen; reason=[string]$swRound.reason; updatedAt=[string]$swRound.updatedAt }
    $applied = [ordered]@{
      ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); round=$round
      allowOpen=$script:allowOpen; reason=[string]$swRound.reason
      cancelPendingOnPause=$script:cancelPendingOnPause
      switchUpdatedAt=[string]$swRound.updatedAt
      switchFileMissing=[bool]$swRound.missing
    }
    $tmpA = $script:tradeSwitchAppliedFile + '.tmp'
    $applied | ConvertTo-Json -Depth 4 | Out-File $tmpA -Encoding UTF8
    if(Test-Path $tmpA){ Move-Item -Path $tmpA -Destination $script:tradeSwitchAppliedFile -Force }
  } catch {}
  $riskOk = Test-RiskOk
  if(-not $script:allowOpen){
    # 覆盖风控结论 -> 主路径与 ALT 路径都会把该原因记进信号日志(不静默跳过)
    $riskOk = @{ ok=$false; reason=('trading-paused-by-user' + $(if($swRound.reason){ '(' + $swRound.reason + ')' } else { '' })) }
    $out.tradingPaused = $true
  }
  $tried = @(Get-TriedSet)
$script:reentryCache = $null   # 2026-10-07: 每轮重建 "币+策略" 重开判定缓存(见 Build-ReentryCache)

  $today = (Get-Date).ToString('yyyy-MM-dd')
  # 今日已开仓数（限制 maxPerDay）：统计 tried 里今天有成功交易的
  $todayTrades = @($tried | Where-Object { $_.date -eq $today }).Count
  if($maxPerDay -lt 99 -and $todayTrades -ge $maxPerDay){ $riskOk = @{ok=$false; reason="今日已开 $todayTrades 笔（上限 $maxPerDay）"} }

  # 币种排除名单(rules.excludeInstruments, 2026-09-05 用于去掉美股/ETF等): 命中则不评估不开仓不记录
  $script:excludeSet = @{}
  $excl = if($cfg -and $cfg.rules -and $cfg.rules.excludeInstruments){ @($cfg.rules.excludeInstruments) } else { @() }
  foreach($e in $excl){ if($e){ $script:excludeSet[[string]$e] = $true } }
  # 硬白名单(2026-10-01 用户要求只开 ZEC/ETH/BTC): rules.instruments 非空时, 名单外的币一律不评估/不开仓
  $script:allowSet = @{}
  if($tradeList -and @($tradeList).Count -gt 0){ foreach($a in @($tradeList)){ if($a){ $script:allowSet[[string]$a] = $true } } }
  # [restscan-2026-11-09] 批量预取本轮所有 K 线（替代逐币 spawn CLI：240 次启动 → 1 次）
  try {
    if($ampScanMode -eq 'rest' -and $restPrefetchOn){
      $__pfPairs = @()
      foreach($__pi in @($instSet.Keys)){
        try {
          if($script:excludeSet.ContainsKey($__pi)){ continue }
          if($script:allowSet.Count -gt 0 -and -not $script:allowSet.ContainsKey($__pi)){ continue }
          foreach($__pb in @('15m','1H','4H')){ $__pfPairs += [pscustomobject]@{ instId=[string]$__pi; bar=$__pb; limit=300 } }
        } catch { }
      }
      foreach($__pm in @('BTC-USDT-SWAP','ETH-USDT-SWAP','SOL-USDT-SWAP')){ $__pfPairs += [pscustomobject]@{ instId=$__pm; bar='1D'; limit=2 } }
      $__pfIn = Join-Path $dataDir 'prefetch-in.json'
      $__pfOut = Join-Path $dataDir 'prefetch-out.json'
      (ConvertTo-Json -InputObject @($__pfPairs) -Compress) | Out-File $__pfIn -Encoding utf8
      & $nodeExe (Join-Path $baseDir 'fetch-candles.js') --in $__pfIn --out $__pfOut --dir $dataDir --conc $restScanConc --rate $restScanRate 2>$null | Out-Null
      if(Test-Path $__pfOut){
        $__pfj = (Get-Content $__pfOut -Raw -Encoding utf8) | ConvertFrom-Json
        Write-Output ('{"info":"prefetch-candles pairs=' + [string]$__pfj.unique + ' ok=' + [string]$__pfj.ok + ' fail=' + [string]$__pfj.fail + ' ' + [string]$__pfj.ms + 'ms"}')
      }
    }
  } catch {
    $__pfErr = ""
    try { $__pfErr = ([string]$_.Exception.Message) -replace '"', "" } catch { }
    Write-Output ('{"warn":"prefetch-candles failed: ' + $__pfErr + ' (fallback to CLI per-coin)"}')
  }

  foreach($inst in $instSet.Keys){
    try {
      if($script:excludeSet.ContainsKey($inst)){ continue }
      if($script:allowSet.Count -gt 0 -and -not $script:allowSet.ContainsKey($inst)){ continue }
      $cand = $instSet[$inst]
      $s15m = Get-BarSignal $inst '15m'; Start-Sleep -Milliseconds 60
      $s1h = Get-BarSignal $inst '1H'; Start-Sleep -Milliseconds 60
      $s4h = Get-BarSignal $inst '4H'   # 趋势过滤 4H（更灵敏，配合 5m 短线）

      # 双确认严格化（降频提精度, config.rules.strictDoubleConfirm 默认开）: 15m 和 1H 双周期都确认才出方向信号
      # 关闭时退化为 15m 或 1H 任一确认（信号多但噪音大）
      $shortSignal = 'NEUTRAL'
      if($strictDoubleConfirm){
        if($s15m.consensus -eq 'LONG' -and $s1h.consensus -eq 'LONG'){ $shortSignal = 'LONG' }
        elseif($s15m.consensus -eq 'SHORT' -and $s1h.consensus -eq 'SHORT'){ $shortSignal = 'SHORT' }
      } else {
        if($s15m.consensus -eq 'LONG' -or $s1h.consensus -eq 'LONG'){ $shortSignal = 'LONG' }
        elseif($s15m.consensus -eq 'SHORT' -or $s1h.consensus -eq 'SHORT'){ $shortSignal = 'SHORT' }
      }

      # Stoch+MACD 补充权重（对比结果：1H 周期 Stoch+MACD 表现好）
      # 当 1H 三共振中性但 Stoch+MACD 明确且 1D 趋势同向 -> 提升为 WEAK 信号
      $stochSig = 'NEUTRAL'
      try {
        $stochItem = @($s1h.strategies | Where-Object { $_ -match 'Stoch' }) | Select-Object -First 1
        if($stochItem){ if($stochItem -match ':LONG'){ $stochSig = 'LONG' } elseif($stochItem -match ':SHORT'){ $stochSig = 'SHORT' } }
      } catch {}

      # 组合C: Supertrend 替代 4H EMA 趋势判断(文档: Supertrend 更干净)
      $trend = $s4h.consensus
      $stTrend = ''
      if($enableComboC -and $s4h.indicators -and $s4h.indicators.supertrend -and $s4h.indicators.supertrend.direction){
        $stDir = [string]$s4h.indicators.supertrend.direction
        # comboCUseTrend=true 才用 Supertrend 替代趋势; false 仅记录(Supertrend 胜率~41% 偏弱, 2026-09-02 起默认不替代)
        if($comboCUseTrend){ if($stDir -eq 'up'){ $trend = 'LONG' } elseif($stDir -eq 'down'){ $trend = 'SHORT' } }
        $stTrend = $stDir
      }
      $resonance = 'NEUTRAL'
      # 多策略独立触发（增加信号）：三共振/Stoch/EMA 任一明确 + 趋势支持 即出信号
      # 三共振（主信号）：4H 趋势支持（多单需 LONG；空单需 SHORT，收紧模式外才放宽为 非LONG）
      if($shortSignal -like 'LONG*' -and $trend -eq 'LONG'){ $resonance = 'STRONG-LONG' }
      elseif($shortSignal -like 'SHORT*' -and ($trend -eq 'SHORT' -or -not $requireShortTrend)){ $resonance = 'STRONG-SHORT' }
      elseif($shortSignal -like 'LONG*'){ $resonance = 'WEAK-LONG' }
      elseif($shortSignal -like 'SHORT*' -and -not $requireShortTrend){ $resonance = 'WEAK-SHORT' }
      # Stoch 独立触发：只要 Stoch 明确 + 趋势同向（不依赖三共振中性）
      $stochBoostNote = $null; $emaBoostNote = $null
      if($resonance -eq 'NEUTRAL' -and $stochSig -ne 'NEUTRAL'){
        if($stochSig -eq 'LONG' -and $trend -eq 'LONG'){ $resonance = 'WEAK-LONG'; $stochBoostNote = 'LONG' }
        elseif($stochSig -eq 'SHORT' -and ($trend -eq 'SHORT' -or -not $requireShortTrend)){ $resonance = 'WEAK-SHORT'; $stochBoostNote = 'SHORT' }
      }
      # EMA+ADX 独立触发：EMA 明确 + 趋势同向
      if($resonance -eq 'NEUTRAL'){
        try {
          $emaItem = @($s1h.strategies | Where-Object { $_ -match 'EMA' }) | Select-Object -First 1
          if($emaItem){
            $emaSig = 'NEUTRAL'
            if($emaItem -match ':LONG'){ $emaSig = 'LONG' } elseif($emaItem -match ':SHORT'){ $emaSig = 'SHORT' }
            if($emaSig -eq 'LONG' -and $trend -eq 'LONG'){ $resonance = 'WEAK-LONG'; $emaBoostNote = 'LONG' }
            elseif($emaSig -eq 'SHORT' -and ($trend -eq 'SHORT' -or -not $requireShortTrend)){ $resonance = 'WEAK-SHORT'; $emaBoostNote = 'SHORT' }
          }
        } catch {}
      }
      # 多单降门槛：WEAK-LONG 也可开（不再强制 STRONG-LONG）
      # （强空单偏好保留在开仓判断里）

      # 组合A: CHOP 过滤(震荡市>61.8否决趋势信号) + Squeeze 记录(释放方向)
      $chopBlockNote = $null
      $chopBlockDir = $null
      $squeezeNote = $null
      if($enableComboA){
        $chop1h = if($s1h.indicators -and $null -ne $s1h.indicators.choppiness){ [double]$s1h.indicators.choppiness } else { 50 }
        if($resonance -match 'STRONG|WEAK' -and $chop1h -gt 61.8){
          $chopBlockDir = $resonance   # 记录被否决前的方向(组合A 独立跟踪用: 验证"不否决会不会赢")
          $resonance = 'NEUTRAL'
          $chopBlockNote = "CHOP=$([math]::Round($chop1h,1))震荡市否决"
        }
        if($s1h.indicators -and $s1h.indicators.ttmSqueeze -and $s1h.indicators.ttmSqueeze.momentum){
          $squeezeNote = [math]::Round([double]$s1h.indicators.ttmSqueeze.momentum, 2)
        }
      }

      # 榜单方向约束：先看涨跌幅榜单定方向，再看 K 线确认
      # 涨幅榜(chg>0)只做多；跌幅榜(chg<0)只做空（逆榜单方向信号直接否决）
      $boardFilteredNote = $null
      if($cand.chg -gt 0 -and $resonance -match 'SHORT'){ $resonance = 'NEUTRAL'; $boardFilteredNote = '逆涨幅榜做空否决' }
      elseif($cand.chg -lt 0 -and $resonance -match 'LONG'){ $resonance = 'NEUTRAL'; $boardFilteredNote = '逆跌幅榜做多否决' }

      $entry = [ordered]@{
        ts=$ts; instId=$inst; chg24=$cand.chg; vol24=$cand.vol; inTradePool=($tradeList -contains $inst)
        price=$s1h.price; s15m=$s15m.consensus; s1h=$s1h.consensus; s4h_trend=$trend; shortSignal=$shortSignal; resonance=$resonance; stochSig=$stochSig; chopBlockDir=$chopBlockDir
      }
      if($stochBoostNote){ $entry.stochBoost = $stochBoostNote }
      if($emaBoostNote){ $entry.emaBoost = $emaBoostNote }
      if($boardFilteredNote){ $entry.boardFiltered = $boardFilteredNote }
      if($stTrend){ $entry.supertrend4h = $stTrend }
      if($chopBlockNote){ $entry.chopBlock = $chopBlockNote }
      if($squeezeNote){ $entry.squeeze = $squeezeNote }

      # 3. 山寨币策略（动量/反弹）：共振 NEUTRAL 的池外候选跑山寨引擎
      $altSignal = $null
      if(-not ($tradeList -contains $inst) -and $resonance -eq 'NEUTRAL'){
        $altCandleFile = Join-Path $dataDir ($inst + '_1H.json')
        $altSignal = Get-AltSignal $inst $altCandleFile
        if($altSignal -and ($altSignal.signal -eq 'LONG' -or $altSignal.signal -eq 'SHORT')){
          # 山寨方向约束：动量做多需涨幅榜(chg>0)；反弹做多需深跌(chg<-15%)；爆拉回落做空需涨幅榜(chg>30%)
          $altDir = $altSignal.signal
          $altStrat = $altSignal.strategy
          $dirBlock = $false
          if($altDir -eq 'LONG' -and $altStrat -like '*动量*' -and $cand.chg -le 0){ $dirBlock = $true }
          elseif($altDir -eq 'LONG' -and $altStrat -like '*反弹*' -and $cand.chg -gt -15){ $dirBlock = $true }
          elseif($altDir -eq 'SHORT' -and $cand.chg -lt 30){ $dirBlock = $true }
          if($dirBlock){
            $entry.altStrategy = $altStrat
            $entry.tradeSkip = '山寨方向约束否决'
            $out.signals += $entry
            continue
          }
          $entry.altStrategy = $altStrat
          $entry.altScore = $altSignal.score
          # 动态反向: ALT策略正向胜率<阈值 → 方向取反(如 动量爆发 反向做空)
          $altRevKey = 'ALT:' + $altStrat
          # revexclude-decision-fix-20261011: 在决定方向的唯一位置再挡一次(reverseExclude 里的策略永不反向)
          # forcereverse-20261014: rules.forceReverse 里的策略无条件反向(优先于动态反向集/反向排除)
          $altForceRev = ($script:forceReverse -and $script:forceReverse.Count -gt 0 -and ($script:forceReverse -contains $altRevKey))
          if($altForceRev -or ($script:reverseSet -and $script:reverseSet.ContainsKey($altRevKey) -and -not ($script:reverseExclude -contains $altRevKey))){
            $altDir = if($altDir -eq 'LONG'){ 'SHORT' } else { 'LONG' }
            $entry.reversed = $altRevKey
            $entry.reversedDir = $altDir
            if($altForceRev){ $entry.forceReversed = $true; Write-Output ('{"info":"force-reverse ' + $altRevKey + ' -> ' + $altDir + '"}') }
          }
          # 开单成交额门槛(2026-09-11): 24h成交额 < minVolUsdt(默认200万U) → 不开单
          if($minVolOpen -gt 0 -and $cand -and $null -ne $cand.vol -and [double]$cand.vol -lt $minVolOpen){
            $entry.tradeSkip = ('low-volume(' + [math]::Round([double]$cand.vol/10000) + '万U)')
            $out.signals += $entry
            continue
          }
          # 普涨禁空(2026-09-18 用户规则, ALT分支): 全市场上涨占比>75% 期间禁止一切做空(滞回至<70%恢复)
          if($altDir -eq 'SHORT' -and $script:shortBlocked){
            $entry.tradeSkip = ('breadth-hot-short-block(upPct>' + $breadthShortOn + '%)')
            $out.signals += $entry
            continue
          }
          # 暴涨禁空(2026-09-18, ALT分支): 24h 涨幅 > maxChg24Short(默认12%) → 不做空
          # chg24exempt-20261014: rules.chg24ShortExemptStrategies 命中则豁免(ALT 动量策略天生抓暴涨币)
          $altChg24Exempt = ($script:chg24ShortExempt -and $script:chg24ShortExempt.Count -gt 0 -and ($script:chg24ShortExempt -contains $altRevKey))
          if($altChg24Exempt){ $entry.chg24Exempt = $true }
          if($altDir -eq 'SHORT' -and -not $altChg24Exempt -and $maxChg24Short -gt 0 -and $cand -and $null -ne $cand.chg -and [double]$cand.chg -gt $maxChg24Short){
            $entry.tradeSkip = ('chg24-hot-short-block(' + $cand.chg + '%>' + $maxChg24Short + '%)')
            $out.signals += $entry
            continue
          }
          # 反向空趋势过滤(2026-09-11, ALT分支): 同主流程——4H趋势向上/当日涨幅过大 → 不做反向空
          if($entry.reversed -and $altDir -eq 'SHORT' -and $revShortFilterOn){
            $blk = $false; $why = ''
            if($trend -eq 'LONG'){ $blk = $true; $why = '4H趋势向上' }
            if(-not $blk -and $cand -and $null -ne $cand.chg -and [double]$cand.chg -gt $revShortMaxChg){ $blk = $true; $why = ('当日涨'+$cand.chg+'%') }
            if($blk){
              $entry.tradeSkip = ('reverse-short-uptrend-block(' + $why + ')')
              $out.signals += $entry
              continue
            }
          }
          # 连续3天熔断: 禁用策略正反都不开
          if($script:disabledSet -and $script:disabledSet.ContainsKey($altRevKey)){
            # 2026-11-04 用户要求: 已禁用策略不再产生任何信号(ALT 分支)
            $script:disabledSignalSkipped++
            continue
          }
          # 同策略连续亏损冷却: 信号照常记录, 但不开单
          if($script:cooldownSet -and $script:cooldownSet.ContainsKey($altRevKey)){
            $entry.tradeSkip = 'strategy-cooldown'
            $out.signals += $entry
            continue
          }
          # 仅反向信号源(2026-09-06 ALTC补): ALT 只当动态反向信号源, 正向方向不开(除非被动态反向 $entry.reversed)。常规流程拦截不到 ALT(独立分支开仓)
          if(-not $entry.reversed -and $script:onlyReverseSource -and $script:onlyReverseSource.Count -gt 0 -and
             ($script:onlyReverseSource -contains $altRevKey -or $script:onlyReverseSource -contains $altStrat)){
            $entry.tradeSkip = 'forward-only-reverse-source'
            $out.signals += $entry
            continue
          }
          # 每轮最大开仓数(2026-09-10 补): ALT 原缺此检查, 会绕过 maxPerRound 控频(与主流程对齐)
          if($roundTrades -ge $maxPerRound){ $entry.tradeSkip = "round-limit($roundTrades/$maxPerRound)"; $out.signals += $entry; continue }
          # 同币限次(2026-09-10): 每币每日上限 $coinMaxPerDay(0=不限) 与 sameCoinOncePerDay(每币1单) 取更严者
          $coinTodayN = @($tried | Where-Object { $_.instId -eq $inst -and $_.date -eq $today }).Count
          # 2026-10-07 用户需求(选项2, ALT 分支同规则): 判定收窄到同一策略
          $altOverCap = (($coinMaxPerDay -gt 0) -and ($coinTodayN -ge $coinMaxPerDay))
          $reA = Get-CoinStrategyReentry $inst ([string]$altRevKey) $today
          $altSameDay = ($sameCoinOncePerDay -and $reA.tried)
          if($altSameDay -and -not $altOverCap){
            if($null -ne $reA.pnl -and [double]$reA.pnl -gt 0){ $altSameDay = $false; $entry.coinReentry = ('prev-trade-win(' + [math]::Round([double]$reA.pnl,2) + 'U,ALT)') }
            elseif($null -eq $reA.pnl){ $entry.coinReentry = 'prev-trade-unknown' }
          } elseif($sameCoinOncePerDay -and -not $reA.tried -and $coinTodayN -ge 1){
            $entry.coinReentry = 'no-same-strategy-trade(ALT)'
          }
          $coinLimited = $altOverCap -or $altSameDay
          if($coinLimited){ $entry.tradeSkip = ("coin-daily-limit({0}/{1})" -f $coinTodayN,$coinMaxPerDay); $out.signals += $entry }
          elseif(-not $riskOk.ok){ $entry.tradeSkip = $riskOk.reason; $out.signals += $entry }
          else {
            $ofRes = Get-OrderFlowSignal $inst
            $ofSignal = $ofRes.signal
            $entry.orderflow = $ofSignal
            # 订单流过滤(严格模式: 必须与方向一致才开仓; 关闭时退化为仅排除反向)
            $ofBlock = if($altDir -eq 'LONG'){ $ofSignal -eq 'BEARISH' } else { $ofSignal -eq 'BULLISH' }
            if($script:riskOn -and $altDir -eq 'SHORT'){ $entry.tradeSkip = 'risk-on-short-downgrade'; $out.signals += $entry }
            elseif(-not $ofBlock){
              if($script:deferOpen){
                $script:deferred.Add([pscustomobject]@{ inst=$inst; dir=$altDir; price=[double]$s1h.price; srcKey=$altRevKey; score=(Get-StrategyScore $altRevKey $false); entry=$entry })
                continue
              }
              $r = Invoke-Trade $inst $altDir ([double]$s1h.price) $altRevKey
              if($r.ok){
                $entry.trade = $r
                $entry.resonance = 'ALT-' + $altDir
                if($oiWatch){ $oiS = Get-OISnapshot $inst ([double]$s1h.price); if($oiS){ $entry.oi = $oiS } }
                $out.trades += $entry
                $roundTrades++
                Save-Tried $inst $altDir 0
              } else { $entry.tradeSkip = $r.reason; $out.signals += $entry }
            } else { $entry.tradeSkip = ('orderflow-block(信号=' + [string]$altDir + ', 订单流=' + [string]$ofSignal + ')'); $out.signals += $entry }
          }
          continue  # 山寨信号处理完，跳过常规流程
        } elseif($altSignal -and $altSignal.signal -eq 'FILTERED'){
          $entry.altStrategy = 'FILTERED'
          $entry.tradeSkip = $altSignal.detail
        }
      }

      # 4. 开仓评估（固定池 + 动态入池）：共振 + 订单流确认 -> 开仓
      #    固定池标的: STRONG/WEAK 都评估; 池外: 动态入池(STRONG/WEAK + 成交额≥dynMinVol, 解除币种限制时可放开)
      $inFixedPool = $tradeList -contains $inst
      $dynEligible = $false
      if(-not $inFixedPool -and $resonance -match 'STRONG|WEAK' -and $cand.vol -ge $dynMinVol){
        $dynEligible = $true
        $entry.dynamicEntry = $true
      }
      # 组合B: 背离做空(RSI顶背离 / CVD顶背离) - 独立触发, 绕过榜单/订单流方向过滤
      $divShort = $false
      if($enableComboB){
        $rsiDiv = if($s1h.indicators){ $s1h.indicators.rsiDivergence } else { $null }
        if($rsiDiv -and $rsiDiv.top){ $divShort = $true; $entry.rsiDivTop = $true; $entry.divShort = $true }
      }
      # 乙(2026-11-01 用户要求): 禁止"背离翻向" —— 已被 15m+1H(及4H) 确认为做多的信号，不再被 1H 顶背离翻成空单
      #   组合B 仍保留为独立做空腿：只在共振为 NEUTRAL / 做空 的币上生效
      if($divShort -and ($resonance -eq 'STRONG-LONG' -or $resonance -eq 'WEAK-LONG')){
        $divShort = $false; $entry.rsiDivTop = $false; $entry.divShort = $false
        $entry.divIgnored = 'LONG-signal-kept'
      }
      if(($inFixedPool -and $resonance -match 'STRONG|WEAK') -or $dynEligible -or $divShort){
        # 同币限次(2026-09-10): 每币每日上限 $coinMaxPerDay(0=不限) 与 sameCoinOncePerDay(每币1单) 取更严者
        $coinTodayN = @($tried | Where-Object { $_.instId -eq $inst -and $_.date -eq $today }).Count
        # 2026-10-07 用户需求(选项2): 判定收窄到**同一策略** —— 别的策略在本币今日的战绩不再封锁本策略。
        #   币级硬上限 coinMaxPerDay 与"已有持仓/挂单"闸门(防叠仓)保持不变。
        $overCap = (($coinMaxPerDay -gt 0) -and ($coinTodayN -ge $coinMaxPerDay))
        $stratKeyDaily = if($divShort){ if($entry.rsiDivTop){ '组合B:RSI顶背离' } elseif($entry.cvdDiv){ '组合B:CVD顶背离' } else { '组合B:背离做空' } } else { $resonance }
        $re = Get-CoinStrategyReentry $inst $stratKeyDaily $today
        $sameDayBlock = ($sameCoinOncePerDay -and $re.tried)
        if($sameDayBlock -and -not $overCap){
          if($null -ne $re.pnl -and [double]$re.pnl -gt 0){
            $sameDayBlock = $false
            $entry.coinReentry = ('prev-trade-win(' + [math]::Round([double]$re.pnl,2) + 'U)')
          } else {
            if($null -eq $re.pnl){ $entry.coinReentry = 'prev-trade-unknown' } else { $entry.coinReentry = ('prev-trade-loss(' + [math]::Round([double]$re.pnl,2) + 'U)') }
          }
        } elseif($sameCoinOncePerDay -and -not $re.tried -and $coinTodayN -ge 1){
          $entry.coinReentry = 'no-same-strategy-trade'
        }
        $already = if($overCap -or $sameDayBlock){ @('coin-daily-limit') } else { @() }
        if(-not $already){
          # 每轮最大开仓数(控频): 已达上限则跳过
          if($roundTrades -ge $maxPerRound){ $entry.tradeSkip = "round-limit($roundTrades/$maxPerRound)"; $out.signals += $entry; continue }
          # perCoin.strongOnly(高杠杆手动管理币, 2026-09-02): 只开 STRONG 最精准信号, WEAK 不开(含反向)
          $pcHere = if($perCoin -and $perCoin[$inst]){ $perCoin[$inst] } else { $null }
          if($pcHere -and $pcHere.strongOnly -and $resonance -match 'WEAK'){
            $entry.tradeSkip = 'weak-not-precise(strongOnly)'
            $out.signals += $entry
            continue
          }
          # 多单降门槛：WEAK-LONG / STRONG-LONG 都可开；空单 WEAK-SHORT / STRONG-SHORT 可开
          $dirCandidate = $null
          if($resonance -eq 'WEAK-SHORT' -or $resonance -eq 'STRONG-SHORT'){ $dirCandidate = 'SHORT' }
          elseif($resonance -eq 'WEAK-LONG' -or $resonance -eq 'STRONG-LONG'){ $dirCandidate = 'LONG' }
          # 组合B: 顶背离 → 强制做空方向(即使共振中性)
          if($divShort){ $dirCandidate = 'SHORT'; $entry.divShort = $true }
          # 连续3天熔断: 禁用策略正反都不开
          $revKey = if($divShort){ if($entry.rsiDivTop){ '组合B:RSI顶背离' } elseif($entry.cvdDiv){ '组合B:CVD顶背离' } else { '组合B:背离做空' } } else { $resonance }
          if($script:disabledSet -and $script:disabledSet.ContainsKey($revKey)){
            # 2026-11-04 用户要求: 已禁用的策略不再产生任何信号(不写 signals / journal / BI)，只计数留痕
            $script:disabledSignalSkipped++
            continue
          }
          # 同策略连续亏损冷却: 信号照常记录, 但不开单(正反都停)
          if($script:cooldownSet -and $script:cooldownSet.ContainsKey($revKey)){
            $entry.tradeSkip = 'strategy-cooldown'
            $out.signals += $entry
            continue
          }
          # 动态反向: 主策略/组合B 正向胜率<阈值 → 方向取反
          # forcereverse-20261014: rules.forceReverse 里的策略无条件反向
          $forceRevHit = ($script:forceReverse -and $script:forceReverse.Count -gt 0 -and ($script:forceReverse -contains $revKey))
          if($forceRevHit -or ($script:reverseSet -and $script:reverseSet.ContainsKey($revKey) -and -not ($script:reverseExclude -contains $revKey))){   # revexclude-decision-fix
            $dirCandidate = if($dirCandidate -eq 'LONG'){ 'SHORT' } else { 'LONG' }
            $entry.reversed = $revKey
            $entry.reversedDir = $dirCandidate
            if($forceRevHit){ $entry.forceReversed = $true; Write-Output ('{"info":"force-reverse ' + $revKey + ' -> ' + $dirCandidate + '"}') }
          }
          # 普涨禁空(2026-09-18 用户规则): 全市场上涨占比>75% 期间禁止一切做空(含组合B背离/动态反向空); 滞回至<70%恢复
          if($dirCandidate -eq 'SHORT' -and $script:shortBlocked){
            $entry.tradeSkip = ('breadth-hot-short-block(upPct>' + $breadthShortOn + '%)')
            $out.signals += $entry
            continue
          }
          # 暴涨禁空(2026-09-18): 该币 24h 涨幅 > maxChg24Short(默认12%) → 禁止一切新开空(含组合B背离/动态反向空)
          #   依据回测: chg24>12 的空单均收益 +0.41%(赚钱), chg24<=12 的均收益 -0.72%(亏钱, 主要亏源) → 拦掉赚钱的那档
          #   位置: 放在 $dirCandidate 定稿之后(组合B 已强制 SHORT), 确保组合B背离空也被覆盖
          # chg24exempt-20261014: rules.chg24ShortExemptStrategies 命中则豁免
          $chg24ExemptHit = ($script:chg24ShortExempt -and $script:chg24ShortExempt.Count -gt 0 -and ($script:chg24ShortExempt -contains $revKey))
          if($chg24ExemptHit){ $entry.chg24Exempt = $true }
          if($dirCandidate -eq 'SHORT' -and -not $chg24ExemptHit -and $maxChg24Short -gt 0 -and $cand -and $null -ne $cand.chg -and [double]$cand.chg -gt $maxChg24Short){
            $entry.tradeSkip = ('chg24-hot-short-block(' + $cand.chg + '%>' + $maxChg24Short + '%)')
            $out.signals += $entry
            continue
          }
          # 反向空趋势过滤(2026-09-11): 反向做空遇到"该币 4H 趋势明确向上"或"当日涨幅过大" → 跳过(单边上涨币反向做空=反复送钱)
          if($entry.reversed -and $dirCandidate -eq 'SHORT' -and $revShortFilterOn){
            $blk = $false; $why = ''
            if($trend -eq 'LONG'){ $blk = $true; $why = '4H趋势向上' }
            if(-not $blk -and $cand -and $null -ne $cand.chg -and [double]$cand.chg -gt $revShortMaxChg){ $blk = $true; $why = ('当日涨'+$cand.chg+'%') }
            if($blk){
              $entry.tradeSkip = ('reverse-short-uptrend-block(' + $why + ')')
              $out.signals += $entry
              continue
            }
          }
          # 仅反向信号源(2026-09-06): 白名单里连带的 STRONG-LONG/WEAK-LONG/ALT:动量 只在动态反向时开, 否则正向停(只留信号供反向判定)
          if(-not $entry.reversed -and $script:onlyReverseSource -and $script:onlyReverseSource.Count -gt 0){
            $isRevSrcOnly = $false
            if($revKey -and ($script:onlyReverseSource -contains $revKey)){ $isRevSrcOnly = $true }
            if([string]$entry.altStrategy -and ($script:onlyReverseSource -contains [string]$entry.altStrategy)){ $isRevSrcOnly = $true }
            if($isRevSrcOnly){
              $entry.tradeSkip = 'forward-only-reverse-source'
              $out.signals += $entry
              continue
            }
          }
          if($dirCandidate){
            # 开单成交额门槛(2026-09-11): 24h成交额 < minVolUsdt(默认200万U) → 不开单
            if($minVolOpen -gt 0 -and $cand -and $null -ne $cand.vol -and [double]$cand.vol -lt $minVolOpen){
              $entry.tradeSkip = ('low-volume(' + [math]::Round([double]$cand.vol/10000) + '万U)')
              $out.signals += $entry
              continue
            }
            # risk-on 空单降级(2026-09-07; 2026-09-12 调整: 组合B顶背离不受限——实测今日顶背离空 4h 胜率 67%, risk-on 属误杀):
            #   仍拦 = 动态反向空 / WEAK 等非 STRONG-SHORT 空; 放行 = 组合B背离空($divShort) 与 STRONG-SHORT(后者在 Invoke-Trade 内 ×0.7)
            if($dirCandidate -eq 'SHORT' -and $script:riskOn -and -not $divShort -and ($entry.reversed -or $resonance -ne 'STRONG-SHORT')){
              $entry.tradeSkip = 'risk-on-short-downgrade'
              $out.signals += $entry
              continue
            }
            $ofRes = Get-OrderFlowSignal $inst
            $ofSignal = $ofRes.signal
            $ofDiv = $ofRes.divergence
            $entry.orderflow = $ofSignal
            # 乙②(2026-11-01): 同上，已确认的多头信号保持做多；甲(2026-11-01): 背离生效时同步修正策略标签，避免订单归因错乱
            if($enableComboB -and $ofDiv -eq 'bull-divergence' -and $dirCandidate -ne 'LONG'){
              # 2026-11-02 用户要求: 禁用 "组合B:CVD顶背离" 标签, 但这些币仍按原共振方向(如 STRONG-SHORT)正常开单。
              #   → 策略被禁用/冷却时【忽略背离】: 不改方向、不改标签、不拦截, 仅置 cvdIgnored 供订单流闸门豁免。
              $cvdName = '组合B:CVD顶背离'
              $cvdOff = ($script:disabledSet -and $script:disabledSet.ContainsKey($cvdName)) -or ($script:cooldownSet -and $script:cooldownSet.ContainsKey($cvdName))
              if($cvdOff){
                $entry.cvdIgnored = ($cvdName + '(disabled-按原共振方向走)')
              } else {
                $divShort = $true; $entry.cvdDiv = 'bull-divergence'; $dirCandidate = 'SHORT'; $entry.divShort = $true
                $revKey = $cvdName
              }
            } elseif($enableComboB -and $ofDiv -eq 'bull-divergence'){
              $entry.divIgnored = 'LONG-signal-kept'
            }
            # 订单流过滤(2026-08-30 修正: 仅排除明确反向, NEUTRAL 放行——orderflow 大部分为 NEUTRAL, 强制 BULLISH/BEARISH 会把信号全拦掉; 组合B背离绕过)
            $dir = $null
            if($dirCandidate -eq 'LONG' -and $ofSignal -ne 'BEARISH'){ $dir = 'LONG' }
            elseif($dirCandidate -eq 'SHORT' -and ($ofSignal -ne 'BULLISH' -or $divShort -or $entry.cvdIgnored)){ $dir = 'SHORT' }
            # chg24 方向规则(2026-10-23 用户要求): 用该币 24h 涨幅决定"只做多 / 只做空 / 不做"
            #   位置: 最终方向 $dir 定稿之后、下单之前; 只拦单、不强行翻方向（不会凭空造出信号方向之外的仓）
            if($dir -and $chg24DirEnabled -and $cand -and $null -ne $cand.chg){
              $cNow = [double]$cand.chg
              $dirExemptHit = $false
              if($script:chg24DirExempt -and $script:chg24DirExempt.Count -gt 0){
                if($revKey -and ($script:chg24DirExempt -contains $revKey)){ $dirExemptHit = $true }
                if([string]$entry.altStrategy -and ($script:chg24DirExempt -contains [string]$entry.altStrategy)){ $dirExemptHit = $true }
              }
              if(-not $dirExemptHit){
                $ruleDir = $null
                if($cNow -lt $chg24DirLongMax){ $ruleDir = 'LONG' }
                elseif($cNow -ge $chg24DirShortMin){ $ruleDir = 'SHORT' }
                if(-not $ruleDir){
                  $entry.tradeSkip = ('chg24-dir-deadzone(chg24=' + $cNow + '% 落在 ' + $chg24DirLongMax + '~' + $chg24DirShortMin + '% 死区)')
                  $entry.chg24Dir = 'deadzone'
                  $out.signals += $entry
                  continue
                }
                if($dir -ne $ruleDir){
                  $entry.tradeSkip = ('chg24-dir-mismatch(' + $dir + '信号 但 chg24=' + $cNow + '%, 规则要求' + $ruleDir + ')')
                  $entry.chg24Dir = 'mismatch'
                  $out.signals += $entry
                  continue
                }
                $entry.chg24Dir = $ruleDir
              } else { $entry.chg24Dir = 'exempt' }
            }
            if($dir){
              # 仓位轮换：满仓时若新信号强且现有弱仓，先平弱仓
              $tradeDone = $false
              if($riskOk.ok){
                if($script:deferOpen){
                  $script:deferred.Add([pscustomobject]@{ inst=$inst; dir=$dir; price=[double]$s1h.price; srcKey=$revKey; score=(Get-StrategyScore $revKey ([bool]$entry.reversed)); entry=$entry })
                  continue
                }
                $r = Invoke-Trade $inst $dir ([double]$s1h.price) $revKey
                if($r.ok){
                  $entry.trade = $r
                  if($oiWatch){ $oiS = Get-OISnapshot $inst ([double]$s1h.price); if($oiS){ $entry.oi = $oiS } }
                  $out.trades += $entry; $roundTrades++; Save-Tried $inst $dir 0; $tradeDone = $true
                }
                else { $entry.tradeSkip = $r.reason; $out.signals += $entry; $tradeDone = $true }
              } else {
                # risk-blocked（满仓）时尝试轮换：若新信号 STRONG 且有浮亏仓，先平最弱仓再开
                # 实盘模式禁用轮换: 可能误平用户自有持仓
                if($resonance -match 'STRONG' -and -not $isLive){
                  $rot = Try-Rotate $inst $dir
                  if($rot.rotated){
                    $entry.rotated = "平掉 $($rot.closedInst) (浮亏 $([math]::Round($rot.closedUpl,2))U) 换新仓"
                    Start-Sleep -Milliseconds 500
                    $r = Invoke-Trade $inst $dir ([double]$s1h.price) $revKey
                    if($r.ok){
                      $entry.trade = $r
                      if($oiWatch){ $oiS = Get-OISnapshot $inst ([double]$s1h.price); if($oiS){ $entry.oi = $oiS } }
                      $out.trades += $entry; $roundTrades++; Save-Tried $inst $dir 0
                    }
                    else { $entry.tradeSkip = $r.reason; $out.signals += $entry }
                  } else {
                    $entry.tradeSkip = "$($riskOk.reason)|轮换:$($rot.reason)"
                    $out.signals += $entry
                  }
                } else {
                  $entry.tradeSkip = $riskOk.reason
                  $out.signals += $entry
                }
              }
            } else {
              $entry.tradeSkip = ('orderflow-block(信号=' + [string]$dirCandidate + ', 订单流=' + [string]$ofSignal + ')')
              $out.signals += $entry
            }
          } else {
            # 多单但非 STRONG（WEAK-LONG 或 未达条件）：记录不执行（强空单偏好）
            $entry.tradeSkip = 'long-needs-strong'
            $out.signals += $entry
          }
        } else {
          $reNote = if($entry.coinReentry){ [string]$entry.coinReentry } else { '同币同策略今日已开过' }
          $entry.tradeSkip = ('already-tried-today(上一单=' + $reNote + ', 规则=sameCoinOncePerDay)')
          $out.signals += $entry
        }
      } else {
        # 2026-10-07 补: 本路径原本只记录不写原因(journal note=null), 面板无法归因。
        # 但这条 else 是"所有非方向候选"的常规出口(中性币也走这里, 每轮约 30 个) → 只有真带方向的信号才写原因;
        # 否则会把 BTC/ETH 这类中性候选全部误标成"成交额不足"(2026-10-07 16:00 那轮实测 29/29 被误标)。
        # 2026-10-07 修: 此前会覆盖更具体的原因(实测 ALT:FILTERED 的 v2-filter-blocked 被本行盖掉) -> 仅当原因为空才写
        if(-not $entry.tradeSkip -and ($resonance -match 'LONG|SHORT' -or $entry.altStrategy -or $entry.divShort -or $entry.reversed)){
          $entry.tradeSkip = 'not-in-pool(low-vol)'
        }
        $out.signals += $entry
      }
    } catch {
      $out.errors += ($inst + ': ' + $_.Exception.Message)
    }
  }

  # 择优开仓(rules.pickBest): 收集阶段已把所有"本可开"的候选暂存(未真开), 此处按策略实测平均盈亏降序, 只开前 $maxPerRound 个
  if($script:pickBest -and $script:deferred.Count -gt 0){
    $script:deferOpen = $false
    try {
      $ranked = @($script:deferred | Sort-Object -Property @{Expression={ [double]$_.score }; Descending=$true})
      $take = [math]::Max(1, [int]$maxPerRound)
      $chosen = @($ranked | Select-Object -First $take)
      $rest = @($ranked | Select-Object -Skip $take)
      foreach($c in $chosen){
        try {
          $r = Invoke-Trade $c.inst $c.dir ([double]$c.price) $c.srcKey
          if($r.ok){
            $c.entry.trade = $r
            $c.entry.pickBest = ('ranked-open score=' + [string]$c.score)
            $out.trades += $c.entry
            $roundTrades++
            Save-Tried $c.inst $c.dir 0
          } else {
            $c.entry.tradeSkip = ('pickBest-rejected: ' + [string]$r.reason)
            $out.signals += $c.entry
          }
        } catch { $out.errors += ('pickBest ' + $c.inst + ': ' + $_.Exception.Message); $out.signals += $c.entry }
      }
      foreach($c in $rest){ $c.entry.tradeSkip = ('pickBest-not-selected(score=' + [string]$c.score + ')'); $out.signals += $c.entry }
      Write-Output ('{"info":"pickbest selected ' + $chosen.Count + '/' + $script:deferred.Count + ': ' + (($chosen | ForEach-Object { $_.inst + '@' + [string]$_.score }) -join ',') + '"}')
    } catch { $out.errors += ('pickBest-block: ' + $_.Exception.Message) }
  }

  # 信号日志记录（Signal Journaling）：记录有方向信号 + 反向对照，去重防刷屏（同币同向同策略连续出现只记一次）
  try {
    $journalFile = Join-Path $baseDir ('signal-journal' + $suffix + '.json')
    $journal = [System.Collections.Generic.List[object]]::new()
    if(Test-Path $journalFile){
      try {
        $existing = Get-Content $journalFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if($existing){ foreach($e in $existing){ $journal.Add($e) } }
      } catch { }
    }
    $allEntries = @($out.signals) + @($out.trades)
    $lastFwd = @{}   # instId -> 最近一次已记录的正向信号(用于去重, 跨轮持久化)
    $lastStC = @{}   # 组合C Supertrend 去重(独立, 不与主信号共用)
    $lastChopA = @{} # 组合A CHOP否决 去重
    # 载入跨轮去重状态: 信号持续期间只记一次(方向/策略变化才记新条目), 避免 journal 每轮膨胀拖垮 1核服务器
    $stateFile = Join-Path $baseDir ('journal-state' + $suffix + '.json')
    if(Test-Path $stateFile){
      try {
        $st = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if($st){
          if($st.fwd){ foreach($p in $st.fwd.PSObject.Properties){ $lastFwd[$p.Name] = @{dir=[string]$p.Value.d; src=[string]$p.Value.s; t=if($p.Value.t){[string]$p.Value.t}else{''}} } }
          if($st.stC){ foreach($p in $st.stC.PSObject.Properties){ $lastStC[$p.Name] = [string]$p.Value } }
          if($st.chopA){ foreach($p in $st.chopA.PSObject.Properties){ $lastChopA[$p.Name] = [string]$p.Value } }
        }
      } catch {}
    }
    foreach($en in $allEntries){
      if($en.instId -and ($en.resonance -ne 'NEUTRAL' -or $en.altStrategy -or $en.trade -or $en.divShort -or $en.reversed)){
        # 推导方向和策略(动态反向优先: 记入 反向:<原策略>; 组合B次之; 实际成交记 TRADE)
        $dir = ''
        $src = $en.resonance
        if($en.reversed){ $dir = $en.reversedDir; $src = '反向:' + $en.reversed }
        elseif($en.divShort){ $dir = 'SHORT'; if($en.rsiDivTop){ $src = '组合B:RSI顶背离' } elseif($en.cvdDiv){ $src = '组合B:CVD顶背离' } else { $src = '组合B:背离做空' } }
        elseif($en.trade -and (!$en.resonance -or $en.resonance -eq 'NEUTRAL')){ $dir = $en.trade.type -replace 'swap-','' ; $src = 'TRADE' }
        elseif($en.altStrategy){ $dir = 'LONG'; $src = 'ALT:' + $en.altStrategy }
        elseif($en.resonance -match 'LONG'){ $dir = 'LONG' }
        elseif($en.resonance -match 'SHORT'){ $dir = 'SHORT' }
        if($dir){
          # 去重(时间窗版, 2026-09-08 修复): 同 instId 同方向同策略已记录且距上次记录 < journalReEmitHours(默认24h) → 跳过;
          # 超过时间窗(平仓后隔日重开/新 episode)允许重新记录——之前永久去重导致验证库7天零新增
          $revDir = if($dir -eq 'LONG'){ 'SHORT' } else { 'LONG' }
          $revKey = '反向对照:' + $src
          $lf = $lastFwd[$en.instId]
          $dupFwd = $false
          if($lf -and $lf.dir -eq $dir -and $lf.src -eq $src){
            $ageH = 9999
            if($lf.t){
              try { $ageH = ((Get-Date) - [datetime][string]$lf.t).TotalHours } catch { $ageH = 9999 }
            }
            if($ageH -lt $journalReEmitH){ $dupFwd = $true }
          }
          if(-not $dupFwd){
            $bp  = Get-BarrierPx $(if($en.price){ [double]$en.price } else { 0 }) $dir  $src  $en.instId
            $bp2 = Get-BarrierPx $(if($en.price){ [double]$en.price } else { 0 }) $revDir $revKey $en.instId
            $journal.Add([ordered]@{
              ts=$ts; instId=$en.instId; direction=$dir; strategy=$src
              entryPrice=if($en.price){ [double]$en.price } else { 0 }
              tpPx=$bp.tp; slPx=$bp.sl
              coinReentry=if($en.coinReentry){ [string]$en.coinReentry } else { '' }
              note=$en.tradeSkip
              clOrdId=if($en.trade -and $en.trade.clOrdId){ [string]$en.trade.clOrdId } else { '' }
            })
            $journal.Add([ordered]@{
              ts=$ts; instId=$en.instId; direction=$revDir; strategy=$revKey
              entryPrice=if($en.price){ [double]$en.price } else { 0 }
              tpPx=$bp2.tp; slPx=$bp2.sl
              note='反向测试-不实盘'
            })
            $lastFwd[$en.instId] = @{ dir=$dir; src=$src; t=$ts }
          }
        }
      }
      # 组合C 独立跟踪: Supertrend 方向翻转时记假设条目(4h验证后进排行, 看 Supertrend 自身判断水平)
      if($enableComboC -and $en.supertrend4h){
        $stDir = if([string]$en.supertrend4h -eq 'up'){ 'LONG' } elseif([string]$en.supertrend4h -eq 'down'){ 'SHORT' } else { $null }
        if($stDir -and $lastStC[$en.instId] -ne $stDir){
          $lastStC[$en.instId] = $stDir
          $journal.Add([ordered]@{
            ts=$ts; instId=$en.instId; direction=$stDir; strategy='组合C:Supertrend'
            entryPrice=if($en.price){ [double]$en.price } else { 0 }
            note='Supertrend方向'
          })
          $journal.Add([ordered]@{
            ts=$ts; instId=$en.instId; direction=$(if($stDir -eq 'LONG'){ 'SHORT' } else { 'LONG' }); strategy='反向对照:组合C:Supertrend'
            entryPrice=if($en.price){ [double]$en.price } else { 0 }
            note='反向测试-不实盘'
          })
        }
      }
      # 组合A 独立跟踪: CHOP 否决的信号按原方向记假设条目(验证"不否决会不会赢" -> 过滤器是否有效)
      if($enableComboA -and $en.chopBlockDir){
        $aDir = if([string]$en.chopBlockDir -match 'SHORT'){ 'SHORT' } elseif([string]$en.chopBlockDir -match 'LONG'){ 'LONG' } else { $null }
        if($aDir -and $lastChopA[$en.instId] -ne $aDir){
          $lastChopA[$en.instId] = $aDir
          $journal.Add([ordered]@{
            ts=$ts; instId=$en.instId; direction=$aDir; strategy='组合A:CHOP否决'
            entryPrice=if($en.price){ [double]$en.price } else { 0 }
            note=$en.chopBlock
          })
          $journal.Add([ordered]@{
            ts=$ts; instId=$en.instId; direction=$(if($aDir -eq 'LONG'){ 'SHORT' } else { 'LONG' }); strategy='反向对照:组合A:CHOP否决'
            entryPrice=if($en.price){ [double]$en.price } else { 0 }
            note='反向测试-不实盘'
          })
        }
      }
    }
    if($journal.Count -gt 0){
      # 原子写入(防进程中断截断损坏 journal)
      $tmpJ = $journalFile + '.tmp'
      $journal.ToArray() | ConvertTo-Json -Depth 5 | Out-File $tmpJ -Encoding UTF8
      if(Test-Path $tmpJ){ Move-Item -Path $tmpJ -Destination $journalFile -Force }
    }
    # 保存跨轮去重状态(供下一轮去重, 防止 journal 每轮重复记录而无限膨胀)
    try {
      $stOut = [ordered]@{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); fwd=[ordered]@{}; stC=[ordered]@{}; chopA=[ordered]@{} }
      foreach($k in $lastFwd.Keys){ $stOut.fwd[$k] = [ordered]@{ d=$lastFwd[$k].dir; s=$lastFwd[$k].src; t=$lastFwd[$k].t } }
      foreach($k in $lastStC.Keys){ $stOut.stC[$k] = $lastStC[$k] }
      foreach($k in $lastChopA.Keys){ $stOut.chopA[$k] = $lastChopA[$k] }
      $tmpS = $stateFile + '.tmp'
      $stOut | ConvertTo-Json -Depth 4 | Out-File $tmpS -Encoding UTF8
      if(Test-Path $tmpS){ Move-Item -Path $tmpS -Destination $stateFile -Force }
    } catch {}
  } catch {}

  if($script:disabledSignalSkipped -gt 0){ $out['disabledSignalsSkipped'] = $script:disabledSignalSkipped }
  $json = $out | ConvertTo-Json -Depth 7
  Add-Content -Path $strategyLog -Value $json -Encoding UTF8
  Write-Snapshot
  # 大额成交流水采集名单(2026-09-17): 把本轮"有方向信号"的币写出去 —— whale-collect 每分钟优先采样这些币,
  # 这样才能在开仓前拿到该币的大额流向(否则采集名单只知道已经开过的币, tape 样本永远配不上信号时刻)
  try {
    $whaleCoins = @($out.signals | Where-Object { $_.instId -and ($_.resonance -match 'LONG|SHORT' -or $_.altStrategy -or $_.divShort -or $_.reversed) } | ForEach-Object { [string]$_.instId } | Select-Object -Unique)
    @{ ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); insts=@($whaleCoins) } | ConvertTo-Json -Depth 3 | Out-File (Join-Path $baseDir 'whale-watch.json') -Encoding UTF8
  } catch {}
  # 孤儿止盈止损清理(2026-09-04): 平仓残留的算法单会误平未来新仓, 每轮结束清一次
  try { Cleanup-OrphanAlgos } catch {}
  Write-Output $json
}

# ===== read-only probe (2026-11-03) =====
# Lets test/snapshot.js cover the PowerShell-side calculations (Get-VolFactor / Get-RefHigh).
# Read-only: prints one JSON line then exits. Never enters the round loop, places no orders,
# writes no state file. Triggered only when -ProbeFunc is given.
if($ProbeFunc){
  try {
    if($ProbeDataDir){ $dataDir = $ProbeDataDir }
    $probeVal = $null
    switch($ProbeFunc){
      'volfactor' { $probeVal = Get-VolFactor $ProbeInst }
      'refhigh'   { $probeVal = Get-RefHigh   $ProbeInst }
      default     { throw ('unknown probe func: ' + $ProbeFunc) }
    }
    $probeOut = [ordered]@{ func=$ProbeFunc; inst=$ProbeInst; value=$probeVal; dataDir=$dataDir }
    Write-Output (ConvertTo-Json -InputObject $probeOut -Compress -Depth 5)
  } catch {
    $probeErr = [ordered]@{ func=$ProbeFunc; inst=$ProbeInst; error=('' + $_.Exception.Message) }
    Write-Output (ConvertTo-Json -InputObject $probeErr -Compress -Depth 5)
  }
  exit 0
}
# ===== end read-only probe (2026-11-03) =====

$round = 0
if($Once){
  Invoke-Round 1
} else {
  if($IntervalSec -le 0){ $IntervalSec = 3600 }
  # 准点触发(2026-09-04): 对齐到 IntervalSec 的整点边界(UTC epoch 对齐)。
  #   2026-10-01 改为 3600s=1 小时 → 触发时刻 = 北京时间每整点 :00:00, 即 1H K线收盘瞬间。
  # 等点期间每 60 秒做两件事:
  #   ① 同步开单闸门开关(轮次间隔拉长到 1 小时后, 若不在此轮询, 点 BI 按钮最长要等 1 小时才生效)
  #   ② 若存在限价挂单, 做成交检查——成交后立即补挂 OCO/移动止损, 不用等下一轮
  while($true){
    try {
      $epoch = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
      $nextSlot = ([math]::Floor($epoch / $IntervalSec) + 1) * $IntervalSec
      $waitS = $nextSlot - $epoch
      if($waitS -gt 0){
        Write-Output ('{"info":"waiting ' + $waitS + 's to next aligned round slot"}')
        while([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() -lt $nextSlot){
          # ① 开单闸门每 60 秒同步(仅读本地文件, 开销可忽略) —— 保证"点按钮 ≤60 秒生效"
          try { Sync-TradingSwitch | Out-Null } catch {}
          # ①b 若闸门状态与上次写回的 applied 文件不同, 立即刷新 —— 否则 BI 上"已生效"要等下一轮(最长 1 小时)才更新
          try {
            $swNow = Get-TradingSwitch
            $needWrite = $true
            if(Test-Path $script:tradeSwitchAppliedFile){
              try {
                $curA = Get-Content $script:tradeSwitchAppliedFile -Raw -Encoding UTF8 | ConvertFrom-Json
                if($curA -and ([bool]$curA.allowOpen -eq [bool]$swNow.allowOpen) -and ([string]$curA.switchUpdatedAt -eq [string]$swNow.updatedAt)){ $needWrite = $false }
              } catch {}
            }
            if($needWrite){
              $appliedNow = [ordered]@{
                ts=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); round=$round
                allowOpen=[bool]$swNow.allowOpen; reason=[string]$swNow.reason
                cancelPendingOnPause=[bool]$swNow.cancelPending
                switchUpdatedAt=[string]$swNow.updatedAt
                switchFileMissing=[bool]$swNow.missing
                note='polled-between-rounds'
              }
              $tmpA = $script:tradeSwitchAppliedFile + '.tmp'
              $appliedNow | ConvertTo-Json -Depth 4 | Out-File $tmpA -Encoding UTF8
              if(Test-Path $tmpA){ Move-Item -Path $tmpA -Destination $script:tradeSwitchAppliedFile -Force }
            }
          } catch {}
          # ② 限价挂单成交检查
          $loFile = Join-Path $baseDir ('limit-orders' + $suffix + '.json')
          if(Test-Path $loFile){
            try {
              $los = @(Get-Content $loFile -Raw -Encoding UTF8 | ConvertFrom-Json)
              if($los.Count -gt 0){
                $attached = @(Check-LimitOrders)
                if($attached.Count -gt 0){
                  Write-Output ('{"info":"limit filled, protection attached: ' + (($attached | ForEach-Object { $_.instId + '/' + $_.action }) -join ',') + '"}')
                }
              }
            } catch {}
          }
          Start-Sleep -Seconds 60
        }
      }
    } catch { Write-Output ('{"error":"' + $_.Exception.Message + '"}') }
    $round++
    try { Invoke-Round $round } catch {
    $__em = ([string]$_.Exception.Message) -replace '"', "''"
    $__st = ([string]$_.ScriptStackTrace) -replace "\r?\n", " | " -replace '"', "'"
    if($__st.Length -gt 400){ $__st = $__st.Substring(0,400) }
    Write-Output ('{"error":"' + $__em + '","at":"' + $__st + '"}')
  }
  }
}