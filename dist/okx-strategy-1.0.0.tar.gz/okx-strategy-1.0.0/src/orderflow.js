// OKX 订单流信号模块 - 基于最近成交重建 CVD/失衡比
// 用法: node orderflow.js <instId> [--limit 500]
// 输入: 通过 okx CLI 拉取 market trades（含 side 字段）
// 输出: 失衡比 (buy ratio - 0.5)、CVD 趋势、近期买卖力量对比
'use strict';

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const isWin = process.platform === 'win32';

function okxCliJson(args) {
  let npmPrefix = 'D:\\Program Files\\nodejs';
  try { npmPrefix = execSync(isWin ? 'npm.cmd prefix -g' : 'npm prefix -g', { encoding: 'utf8', shell: isWin ? 'cmd.exe' : '/bin/sh' }).trim(); } catch (e) {}
  const okx = isWin ? path.join(npmPrefix, 'okx.cmd') : 'okx';
  const out = execSync(`"${okx}" --json ${args}`, { encoding: 'utf8', shell: isWin ? 'cmd.exe' : '/bin/sh', timeout: 20000 });
  if (out.charCodeAt(0) === 0xFEFF) return JSON.parse(out.slice(1));
  return JSON.parse(out);
}

function analyze(instId, limit = 500) {
  const trades = okxCliJson(`market trades ${instId} --limit ${limit}`);
  if (!trades || !trades.length) return { error: 'no trades' };

  let buyVol = 0, sellVol = 0, buyCount = 0, sellCount = 0;
  let cvd = 0;
  const recent = [];

  for (const t of trades) {
    const sz = parseFloat(t.sz);
    const isBuy = t.side === 'buy';
    if (isBuy) { buyVol += sz; buyCount++; cvd += sz; }
    else { sellVol += sz; sellCount++; cvd -= sz; }
  }

  const totalVol = buyVol + sellVol;
  const imbalance = totalVol > 0 ? buyVol / totalVol - 0.5 : 0;  // >0 买方主导
  const buyRatio = totalVol > 0 ? buyVol / totalVol : 0.5;

  // CVD 趋势：把成交按时间分成前半/后半，看 CVD 方向
  const half = Math.floor(trades.length / 2);
  let cvd1 = 0, cvd2 = 0;
  for (let i = 0; i < trades.length; i++) {
    const sz = parseFloat(trades[i].sz);
    const signed = trades[i].side === 'buy' ? sz : -sz;
    if (i < half) cvd1 += signed; else cvd2 += signed;
  }

  const lastPx = trades[0] ? parseFloat(trades[0].px) : null;
  const firstPx = trades[trades.length - 1] ? parseFloat(trades[trades.length - 1].px) : null;
  const priceChg = firstPx && lastPx ? (lastPx - firstPx) / firstPx : 0;

  return {
    instId,
    trades: trades.length,
    windowSec: trades.length > 1 ? Math.round((trades[0].ts - trades[trades.length - 1].ts) / 1000) : 0,
    buyVol, sellVol, buyRatio: +buyRatio.toFixed(3),
    imbalance: +imbalance.toFixed(3),       // >0 买方主导, <0 卖方主导
    cvd: +cvd.toFixed(4),
    cvdTrend: cvd2 - cvd1,                   // >0 CVD 在增强（买方加速）
    priceChgPct: +(priceChg * 100).toFixed(3),
    // 背离检测: 价格涨但 CVD 走弱 = 动能衰竭
    divergence: priceChg > 0 && (cvd2 - cvd1) < 0 ? 'bull-divergence' :
                priceChg < 0 && (cvd2 - cvd1) > 0 ? 'bear-divergence' : 'aligned',
    signal: imbalance > 0.05 && (cvd2 - cvd1) > 0 ? 'BULLISH' :
            imbalance < -0.05 && (cvd2 - cvd1) < 0 ? 'BEARISH' : 'NEUTRAL'
  };
}

// 主流程
const instId = process.argv[2] || 'BTC-USDT';
const limit = parseInt(process.argv[3] || '500', 10);
console.log(JSON.stringify(analyze(instId, limit), null, 2));
