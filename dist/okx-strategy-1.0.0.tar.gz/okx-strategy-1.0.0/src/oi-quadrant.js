#!/usr/bin/env node
/**
 * oi-quadrant.js — 持仓量 × 价格「四象限」快照（每轮调用一次，约 1~2 秒）
 *
 * 原理：market oi-change 一次就能拿到全市场各币的**持仓量变化%** 与 **价格变化%**，
 *       两者组合成四象限。不需要逐币调用。
 *
 *   价涨 + OI 增 → 多头增仓（新钱做多，健康上涨）
 *   价跌 + OI 增 → 空头增仓（新钱做空，健康下跌）← 接飞刀最危险的一种
 *   价涨 + OI 减 → 空头回补（涨势由平空推动，易乏力）
 *   价跌 + OI 减 → 多头离场（跌势由平多推动，易止跌）
 *   变化太小     → 平（不给判断，避免噪声）
 *
 * 用法：
 *   node oi-quadrant.js            # 落盘 oi-quadrant-live.json 并打印摘要
 *   node oi-quadrant.js --json     # 只打印 JSON（供 strategy-monitor 调用）
 *   node oi-quadrant.js --bar 15m --minOiPct 0.2 --minPxPct 0.1
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const D = process.env.OKX_RADAR_HOME || '/opt/okx-radar';
const OUT = path.join(D, 'oi-quadrant-live.json');
const argv = process.argv.slice(2);
const getArg = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };
const BAR = getArg('--bar', '1H');
const PROFILE = getArg('--profile', 'default');
const MIN_OI = parseFloat(getArg('--minOiPct', '0.3'));   // OI 变化小于此值 → 视为持平
const MIN_PX = parseFloat(getArg('--minPxPct', '0.2'));   // 价格变化小于此值 → 视为持平
const JSON_ONLY = argv.includes('--json');

function okx(a) {
  const out = execFileSync('okx', ['--json', '--profile', PROFILE, ...a], {
    encoding: 'utf8', timeout: 45000, maxBuffer: 64 * 1024 * 1024,
    stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, NO_UPDATE_NOTIFIER: '1', OKX_UPDATE_CHECK: 'false' }
  });
  const s = out.replace(/^\uFEFF/, '');
  const i = Math.min(...[s.indexOf('['), s.indexOf('{')].filter(x => x >= 0));
  return i < 0 ? null : JSON.parse(s.slice(i));
}

// 两次排序合并，扩大覆盖（单次上限 100）
function fetchAll() {
  const rows = [];
  const pulls = [
    ['--sortBy', 'oiUsd', '--sortOrder', 'desc'],
    ['--sortBy', 'absOiDeltaPct', '--sortOrder', 'desc', '--minOiUsd', '300000'],
    ['--sortBy', 'volUsd24h', '--sortOrder', 'desc']            // 补覆盖：成交额大的币
  ];
  for (const extra of pulls) {
    try {
      const j = okx(['market', 'oi-change', '--instType', 'SWAP', '--bar', BAR, '--limit', '100', ...extra]);
      const arr = Array.isArray(j) ? j : (j && j.data) || [];
      for (const r of arr) if (r && r.instId) rows.push(r);
    } catch (e) {
      if (!JSON_ONLY) console.error('[warn] oi-change 拉取失败: ' + String(e.message || '').slice(0, 80));
    }
  }
  return rows;
}

const t0 = Date.now();
const rows = fetchAll();
const map = {};
let nQ = { '涨增': 0, '跌增': 0, '涨减': 0, '跌减': 0, '平': 0 };
for (const r of rows) {
  if (map[r.instId]) continue;
  const dp = parseFloat(r.pxChgPct);
  const doi = parseFloat(r.oiDeltaPct);
  if (!isFinite(dp) || !isFinite(doi)) continue;
  let quad;
  if (Math.abs(doi) < MIN_OI || Math.abs(dp) < MIN_PX) quad = '平';
  else quad = (dp > 0 ? '涨' : '跌') + (doi > 0 ? '增' : '减');
  // 顺势 = 价涨OI增（该做多）/ 价跌OI增（该做空）
  const side = quad === '涨增' ? 'LONG' : quad === '跌增' ? 'SHORT' : '';
  map[r.instId] = {
    quad,
    side,                       // 增仓方向暗示的"顺势方向"
    dp: Math.round(dp * 100) / 100,
    doi: Math.round(doi * 100) / 100,
    oiUsd: Math.round(parseFloat(r.oiUsd || 0)),
    px: parseFloat(r.last || 0)
  };
  nQ[quad] = (nQ[quad] || 0) + 1;
}

const doc = {
  ts: new Date().toISOString().replace('T', ' ').slice(0, 19),
  tsMs: Date.now(),
  bar: BAR,
  elapsedMs: Date.now() - t0,
  thresholds: { minOiPct: MIN_OI, minPxPct: MIN_PX },
  counts: nQ,
  coins: Object.keys(map).length,
  map
};

if (JSON_ONLY) {
  process.stdout.write(JSON.stringify(doc));
} else {
  const tmp = OUT + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(doc));
  fs.renameSync(tmp, OUT);
  console.log('[ok] ' + doc.ts + '  ' + BAR + '  覆盖 ' + doc.coins + ' 个币  耗时 ' + doc.elapsedMs + 'ms');
  console.log('     价涨OI增 ' + (nQ['涨增'] || 0) + '  价跌OI增 ' + (nQ['跌增'] || 0)
    + '  价涨OI减 ' + (nQ['涨减'] || 0) + '  价跌OI减 ' + (nQ['跌减'] || 0) + '  平 ' + (nQ['平'] || 0));
  for (const c of ['AKE-USDT-SWAP', 'ZEC-USDT-SWAP', 'BTC-USDT-SWAP', 'ETH-USDT-SWAP']) {
    const v = map[c];
    if (v) console.log('     ' + c.padEnd(18) + v.quad + '  价' + (v.dp >= 0 ? '+' : '') + v.dp + '%  OI' + (v.doi >= 0 ? '+' : '') + v.doi + '%');
  }
}
