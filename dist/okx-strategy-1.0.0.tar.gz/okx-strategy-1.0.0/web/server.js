#!/usr/bin/env node
/*
 * OKX 量化系统 · 控制台后端（零依赖，单文件）
 * ------------------------------------------------------------------
 * 只做四件事：看状态 / 改三个档位 + 回撤熔断 / 一键停止开新单 / 导出诊断报告
 * 不做：平仓按钮、BI 面板、策略调参、回测、文案。
 *
 * 环境变量：
 *   OKX_RADAR_HOME  系统目录，默认 /opt/okx-radar
 *   OKX_SUFFIX      数据后缀，默认 -live
 *   OKX_PROFILE     OKX 账户 profile 名，默认 default（对应包装脚本 okx-default）
 *   OKX_BIN         直接指定 okx 命令（覆盖 profile 推导，测试用）
 *   MONITOR_UNIT    systemd 服务名，默认 okx-monitor-live
 *   CONSOLE_PORT    监听端口，默认 8080
 *   CONSOLE_BIND    监听地址，默认 0.0.0.0
 *
 * 设计约束（来自实测）：
 *   - 改 live-config.json 必须重启 okx-monitor-live 才生效；
 *   - 开单闸门是独立状态文件、每 60 秒轮询，点一下即生效、无需重启；
 *   - 轮次日志是多行美化 JSON，必须按"行首 { 到行首 }"整块解析，不能按行解析。
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

const RADAR = process.env.OKX_RADAR_HOME || '/opt/okx-radar';
const SUFFIX = process.env.OKX_SUFFIX || '-live';
const PROFILE = process.env.OKX_PROFILE || 'default';
const OKX_BIN = process.env.OKX_BIN || ('okx-' + PROFILE);
const MONITOR_UNIT = process.env.MONITOR_UNIT || 'okx-monitor-live';
const PORT = parseInt(process.env.CONSOLE_PORT || '8080', 10);
// 是否模拟盘：由 profile 名决定（launcher 默认 demo）——绝不靠界面上的文字判断
const DEMO = /demo/i.test(PROFILE);
const BIND = process.env.CONSOLE_BIND || '0.0.0.0';

const F = {
  config: path.join(RADAR, 'live-config.json'),
  signals: path.join(RADAR, 'strategy-signals' + SUFFIX + '.log'),
  switch: path.join(RADAR, 'trading-switch' + SUFFIX + '.json'),
  switchApplied: path.join(RADAR, 'trading-switch-applied' + SUFFIX + '.json'),
  equity: path.join(RADAR, 'equity-baseline' + SUFFIX + '.json'),
  auth: path.join(RADAR, 'console-auth.json'),
  today: path.join(RADAR, 'console-today-equity.json'),
  okxConfig: path.join(process.env.HOME || process.env.USERPROFILE || '/root', '.okx', 'config.toml'),
  wrapper: '/usr/local/bin/okx-' + PROFILE,
  version: path.join(RADAR, 'VERSION'),
};

const KNOWN = {
  notional: [10, 20, 50, 100, 200],
  leverage: [1, 2, 3, 5, 10],
  maxPerDay: [5, 10, 20, 99],
  minAvailEq: [0, 10, 20, 50, 100],
  ddHalt: [0, 0.1, 0.2, 0.3],
};

// ---------------------------------------------------------------- 工具

function readJSON(p, dflt) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return dflt; }
}

function tailText(p, maxBytes) {
  let fd;
  try {
    fd = fs.openSync(p, 'r');
    const size = fs.fstatSync(fd).size;
    const len = Math.min(size, maxBytes || 2 * 1024 * 1024);
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, size - len);
    let s = buf.toString('utf8');
    if (size > len) s = s.slice(s.indexOf('\n') + 1); // 丢掉第一行残片
    return s;
  } catch (e) { return ''; } finally { if (fd !== undefined) try { fs.closeSync(fd); } catch (e) {} }
}

function atomicWrite(p, obj) {
  const tmp = p + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 1), 'utf8');
  fs.renameSync(tmp, p);
}

function backup(p, tag) {
  try {
    if (fs.existsSync(p)) {
      const dst = p + '.bak-' + tag + '-' + stamp();
      fs.copyFileSync(p, dst);
      return path.basename(dst);
    }
  } catch (e) {}
  return null;
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
}

function nowStr() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

function run(cmd, args, timeoutMs) {
  // Windows 上 okx 是 .cmd 包装脚本，而且可能写成不带扩展名的 okx / okx-demo：
  // execFile 不认 PATHEXT，会直接 ENOENT，所以 win32 上除 .exe 外一律经 shell 调用（Linux 不受影响）。
  const needShell = process.platform === 'win32' && !/\.exe$/i.test(cmd);
  // 关掉 CLI 自身的 npm 更新检查：否则每次调用都可能去连 npm 源，把状态刷新拖到十几秒。
  const env = Object.assign({}, process.env, { NO_UPDATE_NOTIFIER: '1', OKX_UPDATE_CHECK: 'false', npm_config_update_notifier: 'false' });
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: timeoutMs || 20000, maxBuffer: 8 * 1024 * 1024, env: env, shell: needShell },
      (err, stdout, stderr) => resolve({ ok: !err, out: String(stdout || ''), err: String(stderr || (err && err.message) || '') }));
  });
}

// 从 CLI 输出里挑一句最有用的错误（CLI 把错误写 stderr，首行常是空的或"有更新可用"）
function pickError(text) {
  const lines = String(text || '').split('\n').map((s) => s.trim()).filter(Boolean)
    .filter((s) => !/^Update available|^Run: npm|^Version:|update notifier/i.test(s));
  const hit = lines.find((s) => /^(Error|error|Code|Hint)/.test(s)) || lines[0];
  return hit ? hit.slice(0, 160) : 'CLI 调用失败';
}

function okxJSON(args, timeoutMs) {
  return run(OKX_BIN, ['--json'].concat(args), timeoutMs).then((r) => {
    if (!r.ok) return { ok: false, error: pickError(r.err || r.out) };
    const s = r.out.trim();
    const i = s.search(/[[{]/);
    if (i < 0) return { ok: false, error: pickError(r.err) === 'CLI 调用失败' ? 'CLI 没有返回数据' : pickError(r.err) };
    try { return { ok: true, data: JSON.parse(s.slice(i)) }; } catch (e) { return { ok: false, error: 'CLI 返回的不是 JSON' }; }
  });
}

// ---------------------------------------------------------------- 日志解析

function parseLastRound(text) {
  if (!text) return null;
  text = text.replace(/^\uFEFF/, ''); // PS 5.1 的 Add-Content 会给文件加 BOM
  const lines = text.split('\n');
  let end = -1;
  for (let i = lines.length - 1; i >= 0; i--) { if (/^\}\s*$/.test(lines[i])) { end = i; break; } }
  if (end < 0) return null;
  let start = -1;
  for (let i = end; i >= 0; i--) { if (/^\{\s*$/.test(lines[i])) { start = i; break; } }
  if (start < 0 || end - start < 2) return null;
  try { return JSON.parse(lines.slice(start, end + 1).join('\n')); } catch (e) { return null; }
}

// 把 tradeSkip 翻成人话。返回 { text, list:[{n, why}] }
function explainNoTrade(round) {
  if (!round) return { text: '还没有读到系统的运行记录，稍等一轮（最多 30 分钟）。', list: [] };
  const trades = Array.isArray(round.trades) ? round.trades.filter(Boolean) : [];
  const sigsAll = Array.isArray(round.signals) ? round.signals : [];
  // 真信号 = 共振等级非 NEUTRAL，或触发了组合/山寨/背离类信号；空 tradeSkip 只代表"没进入开单判定"
  const real = sigsAll.filter((x) => x && ((x.resonance && x.resonance !== 'NEUTRAL') || x.altStrategy || x.rsiDivTop || x.divShort || x.tradeSkip));
  if (sigsAll.length && !real.length) {
    return { text: '本轮扫描了 ' + sigsAll.length + ' 个候选，但没有任何币形成交易信号（技术面还没共振）—— 属于正常情况，系统只在有机会时才开单。', list: [] };
  }
  const sigs = Array.isArray(round.signals) ? round.signals : [];
  if (trades.length > 0) return { text: '本轮开了 ' + trades.length + ' 笔单。', list: [] };

  const buckets = new Map();
  const add = (key, why) => { const b = buckets.get(key) || { n: 0, why: why }; b.n++; buckets.set(key, b); };
  let noSignal = 0;
  sigs.forEach((s) => {
    const skip = String((s && s.tradeSkip) || '');
    if (!skip) { noSignal++; return; }
    if (/trading-paused|paused-by-user/i.test(skip)) return add('paused', '你手动停止了开新单');
    if (/breadth-hot-short-block/i.test(skip)) return add('breadth', '市场普涨，系统暂停做空（保护）');
    if (/chg24-hot-short-block/i.test(skip)) return add('chg24', '某个币涨得太快，不做空');
    if (/low-volume|volume/i.test(skip)) return add('vol', '成交额不够，流动性太差');
    if (/avail-low/i.test(skip)) return add('avail', '可用余额不足');
    if (/持仓数|position/i.test(skip)) return add('posmax', '持仓额度已满');
    if (/round-limit/i.test(skip)) return add('round', '本轮开单额度已用完');
    if (/今日已开/i.test(skip)) return add('day', '今天开单额度已用完');
    if (/回撤超/i.test(skip)) return add('dd', '触发回撤熔断，已自动停止开新单');
    if (/cooldown/i.test(skip)) return add('cool', '某个策略或币在冷却期');
    if (/reverse|uptrend/i.test(skip)) return add('rev', '被趋势过滤拦下');
    return add('other:' + skip.slice(0, 40), skip.slice(0, 80));
  });

  if (!sigs.length) return { text: '本轮没有选出候选币（市场没有符合条件的机会），这是正常现象。', list: [] };
  if (!buckets.size) {
    return { text: noSignal >= sigs.length ? '本轮 ' + sigs.length + ' 个候选都没达到开单条件，属于正常情况。' : '本轮没有开单。', list: [] };
  }
  const list = Array.from(buckets.entries()).map(([k, v]) => ({ key: k, n: v.n, why: v.why })).sort((a, b) => b.n - a.n);
  const top = list[0];
  let text = '本轮没开单：' + top.why;
  if (list.length > 1) text += '（另有 ' + (list.length - 1) + ' 类其他原因）';
  text += '。';
  return { text, list };
}

// ---------------------------------------------------------------- 状态聚合

let cache = { at: 0, data: null };
let inflight = null;
let HAS_SYSTEMCTL = null;

// 有些环境没有 systemd（本地预览、容器）。没有的话不能把服务状态判成"未运行"，
// 否则界面会一直红灯报假故障 —— 改为"未接系统服务"，只用心跳判断健康。
function checkSystemctl() {
  if (HAS_SYSTEMCTL !== null) return Promise.resolve(HAS_SYSTEMCTL);
  return run('systemctl', ['--version'], 5000).then((r) => { HAS_SYSTEMCTL = r.ok; return HAS_SYSTEMCTL; });
}

function todayKey() { const d = new Date(); return d.toISOString().slice(0, 10); }

function todayEquity(curEq) {
  try {
    const rec = readJSON(F.today, null);
    if (rec && rec.date === todayKey()) return rec.equity;
    if (curEq > 0) { atomicWrite(F.today, { date: todayKey(), equity: curEq, at: nowStr() }); return curEq; }
    return null;
  } catch (e) { return null; }
}

function buildState() {
  const cfg = readJSON(F.config, {}) || {};
  const rules = cfg.rules || {};
  const risk = cfg.risk || {};
  const sw = readJSON(F.switch, { allowOpen: true, missing: true });
  const round = parseLastRound(tailText(F.signals, 2 * 1024 * 1024));

  return checkSystemctl().then((hasSys) => Promise.all([
    okxJSON(['account', 'balance']),
    okxJSON(['swap', 'positions']),
    okxJSON(['swap', 'orders']),
    hasSys ? run('systemctl', ['is-active', MONITOR_UNIT], 5000) : Promise.resolve({ ok: false, out: '', err: '' }),
    hasSys ? run('systemctl', ['show', MONITOR_UNIT, '-p', 'ActiveEnterTimestamp', '-p', 'NRestarts'], 5000) : Promise.resolve({ ok: false, out: '', err: '' }),
  ]).then(([bal, pos, ord, active, show]) => {
    let totalEq = 0, availEq = 0, detail = [];
    if (bal.ok && bal.data && bal.data[0]) {
      totalEq = parseFloat(bal.data[0].totalEq || 0) || 0;
      detail = Array.isArray(bal.data[0].details) ? bal.data[0].details : [];
      availEq = detail.reduce((s, d) => s + (parseFloat(d.availEq || d.availBal || 0) || 0), 0);
      if (!availEq) availEq = parseFloat(bal.data[0].availEq || 0) || 0;
    }
    const positions = [];
    if (pos.ok && Array.isArray(pos.data)) {
      pos.data.forEach((p) => {
        const sz = parseFloat(p.pos || 0);
        if (!sz) return;
        positions.push({
          instId: p.instId, posSide: p.posSide || (sz > 0 ? 'long' : 'short'), pos: sz,
          avgPx: parseFloat(p.avgPx || 0), markPx: parseFloat(p.markPx || 0),
          lever: p.lever ? parseFloat(p.lever) : null,
          upl: parseFloat(p.upl || 0), uplRatio: p.uplRatio ? parseFloat(p.uplRatio) : null,
          mgnMode: p.mgnMode || '',
        });
      });
    }

    // 未成交的限价挂单（策略下的单 clOrdId 以 DSH 开头）
    const pending = [];
    if (ord.ok && Array.isArray(ord.data)) {
      ord.data.forEach((o) => {
        if (!o || (o.state && String(o.state) !== 'live')) return;
        const cid = String(o.clOrdId || '');
        let ts = '';
        if (o.cTime) { try { ts = new Date(parseInt(o.cTime, 10)).toLocaleString('sv-SE').slice(0, 16); } catch (e) {} }
        pending.push({
          instId: o.instId, side: o.side, sz: parseFloat(o.sz || 0), px: parseFloat(o.px || 0),
          state: o.state || '', clOrdId: cid, strategy: /^DSH/i.test(cid), ts: ts,
        });
      });
    }

    const lastTs = round && round.ts ? round.ts : null;
    let ageSec = null;
    if (lastTs) { const t = Date.parse(lastTs.replace(' ', 'T') + '+08:00'); if (!isNaN(t)) ageSec = Math.round((Date.now() - t) / 1000); }
    if (ageSec === null) {
      try { ageSec = Math.round((Date.now() - fs.statSync(F.signals).mtimeMs) / 1000); } catch (e) {}
    }

    const baseline = readJSON(F.equity, null);
    const todayEq = todayEquity(totalEq);
    const upl = positions.reduce((s, p) => s + p.upl, 0);
    const strategyPid = HAS_SYSTEMCTL ? null : launcherStrategyAlive();
    const serviceActive = HAS_SYSTEMCTL ? (active.out.trim() === 'active') : (strategyPid !== null);
    const serviceMode = HAS_SYSTEMCTL ? 'systemd' : (strategyPid !== null ? 'launcher' : 'none');
    const restarts = (show.out.match(/NRestarts=(\d+)/) || [])[1];
    const hasRound = !!(round && round.ts);

    const healthy = (serviceActive !== false) && (hasRound ? (ageSec !== null && ageSec < 5400) : serviceActive === true);
    const warn = [];
    if (serviceActive === false) warn.push('策略没有在运行');
    if (ageSec !== null && ageSec > 5400) warn.push('超过 90 分钟没有新的运行记录');
    if (availEq > 0 && availEq < (parseFloat(risk.minAvailEqUsdt || 0) || 0)) warn.push('可用余额不足，系统已停止开新单');
    if (typeof rules.maxOpenPositions === 'number' && positions.length >= rules.maxOpenPositions) warn.push('持仓数已达上限，暂不开新单');

    return {
      now: nowStr(),
      version: (function () { try { return fs.readFileSync(F.version, 'utf8').trim(); } catch (e) { return 'dev'; } })(),
      profile: PROFILE,
      demo: currentDemo(),
      configured: fs.existsSync(F.okxConfig),
      service: { active: serviceActive, managed: HAS_SYSTEMCTL, mode: serviceMode, pid: strategyPid, unit: MONITOR_UNIT, restarts: restarts ? parseInt(restarts, 10) : null },
      heartbeat: { lastRoundTs: lastTs, ageSec: ageSec, healthy: healthy },
      account: {
        totalEq: totalEq, availEq: availEq, upl: upl,
        todayChange: (todayEq && totalEq) ? Math.round((totalEq - todayEq) * 100) / 100 : null,
        balanceError: bal.ok ? null : bal.error,
      },
      positions: positions,
      pending: pending,
      pendingError: ord.ok ? null : ord.error,
      switch: { allowOpen: sw.allowOpen !== false, reason: sw.reason || '', updatedAt: sw.updatedAt || '', missing: !!sw.missing },
      applied: readJSON(F.switchApplied, null),
      config: {
        notional: parseFloat(risk.fixedNotionalUsdt || 0) || 0,
        leverage: parseInt(rules.leverage || 0, 10) || 0,
        shortLeverage: parseInt(rules.shortLeverage || 0, 10) || 0,
        maxPerDay: parseInt(rules.maxPerDay || 0, 10) || 0,
        maxOpenPositions: parseInt(rules.maxOpenPositions || 0, 10) || 0,
        ddHalt: typeof risk.ddHalt === 'number' ? risk.ddHalt : 0,
        tpPct: parseFloat(risk.mainTpPct || 0) || 0,
        slPct: parseFloat(risk.mainSlPct || 0) || 0,
        minAvailEq: parseFloat(risk.minAvailEqUsdt || 0) || 0,
      },
      round: round ? {
        ts: round.ts, round: round.round,
        signals: Array.isArray(round.signals) ? round.signals.length : 0,
        trades: Array.isArray(round.trades) ? round.trades.length : 0,
        errors: Array.isArray(round.errors) ? round.errors.slice(0, 5) : [],
      } : null,
      explain: explainNoTrade(round, serviceActive === true),
      warn: warn,
      choices: KNOWN,
    };
  }));
}

function getState(force) {
  if (!force && cache.data && Date.now() - cache.at < 45000) return Promise.resolve(cache.data);
  if (inflight) return inflight;
  inflight = buildState().then((d) => {
    cache = { at: Date.now(), data: d }; inflight = null; return d;
  }).catch((e) => {
    inflight = null;
    return { error: String(e && e.message || e), now: nowStr() };
  });
  return inflight;
}

// ---------------------------------------------------------------- 认证

// 本机公网 IP（给使用者在 OKX 后台填 IP 白名单用）。查不到不算失败。
let ipCache = { at: 0, ip: null };
async function myIp() {
  if (ipCache.ip && Date.now() - ipCache.at < 3600 * 1000) return { ok: true, ip: ipCache.ip };
  const urls = ['https://api.ipify.org?format=json', 'https://ifconfig.me/ip', 'https://ipinfo.io/ip'];
  for (const u of urls) {
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 4000);
      const r = await fetch(u, { signal: ctl.signal });
      clearTimeout(t);
      const txt = (await r.text()).trim();
      const m = txt.match(/\b(\d{1,3}\.){3}\d{1,3}\b/);
      if (m) { ipCache = { at: Date.now(), ip: m[0] }; return { ok: true, ip: m[0] }; }
    } catch (e) { /* 试下一个 */ }
  }
  return { ok: false, ip: null, error: '网络查询公网 IP 失败，可在 OKX 后台选择不绑定 IP' };
}

// 当前环境（模拟盘/实盘）以配置文件为准，而不是靠 profile 名猜：使用者可能在界面上改过
let demoCache = { at: 0, val: DEMO };
function currentDemo() {
  if (Date.now() - demoCache.at < 5000) return demoCache.val;
  let val = DEMO;
  try {
    const t = fs.readFileSync(F.okxConfig, 'utf8');
    const esc = PROFILE.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m = t.match(new RegExp('\\[profiles\\.' + esc + '\\]([\\s\\S]*?)(?=\\n\\[|$)'));
    if (m) { const d = m[1].match(/demo\s*=\s*(true|false)/i); if (d) val = /true/i.test(d[1]); }
  } catch (e) {}
  demoCache = { at: Date.now(), val: val };
  return val;
}

// 把 OKX 的英文报错翻成能照着做的话
function explainKeyError(msg) {
  const s = String(msg || '');
  if (/does not match current environment/i.test(s))
    return '这组 Key 的环境和当前模式不一致 —— 实盘 Key 要选「实盘」，模拟盘 Key 要选「模拟盘」，OKX 不允许跨环境使用。';
  if (/API key doesn't exist|Invalid API ?[Kk]ey/i.test(s)) return '这组 Key 不存在或已被删除/停用，也可能是复制时漏了字符 —— 请回 OKX 后台重新确认并整串复制。';
  if (/Invalid Passphrase/i.test(s)) return 'Passphrase 不对 —— 它是你创建这组 API 时自己设的口令，不是 OKX 登录密码。';
  if (/ENOENT|not recognized|不是内部或外部命令|command not found/i.test(s))
    return '这台电脑还没装 OKX 命令行（okx 命令）。用最新版 exe 运行会自动装好，或手动执行： npm install -g @okx_ai/okx-trade-cli';
  if (/Timestamp request expired/i.test(s)) return '本机时间和 OKX 相差超过 30 秒。先同步系统时间（Windows：w32tm /resync）再试。';
  if (/IP[\s\S]{0,30}(not|whitelist|白名单)/i.test(s)) return '这台机器的 IP 不在 OKX 的 IP 白名单里 —— 去 OKX 后台把这台机器的公网 IP 加进去（控制台里有「本机公网 IP」按钮）。';
  if (/50011|50013|Invalid Sign/i.test(s)) return '签名校验失败，通常是 Secret Key 复制错了。';
  if (/50111|50113/i.test(s)) return 'Key 或口令不对（OKX 错误码 ' + (s.match(/50\d{3}/) || [''])[0] + '）。';
  return s;
}

// 没有 systemd 的机器（Windows 本机、容器）：靠启动器写的 pids.txt 判断策略进程是否存活，
// 而不是一律显示"未接系统服务"（那会让人以为策略没在跑）
function launcherStrategyAlive() {
  try {
    const t = fs.readFileSync(path.join(RADAR, 'pids.txt'), 'utf8');
    const m = t.match(/strategy=(\d+)/);
    if (!m) return null;
    const pid = parseInt(m[1], 10);
    try { process.kill(pid, 0); return pid; } catch (e) { return null; }
  } catch (e) { return null; }
}

// 账户/密钥状态（给`"OKX 账户与密钥`"卡片用）：含一次真连探测，结果缓存 5 分钟
let keyCache = { at: 0, data: null };
async function keyStatus(force) {
  if (!force && keyCache.data && Date.now() - keyCache.at < 300000) return keyCache.data;
  const configured = fs.existsSync(F.okxConfig);
  let perm = null, totalEq = null, err = null;
  if (configured) {
    const c = await okxJSON(['account', 'config'], 20000);
    if (c.ok && c.data && c.data[0]) perm = c.data[0].perm || c.data[0].permissions || null;
    else err = c.error;
    const b = await okxJSON(['account', 'balance'], 20000);
    if (b.ok && b.data && b.data[0]) { totalEq = b.data[0].totalEq || null; err = null; }
    else if (!err) err = b.error;
  }
  const out = { ok: true, profile: PROFILE, demo: currentDemo(), keyConfigured: configured, keyFile: F.okxConfig, perm: perm, totalEq: totalEq, error: err };
  keyCache = { at: Date.now(), data: out };
  return out;
}

const sessions = new Map();
let loginFails = 0, loginLockUntil = 0;

function hashPass(pass, salt) { return crypto.scryptSync(pass, salt, 32).toString('hex'); }

function hasPassword() { return fs.existsSync(F.auth); }

function setPassword(pass) {
  const salt = crypto.randomBytes(16).toString('hex');
  atomicWrite(F.auth, { salt: salt, hash: hashPass(pass, salt), createdAt: nowStr() });
  try { fs.chmodSync(F.auth, 0o600); } catch (e) {}
}

function checkPassword(pass) {
  const a = readJSON(F.auth, null);
  if (!a) return false;
  const h = hashPass(pass, a.salt);
  return h.length === a.hash.length && crypto.timingSafeEqual(Buffer.from(h), Buffer.from(a.hash));
}

function authOK(req) {
  // 仅供本地/离线自测使用；install.sh 不会设置这个变量，生产环境永远走下面的正常校验。
  if (process.env.CONSOLE_DEV_NOAUTH === '1') return true;
  const c = req.headers.cookie || '';
  const m = c.match(/sid=([a-f0-9]+)/);
  if (!m) return false;
  const s = sessions.get(m[1]);
  if (!s) return false;
  if (Date.now() - s.at > 7 * 24 * 3600 * 1000) { sessions.delete(m[1]); return false; }
  s.at = Date.now();
  return true;
}

// 是不是"就在这台机器上打开的"（本机访问免密码：普通使用者双击就能用，
// 而从手机/别的电脑访问则必须有密码）
function isLocal(req) {
  const a = (req.socket && (req.socket.remoteAddress || '')) || '';
  return a === '127.0.0.1' || a === '::1' || a === '::ffff:127.0.0.1';
}

function guard(req, res) {
  if (isLocal(req)) return true;            // 本机免密
  if (authOK(req)) return true;
  if (!hasPassword()) {
    send(res, 403, { ok: false, error: '这台机器还没有设置控制台密码。请先在那台电脑上打开控制台设置密码，再从这台设备访问。' });
    return false;
  }
  send(res, 401, { ok: false, error: '未登录' });
  return false;
}

// ---------------------------------------------------------------- HTTP

function send(res, code, obj, type) {
  const body = typeof obj === 'string' ? obj : JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': (type || 'application/json; charset=utf-8'), 'Cache-Control': 'no-store' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let s = '';
    req.on('data', (c) => { s += c; if (s.length > 65536) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch (e) { resolve({}); } });
  });
}

const ACTIONS = {
  // 首次设置控制台密码
  'setup-password': (b) => {
    if (hasPassword()) return { ok: false, error: '密码已设置过' };
    const p = String(b.password || '');
    if (p.length < 6) return { ok: false, error: '密码至少 6 位' };
    setPassword(p);
    const sid = crypto.randomBytes(24).toString('hex');
    sessions.set(sid, { at: Date.now() });
    return { ok: true, cookie: sid };
  },
  'login': (b) => {
    if (Date.now() < loginLockUntil) return { ok: false, error: '尝试次数过多，请稍后再试' };
    if (!checkPassword(String(b.password || ''))) {
      loginFails++;
      if (loginFails >= 5) { loginLockUntil = Date.now() + 300000; loginFails = 0; }
      return { ok: false, error: '密码不对' };
    }
    loginFails = 0;
    const sid = crypto.randomBytes(24).toString('hex');
    sessions.set(sid, { at: Date.now() });
    return { ok: true, cookie: sid };
  },
  // 填写并验证 OKX 凭据
  'setup-key': async (b) => {
    const key = String(b.apiKey || '').trim();
    const sec = String(b.secretKey || '').trim();
    const pass = String(b.passphrase || '').trim();
    if (!key || !sec || !pass) return { ok: false, error: '三项都要填（API Key / Secret Key / Passphrase）' };
    if (/["\r\n]/.test(key + sec + pass)) return { ok: false, error: '内容不能含引号或换行，请重新复制' };

    const dir = path.dirname(F.okxConfig);
    fs.mkdirSync(dir, { recursive: true });
    const backupName = backup(F.okxConfig, 'before-dist-setup');
    let old = '';
    try { old = fs.readFileSync(F.okxConfig, 'utf8'); } catch (e) {}
    old = old.replace(new RegExp('\\n?\\[profiles\\.' + PROFILE + '\\][\\s\\S]*?(?=\\n\\[|\\s*$)', ''), '');
    // 环境：由使用者在界面上选（模拟盘 / 实盘）。不再只靠 profile 名猜——
    // 实盘 Key 连模拟环境会被 OKX 拒（APIKey does not match current environment），反过来同理。
    const wantDemo = (b.env === 'demo') ? true : ((b.env === 'live') ? false : currentDemo());
    const block = '\n[profiles.' + PROFILE + ']\napi_key = "' + key + '"\nsecret_key = "' + sec + '"\npassphrase = "' + pass + '"\ndemo = ' + (wantDemo ? 'true' : 'false') + '\n';
    const head = /default_profile\s*=/.test(old) ? old : ('default_profile = "' + PROFILE + '"\n' + old);
    fs.writeFileSync(F.okxConfig, head.replace(/\s*$/, '\n') + block, 'utf8');
    try { fs.chmodSync(F.okxConfig, 0o600); } catch (e) {}

    // 包装脚本：monitor 实盘模式调用 okx-<profile>
    try {
      fs.writeFileSync(F.wrapper, '#!/bin/bash\nexec okx --profile ' + PROFILE + ' "$@"\n', 'utf8');
      fs.chmodSync(F.wrapper, 0o755);
    } catch (e) {}

    const test = await okxJSON(['account', 'balance'], 25000);
    if (!test.ok) {
      // 验证失败必须回滚：坏密钥留在配置里会让后面的每一轮都失败
      let restored = false;
      try {
        if (backupName) { fs.copyFileSync(path.join(dir, backupName), F.okxConfig); restored = true; }
        else if (!old) { fs.rmSync(F.okxConfig, { force: true }); restored = true; }
      } catch (e) {}
      keyCache = { at: 0, data: null };
      demoCache = { at: 0, val: DEMO };
      return { ok: false, error: '连不上 OKX：' + explainKeyError(test.error), restored: restored };
    }
    keyCache = { at: 0, data: null };
    const perm = await okxJSON(['account', 'config'], 20000);
    let permText = null;
    if (perm.ok && perm.data && perm.data[0]) {
      permText = perm.data[0].perm || perm.data[0].permissions || null;
    }
    if (permText && /withdraw/i.test(String(permText))) {
      return { ok: false, error: '这组 API Key 带「提币」权限，为了安全请到 OKX 后台取消提币权限后再填。' };
    }
    return { ok: true, perm: permText, backup: backupName, totalEq: test.data && test.data[0] ? test.data[0].totalEq : null };
  },
  // 改档位
  'settings': async (b) => {
    const cfg = readJSON(F.config, null);
    if (!cfg) return { ok: false, error: '读不到 live-config.json' };
    const want = {};
    for (const k of Object.keys(KNOWN)) {
      if (b[k] === undefined) continue;
      const v = Number(b[k]);
      if (!KNOWN[k].includes(v)) return { ok: false, error: k + ' 只能取 ' + KNOWN[k].join(' / ') };
      want[k] = v;
    }
    if (!Object.keys(want).length) return { ok: false, error: '没有要改的项' };
    const backupName = backup(F.config, 'settings');
    if (want.notional !== undefined) cfg.risk.fixedNotionalUsdt = want.notional;
    if (want.leverage !== undefined) { cfg.rules.leverage = want.leverage; cfg.rules.shortLeverage = want.leverage; }
    if (want.maxPerDay !== undefined) cfg.rules.maxPerDay = want.maxPerDay;
    if (want.minAvailEq !== undefined) cfg.risk.minAvailEqUsdt = want.minAvailEq;
    if (want.ddHalt !== undefined) cfg.risk.ddHalt = want.ddHalt;
    if (want.notional !== undefined && parseFloat(cfg.risk.maxNotionalCap || 0) < want.notional) cfg.risk.maxNotionalCap = want.notional;
    cfg.updatedAt = nowStr();
    atomicWrite(F.config, cfg);

    if (!(await checkSystemctl())) {
      getState(true);
      return { ok: true, applied: want, restart: '配置已写入。用 Windows 启动器运行时它会在几秒内自动重启策略生效；手动运行的请自行重启策略', backup: backupName };
    }
    const rst = await run('systemctl', ['restart', MONITOR_UNIT], 60000);
    if (!rst.ok) return { ok: true, applied: want, restart: '重启失败：' + rst.err.split('\n')[0], backup: backupName };
    await new Promise((r) => setTimeout(r, 4000));
    const active = await run('systemctl', ['is-active', MONITOR_UNIT], 5000);
    getState(true);
    return { ok: true, applied: want, restart: active.out.trim() === 'active' ? '已重启并生效' : '重启后服务未运行，请点诊断导出', backup: backupName };
  },
  // 停止 / 恢复开新单
  'pause': async (b) => {
    const sw = readJSON(F.switch, {}) || {};
    const next = {
      allowOpen: false,
      reason: String(b.reason || '使用者在控制台手动停止开新单'),
      updatedAt: nowStr(), updatedBy: 'console',
      cancelPendingOnPause: sw.cancelPendingOnPause !== false,
      _note: '仅控制是否允许新开仓。平仓与止盈止损不受影响。',
    };
    atomicWrite(F.switch, next);
    getState(true);
    return { ok: true, switch: next, note: '最多 60 秒后生效；不会影响已有持仓的止盈止损。' };
  },
  'resume': async () => {
    const sw = readJSON(F.switch, {}) || {};
    const next = {
      allowOpen: true,
      reason: '使用者恢复开新单',
      updatedAt: nowStr(), updatedBy: 'console',
      cancelPendingOnPause: sw.cancelPendingOnPause !== false,
      _note: '仅控制是否允许新开仓。平仓与止盈止损不受影响。',
    };
    atomicWrite(F.switch, next);
    getState(true);
    return { ok: true, switch: next, note: '最多 60 秒后生效。' };
  },
};

function diagReport(st) {
  const cfg = readJSON(F.config, {}) || {};
  const lines = [];
  const add = (s) => lines.push(s);
  add('=== OKX 量化系统 · 诊断报告 ===');
  add('生成时间: ' + nowStr());
  add('版本: ' + (st.version || '?') + '   目录: ' + RADAR + '   账户 profile: ' + PROFILE);
  add('');
  add('--- 服务 ---');
  add('策略服务 ' + MONITOR_UNIT + ': ' + (st.service && st.service.active ? '运行中' : '未运行') + '（重启次数 ' + ((st.service && st.service.restarts) != null ? st.service.restarts : '?') + '）');
  add('上次运行记录: ' + ((st.heartbeat && st.heartbeat.lastRoundTs) || '无') + '   距今: ' + ((st.heartbeat && st.heartbeat.ageSec != null) ? st.heartbeat.ageSec + ' 秒' : '未知'));
  add('开单闸门: ' + (st.switch && st.switch.allowOpen ? '允许开新单' : '已停止开新单') + '   更新时间: ' + ((st.switch && st.switch.updatedAt) || '?'));
  add('');
  add('--- 账户 ---');
  add('总权益: ' + (st.account ? st.account.totalEq : '?') + '   可用: ' + (st.account ? st.account.availEq : '?') + '   浮盈: ' + (st.account ? st.account.upl : '?'));
  if (st.account && st.account.balanceError) add('余额读取错误: ' + st.account.balanceError);
  add('持仓数: ' + ((st.positions || []).length));
  (st.positions || []).forEach((p) => add('  ' + p.instId + ' ' + p.posSide + ' ' + p.pos + ' 张 @' + p.avgPx + ' 现价' + p.markPx + ' 浮盈' + p.upl + 'U 杠杆' + p.lever));
  add('');
  add('--- 档位 ---');
  add('每单名义: ' + st.config.notional + 'U   杠杆: ' + st.config.leverage + 'x   每天最多: ' + st.config.maxPerDay + ' 笔');
  add('回撤熔断: ' + (st.config.ddHalt ? (st.config.ddHalt * 100) + '%' : '关闭') + '   持仓上限: ' + st.config.maxOpenPositions + '   可用余额下限: ' + st.config.minAvailEq + 'U');
  add('止盈/止损: +' + (st.config.tpPct * 100) + '% / -' + (st.config.slPct * 100) + '%');
  add('');
  add('--- 最近一轮 ---');
  if (st.round) {
    add('时间: ' + st.round.ts + '  轮次: ' + st.round.round + '  候选: ' + st.round.signals + '  开单: ' + st.round.trades);
    add('结论: ' + (st.explain ? st.explain.text : ''));
    if (st.explain && st.explain.list) st.explain.list.forEach((x) => add('  [' + x.n + '] ' + x.why));
    if (st.round.errors && st.round.errors.length) { add('错误:'); st.round.errors.forEach((e) => add('  ' + JSON.stringify(e).slice(0, 300))); }
  } else add('读不到运行记录');
  add('');
  add('--- 运行环境 ---');
  add('Node: ' + process.version);
  return run('pwsh', ['-v'], 8000).then((p) => {
    add('PowerShell: ' + (p.out.trim() || '?'));
    return run(OKX_BIN, ['--version'], 10000);
  }).then((o) => {
    add('OKX CLI: ' + (o.out.trim().split('\n')[0] || '?'));
    return run('date', ['-u', '+%Y-%m-%d %H:%M:%S UTC'], 5000);
  }).then((d) => {
    add('本机时间: ' + d.out.trim());
    add('');
    add('（把整段复制发给作者即可定位问题）');
    return lines.join('\n');
  });
}

const server = http.createServer(async (req, res) => {
  const url = (req.url || '/').split('?')[0];
  try {
    if (url === '/' || url === '/index.html') {
      const p = path.join(__dirname, 'index.html');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      fs.createReadStream(p).pipe(res);
      return;
    }
    if (url === '/api/meta') {
      const st = await getState(false);
      return send(res, 200, {
        ok: true, hasPassword: hasPassword(), local: isLocal(req), authed: (isLocal(req) || authOK(req)),
        configured: !!(st && st.configured), version: st && st.version, profile: PROFILE, demo: currentDemo(),
      });
    }
    if (url === '/api/state') { if (!guard(req, res)) return; return send(res, 200, await getState(false)); }
    if (url === '/api/state/refresh') { if (!guard(req, res)) return; return send(res, 200, await getState(true)); }
    if (url === '/api/myip') { if (!guard(req, res)) return; return send(res, 200, await myIp()); }
    if (url === '/api/key-status') { if (!guard(req, res)) return; return send(res, 200, await keyStatus(false)); }

    if (url === '/api/diag') {
      if (!guard(req, res)) return;
      const st = await getState(false);
      const txt = await diagReport(st);
      return send(res, 200, txt, 'text/plain; charset=utf-8');
    }

    if (url.startsWith('/api/')) {
      const name = url.slice(5);
      const fn = ACTIONS[name];
      if (!fn) return send(res, 404, { ok: false, error: '未知接口' });
      if (req.method !== 'POST') return send(res, 405, { ok: false, error: 'method not allowed' });
      if (name !== 'login' && name !== 'setup-password' && !guard(req, res)) return;
      if (name === 'setup-password' && hasPassword()) return send(res, 400, { ok: false, error: '密码已设置过' });
      const body = await readBody(req);
      const out = await fn(body);
      if (out && out.cookie) {
        res.setHeader('Set-Cookie', 'sid=' + out.cookie + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800');
        delete out.cookie;
      }
      return send(res, out && out.ok === false ? 400 : 200, out);
    }
    return send(res, 404, { ok: false, error: 'not found' });
  } catch (e) {
    return send(res, 500, { ok: false, error: String(e && e.message || e) });
  }
});

// 命令行：给服务器端安装脚本用（无头机器没法"本机打开"设密码）
//   node web/server.js --set-password <密码>
//   node web/server.js --clear-password
if (process.argv[2] === '--set-password' || process.argv[2] === '--clear-password') {
  if (process.argv[2] === '--clear-password') {
    try { fs.rmSync(F.auth, { force: true }); console.log('已清除控制台密码'); } catch (e) { console.log('清除失败: ' + e.message); }
  } else {
    const pw = String(process.argv[3] || '');
    if (pw.length < 6) { console.log('密码至少 6 位'); process.exit(1); }
    setPassword(pw);
    console.log('已设置控制台密码（' + pw.length + ' 位）');
  }
  process.exit(0);
}

server.listen(PORT, BIND, () => {
  console.log('[console] listening on http://' + BIND + ':' + PORT + '  home=' + RADAR + ' profile=' + PROFILE + ' suffix=' + SUFFIX);
  console.log('[console] okx config: ' + (fs.existsSync(F.okxConfig) ? '已配置' : '未配置（打开网页完成首次设置）'));
});
